'use strict';

const config = require('./config');
const runtime = require('./runtime');
const { log, errorMessage } = require('./util');
const { store } = require('./store');

const box = (lines) => {
  const width = Math.max(...lines.map((line) => line.length)) + 4;
  const bar = '─'.repeat(width);
  return ['', `┌${bar}┐`, ...lines.map((line) => `│  ${line.padEnd(width - 2)}│`), `└${bar}┘`, ''].join('\n');
};

async function main() {
  console.log('');
  log.info('Iniciando SkyeBot…');

  const { errors, warnings } = config.validate();
  warnings.forEach((warning) => log.warn(warning));

  if (errors.length) {
    errors.forEach((error) => log.error(error));
    log.error('Corrija o arquivo .env (use o .env.example como modelo) e inicie de novo.');
    process.exit(1);
  }

  store.load();
  log.ok(`Banco carregado com ${Object.keys(store.data.guilds).length} servidor(es) configurado(s).`);
  store.startAutoBackup();

  const web = require('./web/server');
  const bot = require('./bot');
  const music = require('./bot/music');

  await web.start();
  music.initEngine().catch((err) => log.warn('Motor de música:', errorMessage(err))); // em segundo plano

  const connected = await bot.start();
  if (!connected) {
    log.warn('O painel está no ar, mas o bot não entrou no Discord. Veja o motivo acima e o aviso no topo do painel.');
  }

  // Resumo final, com o que a pessoa precisa para entrar no painel.
  const lines = [
    `Painel:  http://IP-DA-HOST:${runtime.port}   (porta ${runtime.port})`,
    `Usuário: ${config.panel.user}`,
    config.panel.passwordWasGenerated
      ? `Senha:   ${config.panel.password}   (gerada automaticamente — para trocar, defina PANEL_PASSWORD no .env)`
      : 'Senha:   a que você definiu em PANEL_PASSWORD no .env',
    `Bot:     ${connected ? 'conectado ao Discord' : 'OFFLINE — confira DISCORD_TOKEN no .env'}`,
  ];
  if (config.tunnel.mode !== 'off' && (config.ngrok.authtoken || config.tunnel.mode === 'cloudflare')) {
    lines.push('Link:    criando o túnel público… o endereço aparece aqui e no topo do painel.');
  }
  console.log(box(lines));

  let closing = false;
  const stop = async (signal) => {
    if (closing) return;
    closing = true;
    log.info(`Recebi ${signal}. Salvando os dados e encerrando…`);
    const force = setTimeout(() => process.exit(0), 8000);
    force.unref();
    try {
      store.saveNow();
      await bot.shutdown();
      await web.stop();
      require('./web/auth').sessionStore.flush();
      store.saveNow();
    } catch (err) {
      log.error('Erro ao encerrar:', errorMessage(err));
    }
    process.exit(0);
  };

  process.on('SIGINT', () => stop('SIGINT'));
  process.on('SIGTERM', () => stop('SIGTERM'));

  // Erros soltos derrubavam o processo inteiro na versão antiga.
  process.on('unhandledRejection', (reason) => log.error('Promise sem tratamento:', reason));
  process.on('uncaughtException', (err) => {
    log.error('Exceção não tratada:', err);
    store.saveNow();
  });
}

main().catch((err) => {
  log.error('Falha fatal na inicialização:', err);
  process.exit(1);
});
