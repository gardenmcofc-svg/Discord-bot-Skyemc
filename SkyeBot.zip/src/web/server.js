'use strict';

const path = require('path');
const express = require('express');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');

const config = require('../config');
const runtime = require('../runtime');
const { log, errorMessage } = require('../util');
const auth = require('./auth');
const tunnel = require('../tunnel');

const PUBLIC_DIR = path.join(config.rootDir, 'public');

let httpServer = null;

function createApp() {
  const api = require('./api'); // só carrega quando o painel sobe (depende do bot)
  const app = express();

  if (config.panel.trustProxy) app.set('trust proxy', 1);
  app.disable('x-powered-by');

  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'"],
          styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
          fontSrc: ["'self'", 'https://fonts.gstatic.com'],
          imgSrc: ["'self'", 'data:', 'https:'],
          connectSrc: ["'self'"],
          frameAncestors: ["'none'"],
          // O helmet liga isto por padrão e isso QUEBRA o painel quando ele é aberto
          // por http (ip:porta da host): o navegador tentaria buscar CSS e JS em https.
          upgradeInsecureRequests: null,
        },
      },
      crossOriginEmbedderPolicy: false,
      hsts: false, // o painel pode ser acessado por http e por https; não force um só.
    }),
  );
  app.use(compression());
  app.use(express.json({ limit: '256kb' }));
  app.use(express.urlencoded({ extended: false, limit: '256kb' }));

  // Não precisa de login: serve para a host saber que o processo está vivo.
  app.get('/healthz', (req, res) => res.json({ ok: true }));

  app.use(auth.sessionMiddleware);
  app.use(auth.sameOrigin);

  app.use(
    '/api',
    rateLimit({
      windowMs: 60000,
      limit: 300,
      standardHeaders: true,
      legacyHeaders: false,
      message: { error: true, message: 'Muitas requisições. Aguarde um momento.' },
    }),
  );

  auth.attachRoutes(app);

  app.get('/login', (req, res) => {
    if (req.session?.user) return res.redirect('/');
    res.setHeader('Cache-Control', 'no-store');
    res.sendFile(path.join(PUBLIC_DIR, 'login.html'));
  });

  app.use('/api', auth.requireAuth, api);

  app.get('/', auth.requireAuth, (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
  });

  app.use(
    express.static(PUBLIC_DIR, {
      index: false,
      maxAge: '5m',
      setHeaders: (res, filePath) => {
        if (filePath.endsWith('.html')) res.setHeader('Cache-Control', 'no-store');
      },
    }),
  );

  app.use((req, res) => {
    if (req.path.startsWith('/api/')) {
      return res.status(404).json({ error: true, message: 'Rota não encontrada.' });
    }
    res.redirect('/');
  });

  app.use((err, req, res, next) => {
    log.error('Erro no servidor web:', err.message);
    if (res.headersSent) return next(err);
    res.status(500).json({ error: true, message: 'Erro interno no painel.' });
  });

  return app;
}

function listen(app, port) {
  return new Promise((resolve, reject) => {
    const instance = app.listen(port, '0.0.0.0', () => resolve(instance));
    instance.once('error', reject);
  });
}

async function start() {
  const app = createApp();

  let port = config.port;
  const maxTries = config.portFixedByHost ? 1 : 10;

  for (let attempt = 0; attempt < maxTries; attempt++) {
    try {
      httpServer = await listen(app, port);
      break;
    } catch (err) {
      if (err.code === 'EADDRINUSE' && attempt < maxTries - 1) {
        log.warn(`A porta ${port} está ocupada. Tentando a ${port + 1}…`);
        port += 1;
        continue;
      }
      if (err.code === 'EADDRINUSE') {
        log.error(`A porta ${port} já está em uso. Feche o outro processo ou troque a porta.`);
      }
      throw err;
    }
  }

  httpServer.on('error', (err) => log.error('Servidor web:', err.message));
  runtime.port = port;
  log.ok(`Painel disponível em http://localhost:${port}`);

  // O túnel sobe em segundo plano para não atrasar o bot.
  tunnel.start(port).catch((err) => log.warn('Túnel:', errorMessage(err)));
  return httpServer;
}

async function stop() {
  await tunnel.stop().catch(() => {});
  if (httpServer) {
    await new Promise((resolve) => {
      httpServer.close(() => resolve());
      httpServer.closeAllConnections?.();
      setTimeout(resolve, 2000).unref();
    });
  }
}

module.exports = { createApp, start, stop };
