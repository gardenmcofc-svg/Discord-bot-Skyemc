'use strict';

const express = require('express');
const fs = require('fs');
const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');

const pkg = require('../../package.json');
const runtime = require('../runtime');
const { store, DB_FILE } = require('../store');
const { pingMinecraft, rememberPing, faviconFor } = require('../mcping');
const { clamp, str, cleanId, isSnowflake, parseDuration, escapeMentions, errorMessage, log } = require('../util');

const bot = require('../bot');
const music = require('../bot/music');
const progress = require('../bot/progress');
const tickets = require('../bot/tickets');
const suggestions = require('../bot/suggestions');
const giveaways = require('../bot/giveaways');
const moderation = require('../bot/moderation');

const router = express.Router();

/** O cliente pode ser recriado (ex.: intents), então sempre lemos o atual. */
const client = () => bot.client;

const ok = (res, message, extra = {}) => res.json({ error: false, message, ...extra });
const fail = (res, status, message) => res.status(status).json({ error: true, message });

/** Express 4 não captura erros de funções async; este envelope resolve. */
const route = (handler) => (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);

const idList = (value, max = 50) =>
  (Array.isArray(value) ? value : String(value ?? '').split(','))
    .map((item) => cleanId(item))
    .filter(Boolean)
    .slice(0, max);

const wordList = (value, max = 200) =>
  (Array.isArray(value) ? value : String(value ?? '').split(/[,\n]/))
    .map((word) => String(word).trim().toLowerCase().slice(0, 60))
    .filter(Boolean)
    .slice(0, max);

const domainList = (value, max = 100) =>
  (Array.isArray(value) ? value : String(value ?? '').split(/[,\n\s]+/))
    .map((item) => String(item).trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/.*$/, ''))
    .filter((item) => /^[a-z0-9.-]+\.[a-z]{2,}$/.test(item))
    .slice(0, max);

const slug = (value) =>
  String(value ?? '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);

/** Categorias de ticket: ids únicos e textos dentro dos limites do Discord. */
function categoryList(value) {
  const seen = new Map();
  for (const item of Array.isArray(value) ? value : []) {
    const label = str(item?.label, 50, '').trim();
    const id = slug(item?.id || label);
    if (!id || !label || seen.has(id)) continue;
    seen.set(id, {
      id,
      label,
      emoji: str(item?.emoji, 8, '').trim(),
      description: str(item?.description, 100, '').trim(),
    });
  }
  return [...seen.values()].slice(0, 10);
}

const hexColor = (value, fallback) =>
  /^#[0-9a-f]{6}$/i.test(String(value)) ? String(value) : fallback;

// ---------------------------------------------------------------------------
// Middleware de servidor
// ---------------------------------------------------------------------------

router.param('guildId', (req, res, next, guildId) => {
  if (!isSnowflake(guildId)) return fail(res, 400, 'ID de servidor inválido.');
  if (!client().guilds.cache.has(guildId)) {
    return fail(res, 404, 'O bot não está nesse servidor. Convide-o e recarregue o painel.');
  }
  req.guildId = guildId;
  req.guildData = store.guild(guildId);
  return next();
});

function requireReady(req, res, next) {
  if (!client().isReady()) return fail(res, 503, 'O bot ainda não está conectado ao Discord.');
  return next();
}

// ---------------------------------------------------------------------------
// Estado geral
// ---------------------------------------------------------------------------

router.get('/status', (req, res) => {
  const c = client();
  const ready = c.isReady();
  res.json({
    version: pkg.version,
    botOnline: ready,
    botTag: c.user?.tag ?? null,
    botAvatar: c.user?.displayAvatarURL?.({ size: 128 }) ?? null,
    botError: ready ? null : runtime.botError,
    limitedIntents: runtime.limitedIntents,
    inviteUrl: bot.inviteUrl(),
    ping: ready && Number.isFinite(c.ws.ping) ? Math.max(0, Math.round(c.ws.ping)) : null,
    uptime: c.uptime ?? 0,
    panel: {
      publicUrl: runtime.publicUrl,
      directUrl: runtime.directUrl,
      port: runtime.port,
      tunnel: runtime.tunnel,
    },
    system: {
      node: process.version,
      memoryMb: Math.round(process.memoryUsage().rss / 1048576),
      processUptime: Math.round(process.uptime() * 1000),
    },
    music: music.engineInfo(),
    guilds: ready
      ? c.guilds.cache
          .map((guild) => ({
            id: guild.id,
            name: guild.name,
            icon: guild.iconURL({ size: 64 }),
            memberCount: guild.memberCount,
          }))
          .sort((a, b) => b.memberCount - a.memberCount)
      : [],
  });
});

router.get('/guilds/:guildId/overview', route(async (req, res) => {
  const data = req.guildData;
  const guild = client().guilds.cache.get(req.guildId);

  res.json({
    guild: {
      id: guild.id,
      name: guild.name,
      icon: guild.iconURL({ size: 128 }),
      memberCount: guild.memberCount,
      channelCount: guild.channels.cache.size,
      roleCount: guild.roles.cache.size,
    },
    stats: {
      ...data.stats,
      economyAccounts: Object.keys(data.economy.users).length,
      rankedUsers: Object.keys(data.levels.users).length,
      openGiveaways: data.giveaways.filter((g) => !g.ended).length,
      customCommands: data.customCommands.length,
      openTickets: data.ticketList.filter((t) => t.status === 'open').length,
      pendingSuggestions: data.suggestionList.filter((sug) => sug.status === 'pending').length,
      warnedUsers: Object.keys(data.warns).length,
    },
    minecraft: data.serverStatus.lastPing,
    minecraftIcon: faviconFor(req.guildId),
    music: music.snapshot(req.guildId),
    logs: store.logsFor(req.guildId, 30),
  });
}));

router.get('/guilds/:guildId/resources', (req, res) => {
  const resources = bot.listGuildResources(req.guildId);
  if (!resources) return fail(res, 404, 'Servidor não encontrado no cache do bot.');
  return res.json(resources);
});

/** Busca de membros por nome, para o painel não depender de colar IDs. */
router.get('/guilds/:guildId/members', route(async (req, res) => {
  const query = str(String(req.query.q ?? ''), 60, '').trim();
  if (query.length < 2) return res.json({ members: [] });

  const guild = client().guilds.cache.get(req.guildId);
  try {
    const found = isSnowflake(query)
      ? [await guild.members.fetch(query)]
      : [...(await guild.members.search({ query, limit: 8 })).values()];
    return res.json({
      members: found.filter(Boolean).map((member) => ({
        id: member.id,
        tag: member.user.tag,
        name: member.displayName,
        avatar: member.displayAvatarURL({ size: 64 }),
      })),
    });
  } catch {
    return res.json({ members: [] });
  }
}));

router.get('/guilds/:guildId/config', (req, res) => {
  // eslint-disable-next-line no-unused-vars
  const { levels, economy, warns, ticketList, suggestionList, polls, reminders, ...rest } = req.guildData;
  res.json({
    ...rest,
    // Os mapas de usuários vão por rotas próprias para o payload não crescer demais.
    levels: { ...levels, users: undefined },
    economy: { ...economy, users: undefined },
  });
});

// ---------------------------------------------------------------------------
// Configurações (cada seção tem o próprio saneamento)
// ---------------------------------------------------------------------------

const sanitizers = {
  general: (body, current) => ({
    prefix: str(body.prefix, 5, current.prefix).trim() || '!',
  }),

  automod: (body, current) => ({
    enabled: Boolean(body.enabled),
    antiInvite: Boolean(body.antiInvite),
    antiLink: Boolean(body.antiLink),
    allowedDomains: domainList(body.allowedDomains),
    antiSpam: Boolean(body.antiSpam),
    spamMessages: clamp(body.spamMessages, 2, 30, current.spamMessages),
    spamSeconds: clamp(body.spamSeconds, 2, 60, current.spamSeconds),
    maxMentions: clamp(body.maxMentions, 0, 30, current.maxMentions),
    capsPercent: clamp(body.capsPercent, 0, 100, current.capsPercent),
    badWords: wordList(body.badWords),
    ignoredRoleIds: idList(body.ignoredRoleIds),
    ignoredChannelIds: idList(body.ignoredChannelIds),
    logChannelId: cleanId(body.logChannelId),
    punishment: ['delete', 'warn', 'timeout'].includes(body.punishment) ? body.punishment : 'delete',
    timeoutMinutes: clamp(body.timeoutMinutes, 1, 10080, current.timeoutMinutes),
  }),

  welcome: (body, current) => ({
    enabled: Boolean(body.enabled),
    channelId: cleanId(body.channelId),
    message: str(body.message, 1800, current.message),
    useEmbed: Boolean(body.useEmbed),
    embedColor: hexColor(body.embedColor, current.embedColor),
    autoRoleId: cleanId(body.autoRoleId),
    dmEnabled: Boolean(body.dmEnabled),
    dmMessage: str(body.dmMessage, 1800, current.dmMessage),
    leaveEnabled: Boolean(body.leaveEnabled),
    leaveChannelId: cleanId(body.leaveChannelId),
    leaveMessage: str(body.leaveMessage, 1800, current.leaveMessage),
  }),

  tickets: (body, current) => ({
    enabled: Boolean(body.enabled),
    channelId: cleanId(body.channelId),
    categoryId: cleanId(body.categoryId),
    supportRoleId: cleanId(body.supportRoleId),
    logChannelId: cleanId(body.logChannelId),
    embedTitle: str(body.embedTitle, 250, current.embedTitle),
    embedDesc: str(body.embedDesc, 3800, current.embedDesc),
    buttonText: str(body.buttonText, 78, current.buttonText) || 'Abrir ticket',
    ticketWelcomeMsg: str(body.ticketWelcomeMsg, 3800, current.ticketWelcomeMsg),
    embedColor: hexColor(body.embedColor, current.embedColor),
    transcripts: Boolean(body.transcripts),
    maxPerUser: clamp(body.maxPerUser, 1, 5, current.maxPerUser),
    ratings: body.ratings === undefined ? current.ratings : Boolean(body.ratings),
    autoCloseHours: clamp(body.autoCloseHours, 0, 720, current.autoCloseHours ?? 0),
    categories: body.categories === undefined ? current.categories : categoryList(body.categories),
  }),

  suggestions: (body, current) => ({
    enabled: Boolean(body.enabled),
    channelId: cleanId(body.channelId),
    dmAuthor: body.dmAuthor === undefined ? current.dmAuthor : Boolean(body.dmAuthor),
  }),

  serverStatus: (body, current) => ({
    enabled: Boolean(body.enabled),
    name: str(body.name, 100, current.name),
    host: str(body.host, 120, current.host).trim().replace(/^https?:\/\//i, '').replace(/\/.*$/, ''),
    port: clamp(body.port, 1, 65535, current.port),
    counterChannelId: cleanId(body.counterChannelId),
    counterTemplate: str(body.counterTemplate, 90, current.counterTemplate),
  }),

  levels: (body, current) => ({
    enabled: Boolean(body.enabled),
    xpMin: clamp(body.xpMin, 1, 500, current.xpMin),
    xpMax: clamp(body.xpMax, 1, 500, current.xpMax),
    cooldownSeconds: clamp(body.cooldownSeconds, 0, 3600, current.cooldownSeconds),
    announce: Boolean(body.announce),
    announceChannelId: cleanId(body.announceChannelId),
    announceMessage: str(body.announceMessage, 500, current.announceMessage),
    noXpChannelIds: idList(body.noXpChannelIds),
    rewards: (Array.isArray(body.rewards) ? body.rewards : [])
      .map((reward) => ({ level: clamp(reward.level, 1, 999, 1), roleId: cleanId(reward.roleId) }))
      .filter((reward) => reward.roleId)
      .slice(0, 40),
  }),

  economy: (body, current) => ({
    enabled: Boolean(body.enabled),
    currency: str(body.currency, 30, current.currency) || 'Folhas',
    currencyEmoji: str(body.currencyEmoji, 8, current.currencyEmoji),
    dailyAmount: clamp(body.dailyAmount, 0, 1000000, current.dailyAmount),
    workMin: clamp(body.workMin, 0, 1000000, current.workMin),
    workMax: clamp(body.workMax, 0, 1000000, current.workMax),
    workCooldownMinutes: clamp(body.workCooldownMinutes, 1, 10080, current.workCooldownMinutes),
  }),

  antinuke: (body, current) => ({
    enabled: Boolean(body.enabled),
    maxChannelDelete: clamp(body.maxChannelDelete, 1, 50, current.maxChannelDelete),
    maxRoleDelete: clamp(body.maxRoleDelete, 1, 50, current.maxRoleDelete),
    maxBans: clamp(body.maxBans, 1, 50, current.maxBans),
    maxKicks: clamp(body.maxKicks, 1, 50, current.maxKicks),
    windowSeconds: clamp(body.windowSeconds, 10, 3600, current.windowSeconds),
    punishment: ['removeRoles', 'kick', 'ban'].includes(body.punishment) ? body.punishment : 'removeRoles',
    whitelistIds: idList(body.whitelistIds),
    alertChannelId: cleanId(body.alertChannelId),
  }),
};

router.post('/guilds/:guildId/config/:section', (req, res) => {
  const section = req.params.section;
  const sanitize = sanitizers[section];
  if (!sanitize) return fail(res, 400, 'Seção de configuração desconhecida.');

  const body = req.body || {};

  if (section === 'general') {
    Object.assign(req.guildData, sanitize(body, req.guildData));
    store.saveNow();
  } else {
    store.updateGuild(req.guildId, section, sanitize(body, req.guildData[section]));
    store.saveNow();
  }

  store.addLog(req.guildId, 'Painel', `Seção "${section}" atualizada.`);
  return ok(res, 'Alterações salvas.');
});

// ---------------------------------------------------------------------------
// Minecraft
// ---------------------------------------------------------------------------

router.post('/guilds/:guildId/minecraft/ping', route(async (req, res) => {
  const settings = req.guildData.serverStatus;
  const host = str(req.body?.host, 120, settings.host).trim();
  const port = clamp(req.body?.port, 1, 65535, settings.port);

  const result = await pingMinecraft(host, port);
  const light = rememberPing(req.guildId, result);
  if (host === settings.host && port === settings.port) {
    settings.lastPing = light;
    store.save();
  }
  res.json({
    error: false,
    message: result.online
      ? `Online: ${result.players.online}/${result.players.max} jogadores (${result.latency}ms).`
      : `Offline. ${result.error ?? ''}`.trim(),
    result: { ...light, favicon: result.favicon ?? null },
  });
}));

// ---------------------------------------------------------------------------
// Tickets
// ---------------------------------------------------------------------------

router.post('/guilds/:guildId/tickets/panel', requireReady, route(async (req, res) => {
  const result = await tickets.sendPanel(client(), req.guildId);
  if (result.error) return fail(res, 400, result.message);
  return ok(res, result.message);
}));

router.get('/guilds/:guildId/badges', (req, res) => {
  res.json({
    tickets: req.guildData.ticketList.filter((t) => t.status === 'open').length,
    suggestions: req.guildData.suggestionList.filter((sug) => sug.status === 'pending').length,
  });
});

router.get('/guilds/:guildId/tickets', (req, res) => {
  const status = ['open', 'closed'].includes(req.query.status) ? req.query.status : 'all';
  res.json({
    stats: tickets.stats(req.guildId),
    tickets: tickets.list(req.guildId, { status, query: str(String(req.query.q ?? ''), 60, '') }),
  });
});

router.get('/guilds/:guildId/tickets/:ticketId(\\d+)', route(async (req, res) => {
  const result = await tickets.detail(client(), req.guildId, req.params.ticketId);
  if (!result) return fail(res, 404, 'Ticket não encontrado.');
  return res.json(result);
}));

router.post('/guilds/:guildId/tickets/:ticketId(\\d+)/close', requireReady, route(async (req, res) => {
  const result = await tickets.closeFromPanel(client(), req.guildId, req.params.ticketId, str(req.body?.reason, 300, ''));
  return result.error ? fail(res, 400, result.message) : ok(res, result.message);
}));

router.post('/guilds/:guildId/tickets/:ticketId(\\d+)/reply', requireReady, route(async (req, res) => {
  const result = await tickets.replyFromPanel(client(), req.guildId, req.params.ticketId, req.body?.message);
  return result.error ? fail(res, 400, result.message) : ok(res, result.message);
}));

// ---------------------------------------------------------------------------
// Sugestões
// ---------------------------------------------------------------------------

router.get('/guilds/:guildId/suggestions', (req, res) => {
  const status = ['pending', 'approved', 'denied'].includes(req.query.status) ? req.query.status : 'all';
  const all = req.guildData.suggestionList;
  res.json({
    counts: {
      pending: all.filter((s) => s.status === 'pending').length,
      approved: all.filter((s) => s.status === 'approved').length,
      denied: all.filter((s) => s.status === 'denied').length,
    },
    suggestions: suggestions.list(req.guildId, status),
  });
});

router.post('/guilds/:guildId/suggestions/:id(\\d+)/review', requireReady, route(async (req, res) => {
  const status = req.body?.status === 'approved' ? 'approved' : req.body?.status === 'denied' ? 'denied' : null;
  if (!status) return fail(res, 400, 'Escolha aprovar ou negar.');
  const result = await suggestions.review(client(), req.guildId, req.params.id, status, str(req.body?.note, 500, ''), 'Painel web');
  return result.error ? fail(res, 400, result.message) : ok(res, result.message);
}));

// ---------------------------------------------------------------------------
// Mensagens e embeds
// ---------------------------------------------------------------------------

router.post('/guilds/:guildId/message', requireReady, route(async (req, res) => {
  const body = req.body || {};
  const channelId = cleanId(body.channelId);
  if (!channelId) return fail(res, 400, 'Escolha o canal de destino.');

  const guild = client().guilds.cache.get(req.guildId);
  const channel = guild.channels.cache.get(channelId);
  if (!channel?.isTextBased()) return fail(res, 404, 'Canal não encontrado neste servidor.');

  const content = str(body.content, 1900, '');
  const useEmbed = Boolean(body.useEmbed);

  if (!useEmbed && !content.trim()) return fail(res, 400, 'Escreva a mensagem antes de enviar.');

  const payload = { content: content ? escapeMentions(content) : undefined };

  if (useEmbed) {
    const embed = new EmbedBuilder().setColor(hexColor(body.embedColor, '#57C785'));
    const title = str(body.title, 250, '');
    const description = str(body.description, 3800, '');
    if (!title && !description) return fail(res, 400, 'A embed precisa de um título ou uma descrição.');
    if (title) embed.setTitle(title);
    if (description) embed.setDescription(escapeMentions(description));
    if (/^https?:\/\//.test(body.imageUrl || '')) embed.setImage(body.imageUrl);
    if (/^https?:\/\//.test(body.thumbnailUrl || '')) embed.setThumbnail(body.thumbnailUrl);
    const footer = str(body.footer, 2000, '');
    if (footer) embed.setFooter({ text: footer });
    payload.embeds = [embed];
  }

  try {
    await channel.send(payload);
    store.addLog(req.guildId, 'Mensagem', `Mensagem enviada para #${channel.name} pelo painel.`);
    return ok(res, `Mensagem enviada em #${channel.name}.`);
  } catch (err) {
    return fail(res, 500, `O Discord recusou o envio: ${errorMessage(err)}`);
  }
}));

router.post('/guilds/:guildId/role-buttons', requireReady, route(async (req, res) => {
  const body = req.body || {};
  const channelId = cleanId(body.channelId);
  const roles = (Array.isArray(body.roles) ? body.roles : []).slice(0, 5);
  if (!channelId) return fail(res, 400, 'Escolha o canal de destino.');
  if (!roles.length) return fail(res, 400, 'Selecione pelo menos um cargo.');

  const guild = client().guilds.cache.get(req.guildId);
  const channel = guild.channels.cache.get(channelId);
  if (!channel?.isTextBased()) return fail(res, 404, 'Canal não encontrado.');

  const buttons = [];
  for (const entry of roles) {
    const roleId = cleanId(entry.roleId ?? entry);
    const role = guild.roles.cache.get(roleId);
    if (!role) continue;
    buttons.push(
      new ButtonBuilder()
        .setCustomId(`role:${roleId}`)
        .setLabel(str(entry.label, 78, role.name) || role.name)
        .setStyle(ButtonStyle.Secondary),
    );
  }
  if (!buttons.length) return fail(res, 400, 'Nenhum dos cargos escolhidos existe mais.');

  const embed = new EmbedBuilder()
    .setColor(hexColor(body.embedColor, '#57C785'))
    .setTitle(str(body.title, 250, 'Escolha seus cargos') || 'Escolha seus cargos')
    .setDescription(str(body.description, 3800, 'Clique nos botões para pegar ou tirar um cargo.') || 'Clique nos botões para pegar ou tirar um cargo.');

  try {
    await channel.send({ embeds: [embed], components: [new ActionRowBuilder().addComponents(buttons)] });
    store.addLog(req.guildId, 'Cargos', `Painel de cargos publicado em #${channel.name}.`);
    return ok(res, `Painel de cargos publicado em #${channel.name}.`);
  } catch (err) {
    return fail(res, 500, `Não consegui publicar: ${errorMessage(err)}`);
  }
}));

// ---------------------------------------------------------------------------
// Economia
// ---------------------------------------------------------------------------

router.get('/guilds/:guildId/economy', route(async (req, res) => {
  const entries = progress.economyLeaderboard(req.guildId, 50);
  res.json({
    settings: { ...req.guildData.economy, users: undefined },
    entries: await progress.attachUsernames(client(), entries),
  });
}));

router.post('/guilds/:guildId/economy/update', (req, res) => {
  const { userId: rawId, amount, action } = req.body || {};
  const userId = cleanId(rawId);
  const value = Number(amount);

  if (!userId) return fail(res, 400, 'Informe um ID de usuário válido do Discord.');
  if (!Number.isFinite(value)) return fail(res, 400, 'Informe um valor numérico.');
  const safe = Math.max(-1e9, Math.min(1e9, value));

  let balance;
  if (action === 'add') balance = progress.addMoney(req.guildId, userId, safe);
  else if (action === 'remove') balance = progress.addMoney(req.guildId, userId, -safe);
  else if (action === 'set') balance = progress.setMoney(req.guildId, userId, safe);
  else return fail(res, 400, 'Ação inválida.');

  store.addLog(req.guildId, 'Economia', `Saldo de ${userId} agora é ${balance}.`);
  return ok(res, `Saldo atualizado para ${balance}.`, { balance });
});

router.post('/guilds/:guildId/economy/reset', (req, res) => {
  req.guildData.economy.users = {};
  store.saveNow();
  store.addLog(req.guildId, 'Economia', 'Todos os saldos foram zerados pelo painel.');
  ok(res, 'Economia zerada.');
});

// ---------------------------------------------------------------------------
// Níveis
// ---------------------------------------------------------------------------

router.get('/guilds/:guildId/levels', route(async (req, res) => {
  const entries = progress.levelLeaderboard(req.guildId, 50).map((entry) => ({
    ...entry,
    needed: progress.xpForLevel(entry.level),
  }));
  res.json({
    settings: { ...req.guildData.levels, users: undefined },
    entries: await progress.attachUsernames(client(), entries),
  });
}));

router.post('/guilds/:guildId/levels/update', (req, res) => {
  const userId = cleanId(req.body?.userId);
  if (!userId) return fail(res, 400, 'Informe um ID de usuário válido.');

  const user = progress.levelUser(req.guildId, userId);
  if (req.body.level != null && req.body.level !== '') user.level = clamp(req.body.level, 1, 999, user.level);
  if (req.body.xp != null && req.body.xp !== '') user.xp = clamp(req.body.xp, 0, 10000000, user.xp);
  store.saveNow();
  store.addLog(req.guildId, 'Níveis', `Nível de ${userId} ajustado pelo painel.`);
  return ok(res, `Nível de ${userId} atualizado.`);
});

router.post('/guilds/:guildId/levels/reset', (req, res) => {
  req.guildData.levels.users = {};
  store.saveNow();
  store.addLog(req.guildId, 'Níveis', 'Todo o XP foi zerado pelo painel.');
  ok(res, 'Ranking de XP zerado.');
});

// ---------------------------------------------------------------------------
// Música
// ---------------------------------------------------------------------------

router.get('/guilds/:guildId/music', (req, res) => {
  res.json({ queue: music.snapshot(req.guildId), engine: music.engineInfo() });
});

router.post('/guilds/:guildId/music/:action', requireReady, route(async (req, res) => {
  const action = req.params.action;
  const guild = client().guilds.cache.get(req.guildId);

  if (action === 'play') {
    const channelId = cleanId(req.body?.channelId);
    const query = str(req.body?.query, 400, '').trim();
    if (!channelId) return fail(res, 400, 'Escolha o canal de voz.');
    if (!query) return fail(res, 400, 'Diga o nome ou o link da música.');

    const channel = guild.channels.cache.get(channelId);
    if (!channel) return fail(res, 404, 'Canal de voz não encontrado.');

    const result = await music.play(guild, channel, query, null, 'painel web');
    return result.error ? fail(res, 400, result.message) : ok(res, result.message, { track: result.track });
  }

  const actions = {
    skip: () => music.skip(req.guildId),
    stop: () => music.destroy(req.guildId),
    pause: () => music.pause(req.guildId),
    resume: () => music.resume(req.guildId),
    shuffle: () => music.shuffle(req.guildId),
    clear: () => music.clear(req.guildId),
    volume: () => music.setVolume(req.guildId, req.body?.volume),
    loop: () => music.setLoop(req.guildId, req.body?.mode),
    remove: () => music.remove(req.guildId, req.body?.index),
  };

  const run = actions[action];
  if (!run) return fail(res, 400, 'Ação de música desconhecida.');

  const result = run();
  return result.error ? fail(res, 400, result.message) : ok(res, result.message);
}));

// ---------------------------------------------------------------------------
// Sorteios
// ---------------------------------------------------------------------------

router.get('/guilds/:guildId/giveaways', (req, res) => {
  const guild = client().guilds.cache.get(req.guildId);
  const list = [...req.guildData.giveaways].reverse().slice(0, 25).map((g) => ({
    id: g.id,
    prize: g.prize,
    channelId: g.channelId,
    channelName: guild.channels.cache.get(g.channelId)?.name ?? null,
    endsAt: g.endsAt,
    ended: g.ended,
    winnerCount: g.winnerCount,
    participantCount: g.participants.length,
    winners: g.winners || [],
    requiredRoleId: g.requiredRoleId || '',
    requiredLevel: g.requiredLevel || 0,
  }));
  res.json({ giveaways: list });
});

router.post('/guilds/:guildId/giveaways', requireReady, route(async (req, res) => {
  const body = req.body || {};
  const result = await giveaways.create(client(), req.guildId, {
    channelId: cleanId(body.channelId),
    prize: str(body.prize, 200, '').trim(),
    durationMs: parseDuration(body.duration),
    winnerCount: clamp(body.winnerCount, 1, 20, 1),
    requiredRoleId: cleanId(body.requiredRoleId),
    requiredLevel: clamp(body.requiredLevel, 0, 999, 0),
    createdBy: 'painel web',
  });
  return result.error ? fail(res, 400, result.message) : ok(res, result.message, { id: result.giveaway.id });
}));

router.post('/guilds/:guildId/giveaways/:giveawayId/:action', requireReady, route(async (req, res) => {
  const { giveawayId, action } = req.params;
  if (!['end', 'reroll'].includes(action)) return fail(res, 400, 'Ação inválida.');

  const result = await giveaways.end(client(), req.guildId, giveawayId, { reroll: action === 'reroll' });
  return result.error ? fail(res, 400, result.message) : ok(res, result.message, { winners: result.winners });
}));

// ---------------------------------------------------------------------------
// Comandos personalizados
// ---------------------------------------------------------------------------

router.get('/guilds/:guildId/commands', (req, res) => {
  res.json({ commands: req.guildData.customCommands });
});

router.post('/guilds/:guildId/commands', (req, res) => {
  const body = req.body || {};
  const name = str(body.name, 40, '').trim().toLowerCase().replace(/^!+/, '').replace(/\s+/g, '');
  if (!name) return fail(res, 400, 'Dê um nome ao comando.');
  if (!/^[\p{L}\p{N}_-]+$/u.test(name)) return fail(res, 400, 'Use só letras, números, - e _ no nome do comando.');

  const actions = [];
  const reply = str(body.reply, 1800, '');
  const dm = str(body.dm, 1800, '');
  const roleId = cleanId(body.roleId);
  const amount = Number(body.amount);

  if (reply.trim()) actions.push({ type: 'reply', content: reply });
  if (dm.trim()) actions.push({ type: 'send_dm', content: dm });
  if (roleId) actions.push({ type: 'add_role', roleId });
  if (Number.isFinite(amount) && amount !== 0) actions.push({ type: 'add_money', amount: clamp(amount, -1000000, 1000000, 0) });

  if (!actions.length) return fail(res, 400, 'Escolha pelo menos uma ação para o comando.');

  const isUpdate = req.guildData.customCommands.some((command) => command.name === name);
  if (!isUpdate && req.guildData.customCommands.length >= 100) return fail(res, 400, 'Limite de 100 comandos atingido.');

  req.guildData.customCommands = req.guildData.customCommands.filter((command) => command.name !== name);
  req.guildData.customCommands.push({
    name,
    actions,
    cooldown: clamp(body.cooldown, 0, 86400, 10),
    updatedAt: Date.now(),
  });
  store.saveNow();
  store.addLog(req.guildId, 'Comando', `Comando "${name}" salvo.`);
  return ok(res, `Comando salvo. Use ${req.guildData.prefix}${name} no Discord.`);
});

router.delete('/guilds/:guildId/commands/:name', (req, res) => {
  const name = String(req.params.name).toLowerCase();
  const before = req.guildData.customCommands.length;
  req.guildData.customCommands = req.guildData.customCommands.filter((command) => command.name !== name);
  if (req.guildData.customCommands.length === before) return fail(res, 404, 'Comando não encontrado.');
  store.saveNow();
  return ok(res, `Comando "${name}" apagado.`);
});

// ---------------------------------------------------------------------------
// Avisos, logs e backups
// ---------------------------------------------------------------------------

router.get('/guilds/:guildId/warns', route(async (req, res) => {
  const entries = Object.entries(req.guildData.warns).map(([userId, warns]) => ({
    userId,
    count: warns.length,
    last: warns[warns.length - 1],
  }));
  res.json({ entries: await progress.attachUsernames(client(), entries) });
}));

router.delete('/guilds/:guildId/warns/:userId', (req, res) => {
  const removed = moderation.clearWarns(req.guildId, cleanId(req.params.userId));
  ok(res, `${removed} aviso(s) apagados.`);
});

router.get('/guilds/:guildId/logs', (req, res) => {
  res.json({ logs: store.logsFor(req.guildId, clamp(req.query.limit, 10, 300, 100)) });
});

router.get('/backups', (req, res) => {
  res.json({ backups: store.listBackups() });
});

router.post('/backup', (req, res) => {
  try {
    const file = store.backup();
    ok(res, `Backup criado: ${file.split(/[\\/]/).pop()}`, { backups: store.listBackups() });
  } catch (err) {
    fail(res, 500, `Não consegui criar o backup: ${errorMessage(err)}`);
  }
});

router.get('/export', (req, res) => {
  store.saveNow();
  res.setHeader('Content-Disposition', `attachment; filename="skyebot-${Date.now()}.json"`);
  res.setHeader('Content-Type', 'application/json');
  fs.createReadStream(DB_FILE).pipe(res);
});

router.use((err, req, res, next) => {
  log.error('Erro na API:', err?.message || err);
  if (res.headersSent) return next(err);
  return fail(res, 500, 'Erro interno no painel. Veja o console do bot para detalhes.');
});

module.exports = router;
