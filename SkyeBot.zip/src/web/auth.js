'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');

const config = require('../config');
const runtime = require('../runtime');
const { log } = require('../util');

// A senha do .env é convertida em hash na inicialização, então o texto puro
// não fica guardado em memória depois disso.
const passwordHash = bcrypt.hashSync(config.panel.password, 10);

const SESSION_FILE = path.join(config.dataDir, 'sessions.json');
const SESSION_MAX_AGE = 12 * 60 * 60 * 1000;

/**
 * Sessões em arquivo: o login sobrevive a reinícios do bot (o armazenamento
 * padrão do express-session vive só na memória e vaza espaço com o tempo).
 */
class FileStore extends session.Store {
  constructor(file) {
    super();
    this.file = file;
    this.sessions = new Map();
    this.timer = null;

    try {
      const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
      for (const [sid, sess] of Object.entries(raw)) {
        if (!this.#expired(sess)) this.sessions.set(sid, sess);
      }
    } catch {
      /* primeira execução ou arquivo ilegível: começa vazio */
    }

    const sweep = setInterval(() => {
      let changed = false;
      for (const [sid, sess] of this.sessions) {
        if (this.#expired(sess)) {
          this.sessions.delete(sid);
          changed = true;
        }
      }
      if (changed) this.#queue();
    }, 600000);
    sweep.unref();
  }

  #expired(sess) {
    const expires = sess?.cookie?.expires;
    return expires ? new Date(expires).getTime() <= Date.now() : false;
  }

  #queue() {
    if (this.timer) return;
    this.timer = setTimeout(() => {
      this.timer = null;
      this.flush();
    }, 3000);
    this.timer.unref();
  }

  flush() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      const tmp = `${this.file}.${process.pid}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify(Object.fromEntries(this.sessions)), { mode: 0o600 });
      fs.renameSync(tmp, this.file);
    } catch (err) {
      log.warn('Não consegui salvar as sessões do painel:', err.message);
    }
  }

  get(sid, cb) {
    const sess = this.sessions.get(sid);
    if (!sess) return cb(null, null);
    if (this.#expired(sess)) {
      this.sessions.delete(sid);
      return cb(null, null);
    }
    return cb(null, JSON.parse(JSON.stringify(sess)));
  }

  set(sid, sess, cb) {
    this.sessions.set(sid, JSON.parse(JSON.stringify(sess)));
    this.#queue();
    if (cb) cb();
  }

  destroy(sid, cb) {
    this.sessions.delete(sid);
    this.#queue();
    if (cb) cb();
  }

  touch(sid, sess, cb) {
    const current = this.sessions.get(sid);
    if (current) {
      current.cookie = JSON.parse(JSON.stringify(sess.cookie));
      this.#queue();
    }
    if (cb) cb();
  }
}

const sessionStore = new FileStore(SESSION_FILE);

const sessionMiddleware = session({
  name: 'skye.sid',
  secret: config.panel.sessionSecret,
  store: sessionStore,
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    maxAge: SESSION_MAX_AGE,
    // Seguro quando o acesso é por https (ngrok); normal quando é por http direto.
    secure: 'auto',
  },
});

const loginLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 10,
  skipSuccessfulRequests: true, // só tentativas erradas contam
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: true, message: 'Tentativas demais. Espere 10 minutos antes de tentar de novo.' },
});

const digest = (value) => crypto.createHash('sha256').update(String(value)).digest();
const safeEqual = (a, b) => crypto.timingSafeEqual(digest(a), digest(b));

/** Bloqueia requisições que mudam dados vindas de outro site. */
function sameOrigin(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const origin = req.get('origin');
  if (!origin) return next();

  try {
    const originHost = new URL(origin).host;
    const allowed = new Set(
      [req.get('host'), String(req.get('x-forwarded-host') || '').split(',')[0].trim(), config.ngrok.domain]
        .filter(Boolean),
    );
    if (runtime.publicUrl) allowed.add(new URL(runtime.publicUrl).host);
    if (allowed.has(originHost)) return next();
  } catch {
    /* origem ilegível: cai no bloqueio abaixo */
  }
  return res.status(403).json({ error: true, message: 'Requisição bloqueada: origem não reconhecida.' });
}

function requireAuth(req, res, next) {
  if (req.session?.user) return next();
  // O router da API é montado em "/api", então req.path já vem sem esse trecho.
  if (req.originalUrl.startsWith('/api/')) {
    return res.status(401).json({ error: true, message: 'Sessão expirada. Faça login de novo.' });
  }
  return res.redirect('/login');
}

function attachRoutes(app) {
  app.post('/api/login', loginLimiter, (req, res) => {
    const { user, password } = req.body || {};

    const userOk = safeEqual(String(user || '').trim(), config.panel.user);
    const passOk = bcrypt.compareSync(String(password || '').slice(0, 200), passwordHash);

    if (!userOk || !passOk) {
      log.warn(`Login recusado para "${String(user || '').slice(0, 40)}" vindo de ${req.ip}.`);
      return res.status(401).json({ error: true, message: 'Usuário ou senha incorretos.' });
    }

    req.session.regenerate((err) => {
      if (err) return res.status(500).json({ error: true, message: 'Não foi possível abrir a sessão.' });
      req.session.user = config.panel.user;
      req.session.since = Date.now();
      log.ok(`Login do painel por ${req.ip}.`);
      res.json({ error: false, user: config.panel.user });
    });
  });

  app.post('/api/logout', (req, res) => {
    req.session.destroy(() => {
      res.clearCookie('skye.sid');
      res.json({ error: false });
    });
  });

  app.get('/api/session', (req, res) => {
    res.json({ authenticated: Boolean(req.session?.user), user: req.session?.user ?? null });
  });
}

module.exports = { sessionMiddleware, sessionStore, requireAuth, attachRoutes, sameOrigin };
