'use strict';

/** Estado compartilhado entre o bot, o painel e o túnel (só leitura fora de quem escreve). */
module.exports = {
  startedAt: Date.now(),
  port: null,
  publicUrl: null,
  directUrl: null, // http://IP:porta, quando a host expõe a porta diretamente
  tunnel: { provider: null, state: 'disabled', error: null }, // provider: ngrok | cloudflare; state: disabled | connecting | online | error
  botError: null,
  limitedIntents: [],
  generatedPassword: null,
};
