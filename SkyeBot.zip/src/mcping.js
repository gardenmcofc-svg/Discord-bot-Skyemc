'use strict';

/**
 * Consulta de status de servidor Minecraft (Server List Ping, protocolo 1.7+).
 * Implementado direto em TCP para não depender de biblioteca externa.
 * Entende registros SRV (_minecraft._tcp), como o próprio jogo faz.
 */

const net = require('net');
const dns = require('dns').promises;

const MAX_RESPONSE = 2 * 1024 * 1024; // um servidor hostil não pode encher a memória

function writeVarInt(value) {
  const bytes = [];
  let v = value >>> 0;
  do {
    let byte = v & 0x7f;
    v >>>= 7;
    if (v !== 0) byte |= 0x80;
    bytes.push(byte);
  } while (v !== 0);
  return Buffer.from(bytes);
}

function writeString(text) {
  const body = Buffer.from(text, 'utf8');
  return Buffer.concat([writeVarInt(body.length), body]);
}

function packet(id, ...parts) {
  const body = Buffer.concat([writeVarInt(id), ...parts]);
  return Buffer.concat([writeVarInt(body.length), body]);
}

/** Lê um VarInt do buffer. Devolve null se ainda faltam bytes. */
function readVarInt(buffer, offset = 0) {
  let result = 0;
  let shift = 0;
  let position = offset;
  while (true) {
    if (position >= buffer.length) return null;
    const byte = buffer[position++];
    result |= (byte & 0x7f) << shift;
    if ((byte & 0x80) === 0) break;
    shift += 7;
    if (shift > 35) throw new Error('VarInt grande demais');
  }
  return { value: result >>> 0, size: position - offset };
}

/** Tira os códigos de cor (§a, §l...) da descrição. */
function stripFormatting(text) {
  return String(text).replace(/§./g, '');
}

function flattenDescription(description) {
  if (description == null) return '';
  if (typeof description === 'string') return stripFormatting(description);
  if (Array.isArray(description)) return description.map(flattenDescription).join('');
  let out = typeof description.text === 'string' ? description.text : '';
  if (Array.isArray(description.extra)) out += description.extra.map(flattenDescription).join('');
  return stripFormatting(out);
}

/** Procura o registro SRV; sem ele, usa o endereço e a porta como vieram. */
async function resolveTarget(host, port) {
  if (net.isIP(host) || port !== 25565) return { host, port };
  try {
    const records = await Promise.race([
      dns.resolveSrv(`_minecraft._tcp.${host}`),
      new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 2500)),
    ]);
    if (records?.length) {
      const best = records.sort((a, b) => a.priority - b.priority)[0];
      return { host: best.name, port: best.port };
    }
  } catch {
    /* sem SRV: segue com o endereço direto */
  }
  return { host, port };
}

function offlineResult(error) {
  return {
    online: false,
    players: { online: 0, max: 0, sample: [] },
    version: '',
    motd: '',
    latency: 0,
    error,
    checkedAt: Date.now(),
  };
}

/**
 * @returns {Promise<{online: boolean, players: {online: number, max: number, sample: string[]}, version: string, motd: string, latency: number, error?: string}>}
 */
async function pingMinecraft(host, port = 25565, timeout = 5000) {
  const address = String(host || '').trim();
  const portNumber = Number(port) || 25565;

  if (!address) return offlineResult('Nenhum endereço configurado.');

  const target = await resolveTarget(address, portNumber);

  return new Promise((resolve) => {
    const started = Date.now();
    let settled = false;
    let chunks = Buffer.alloc(0);

    const finish = (result) => {
      if (settled) return;
      settled = true;
      socket.destroy();
      resolve(result);
    };

    const socket = net.createConnection({ host: target.host, port: target.port });
    socket.setTimeout(timeout);

    socket.on('connect', () => {
      const handshake = packet(
        0x00,
        writeVarInt(47),
        writeString(address),
        Buffer.from([(portNumber >> 8) & 0xff, portNumber & 0xff]),
        writeVarInt(1),
      );
      socket.write(handshake);
      socket.write(packet(0x00)); // status request
    });

    socket.on('data', (data) => {
      chunks = Buffer.concat([chunks, data]);
      if (chunks.length > MAX_RESPONSE) {
        finish(offlineResult('Resposta grande demais do servidor.'));
        return;
      }
      try {
        const length = readVarInt(chunks, 0);
        if (!length) return;
        const total = length.size + length.value;
        if (chunks.length < total) return;

        const packetId = readVarInt(chunks, length.size);
        const strLen = readVarInt(chunks, length.size + packetId.size);
        const start = length.size + packetId.size + strLen.size;
        const json = chunks.subarray(start, start + strLen.value).toString('utf8');
        const parsed = JSON.parse(json);

        finish({
          online: true,
          players: {
            online: Number(parsed?.players?.online) || 0,
            max: Number(parsed?.players?.max) || 0,
            sample: Array.isArray(parsed?.players?.sample)
              ? parsed.players.sample.map((p) => String(p?.name || '')).filter(Boolean).slice(0, 12)
              : [],
          },
          version: stripFormatting(parsed?.version?.name || ''),
          motd: flattenDescription(parsed?.description).trim().slice(0, 200),
          favicon: typeof parsed?.favicon === 'string' && parsed.favicon.length < 200000 ? parsed.favicon : null,
          latency: Date.now() - started,
          checkedAt: Date.now(),
        });
      } catch (err) {
        finish(offlineResult(`Resposta inválida do servidor (${err.message}).`));
      }
    });

    socket.on('timeout', () => finish(offlineResult('O servidor não respondeu a tempo.')));
    socket.on('error', (err) => {
      const reason = err.code === 'ENOTFOUND'
        ? 'Endereço não encontrado. Confira o IP.'
        : err.code === 'ECONNREFUSED'
          ? 'Conexão recusada. O servidor pode estar offline ou usar outra porta.'
          : err.message;
      finish(offlineResult(reason));
    });
  });
}

/**
 * O ícone (favicon) do servidor pesa alguns KB. Ele fica só na memória e não
 * vai para o banco de dados a cada consulta.
 */
const faviconCache = new Map();

function rememberPing(guildId, result) {
  if (result.favicon) faviconCache.set(guildId, result.favicon);
  const { favicon, ...light } = result; // eslint-disable-line no-unused-vars
  return light;
}

function faviconFor(guildId) {
  return faviconCache.get(guildId) || null;
}

module.exports = { pingMinecraft, rememberPing, faviconFor };
