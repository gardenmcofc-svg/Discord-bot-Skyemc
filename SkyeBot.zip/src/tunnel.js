'use strict';

/**
 * Acesso ao painel de qualquer lugar.
 *
 * Numa host (Pterodactyl, bot-hosting…) você não abre o painel por "localhost":
 * ou a host libera uma porta pública para o seu servidor, ou o bot precisa criar
 * um túnel. Este módulo cuida disso, em ordem:
 *
 *   1. ngrok  — se NGROK_AUTHTOKEN estiver preenchido no .env;
 *   2. cloudflare (trycloudflare.com) — não precisa de conta nem de token. É o plano B
 *      automático quando o ngrok falha de um jeito que não se resolve sozinho, e também
 *      pode ser escolhido de propósito com TUNNEL=cloudflare.
 *
 * TUNNEL=auto (padrão) | ngrok | cloudflare | off
 *
 * Depois que o túnel sobe, um vigia confere a cada minuto se o link responde de verdade
 * e reinicia o túnel se ele cair sem avisar.
 */

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { Readable } = require('stream');
const { pipeline } = require('stream/promises');

const config = require('./config');
const runtime = require('./runtime');
const { log, sleep, errorMessage } = require('./util');

const IS_WIN = process.platform === 'win32';
const BIN_DIR = path.join(config.rootDir, 'bin');
const CF_BIN = path.join(BIN_DIR, IS_WIN ? 'cloudflared.exe' : 'cloudflared');
const CF_ASSETS = {
  'linux-x64': 'cloudflared-linux-amd64',
  'linux-arm64': 'cloudflared-linux-arm64',
  'linux-arm': 'cloudflared-linux-arm',
  'win32-x64': 'cloudflared-windows-amd64.exe',
};

let port = null;
let stopping = false;
let generation = 0; // sobe a cada (re)início para descartar tentativas antigas
let ngrokListener = null;
let cloudflareChild = null;
let monitor = null;

function setState(provider, state, error = null, url) {
  runtime.tunnel.provider = provider;
  runtime.tunnel.state = state;
  runtime.tunnel.error = error;
  if (url !== undefined) runtime.publicUrl = url;
}

// ---------------------------------------------------------------------------
// ngrok
// ---------------------------------------------------------------------------

/** Erros que nenhuma nova tentativa vai resolver: só o dono do bot corrige. */
const NGROK_PERMANENT = [
  [
    /does not look like a proper|ERR_NGROK_105|ERR_NGROK_106|authentication failed|invalid.*authtoken|authtoken.*(invalid|revoked|not valid)/i,
    'O NGROK_AUTHTOKEN está errado. Copie em https://dashboard.ngrok.com/get-started/your-authtoken '
      + '(é o "Your Authtoken", não uma "API key") e cole no .env sem aspas e sem espaços.',
  ],
  [
    /ERR_NGROK_313|ERR_NGROK_314|ERR_NGROK_320|domain.*(not found|not.*reserved|not.*authorized)|not.*your.*domain/i,
    'O NGROK_DOMAIN não pertence à sua conta ngrok. Confira em dashboard.ngrok.com → Domains, ou deixe o campo vazio.',
  ],
  [
    /ERR_NGROK_108|simultaneous ngrok agent sessions|limited to 1 simultaneous/i,
    'Sua conta ngrok já tem um agente aberto em outro lugar (o plano grátis permite 1 por vez). Feche o outro ou use TUNNEL=cloudflare.',
  ],
];
/** O domínio ainda está "preso" pela sessão anterior (some sozinho em ~1 min). */
const NGROK_BUSY = /ERR_NGROK_334|already online/i;
const NETWORK = /timeout|timed out|ENOTFOUND|ECONN|EAI_AGAIN|EHOSTUNREACH|ENETUNREACH|dial|network|i\/o|tls handshake|connection (reset|refused|closed)/i;

function classifyNgrok(message) {
  for (const [pattern, text] of NGROK_PERMANENT) {
    if (pattern.test(message)) return { kind: 'permanent', text };
  }
  if (NGROK_BUSY.test(message)) {
    return { kind: 'busy', text: 'O domínio ainda está preso pela sessão anterior do ngrok (normal logo após reiniciar).' };
  }
  if (NETWORK.test(message)) return { kind: 'network', text: `Sem conexão com o ngrok (${message}).` };
  return { kind: 'unknown', text: message };
}

/** @returns {Promise<boolean>} true se o túnel subiu */
async function startNgrok(run) {
  let ngrok;
  try {
    ngrok = require('@ngrok/ngrok');
  } catch (err) {
    setState('ngrok', 'error', `Biblioteca do ngrok indisponível: ${errorMessage(err)}`);
    log.warn(runtime.tunnel.error);
    return false;
  }

  setState('ngrok', 'connecting');
  const maxAttempts = 8;

  for (let attempt = 1; attempt <= maxAttempts && !stopping && run === generation; attempt++) {
    try {
      ngrokListener = await ngrok.forward({
        addr: port,
        authtoken: config.ngrok.authtoken,
        domain: config.ngrok.domain || undefined,
      });
      if (stopping || run !== generation) {
        await ngrokListener.close().catch(() => {});
        return false;
      }
      setState('ngrok', 'online', null, ngrokListener.url());
      log.ok(`Painel público (ngrok): ${runtime.publicUrl}`);
      return true;
    } catch (err) {
      const raw = errorMessage(err);
      const { kind, text } = classifyNgrok(raw);
      runtime.tunnel.error = text;

      const giveUp = kind === 'permanent' || (kind === 'unknown' && attempt >= 2) || attempt === maxAttempts;
      if (giveUp) {
        setState('ngrok', 'error', text);
        log.warn(`ngrok: ${text}`);
        return false;
      }
      const wait = Math.min(60, (kind === 'busy' ? 10 : 8) * attempt);
      log.warn(`ngrok: ${text} Nova tentativa em ${wait}s (${attempt}/${maxAttempts})…`);
      await sleep(wait * 1000);
    }
  }
  return false;
}

// ---------------------------------------------------------------------------
// Cloudflare (trycloudflare.com) — sem conta, sem token
// ---------------------------------------------------------------------------

async function ensureCloudflared() {
  if (fs.existsSync(CF_BIN)) return;

  const asset = CF_ASSETS[`${process.platform}-${process.arch}`];
  if (!asset) throw new Error(`Não há cloudflared para ${process.platform}/${process.arch}.`);

  log.info('Baixando o cloudflared (túnel sem conta), só desta vez…');
  fs.mkdirSync(BIN_DIR, { recursive: true });
  const tmp = `${CF_BIN}.download`;
  const response = await fetch(`https://github.com/cloudflare/cloudflared/releases/latest/download/${asset}`, {
    redirect: 'follow',
    signal: AbortSignal.timeout(240000),
  });
  if (!response.ok || !response.body) throw new Error(`Download recusado (HTTP ${response.status}).`);
  await pipeline(Readable.fromWeb(response.body), fs.createWriteStream(tmp));
  fs.chmodSync(tmp, 0o755);
  fs.renameSync(tmp, CF_BIN);
}

/** Uma execução do cloudflared, do início até ele encerrar. */
function runCloudflared(run) {
  return new Promise((resolve) => {
    const child = spawn(
      CF_BIN,
      // http2 usa TCP; o padrão (quic) usa UDP, que muitas hosts bloqueiam.
      ['tunnel', '--no-autoupdate', '--protocol', 'http2', '--url', `http://127.0.0.1:${port}`],
      { stdio: ['ignore', 'ignore', 'pipe'], detached: !IS_WIN },
    );
    cloudflareChild = child;
    let gotUrl = false;
    let tail = '';

    child.stderr.on('data', (chunk) => {
      const text = chunk.toString();
      tail = (tail + text).slice(-1200);
      // "api.trycloudflare.com" aparece em mensagens de erro e não é o link do painel.
      const found = text.match(/https:\/\/(?!api\.)[a-z0-9-]+\.trycloudflare\.com/i);
      if (found && !gotUrl && run === generation) {
        gotUrl = true;
        setState('cloudflare', 'online', null, found[0]);
        log.ok(`Painel público (cloudflare): ${found[0]}`);
      }
    });
    child.on('error', (err) => resolve({ gotUrl: false, tail: err.message }));
    child.on('close', () => {
      if (cloudflareChild === child) cloudflareChild = null;
      resolve({ gotUrl, tail });
    });
  });
}

async function startCloudflare(run) {
  setState('cloudflare', 'connecting');
  try {
    await ensureCloudflared();
  } catch (err) {
    setState('cloudflare', 'error', `Não consegui baixar o cloudflared: ${errorMessage(err)}`);
    log.warn(runtime.tunnel.error);
    return false;
  }

  let failures = 0;
  while (!stopping && run === generation) {
    const { gotUrl, tail } = await runCloudflared(run);
    if (stopping || run !== generation) break;

    if (gotUrl) failures = 0; // funcionou por um tempo e caiu: recomeça a contagem
    else failures += 1;

    const reason = /429|too many requests|rate.?limit/i.test(tail)
      ? 'O Cloudflare limitou os pedidos de túnel deste IP; vou tentar de novo daqui a pouco.'
      : tail.trim().split('\n').filter(Boolean).at(-1)?.slice(0, 160) || 'o túnel encerrou';

    if (failures >= 6) {
      setState('cloudflare', 'error', `O túnel não subiu depois de várias tentativas: ${reason}`);
      log.warn(runtime.tunnel.error);
      return false;
    }
    setState('cloudflare', 'connecting', reason, null);
    const wait = Math.min(60, 8 * (failures + 1));
    log.warn(`cloudflare: ${reason} Reiniciando o túnel em ${wait}s…`);
    await sleep(wait * 1000);
  }
  return false;
}

// ---------------------------------------------------------------------------
// Orquestração
// ---------------------------------------------------------------------------

async function launch() {
  const run = ++generation;
  const mode = config.tunnel.mode;
  runtime.publicUrl = null;

  if (mode === 'off') {
    setState(null, 'disabled');
    return;
  }

  const wantsNgrok = mode === 'ngrok' || (mode === 'auto' && config.ngrok.authtoken);
  if (mode === 'ngrok' && !config.ngrok.authtoken) {
    setState('ngrok', 'error', 'TUNNEL=ngrok, mas o NGROK_AUTHTOKEN está vazio no .env.');
    log.warn(runtime.tunnel.error);
    return;
  }

  if (wantsNgrok) {
    if (await startNgrok(run)) return;
    // Com TUNNEL=ngrok o dono pediu só o ngrok: não troca de provedor por conta própria.
    if (mode !== 'auto' || stopping || run !== generation) return;
    log.warn('Vou usar o plano B: túnel do Cloudflare (sem conta), para você conseguir abrir o painel.');
  } else if (mode === 'auto') {
    setState(null, 'disabled');
    return; // sem ngrok configurado e sem pedido explícito: não expõe o painel por conta própria
  }

  await startCloudflare(run);
}

/** Endereço que a host expõe diretamente, para quem tem porta liberada. */
async function discoverDirectUrl() {
  try {
    const response = await fetch('https://api.ipify.org', { signal: AbortSignal.timeout(4000) });
    const ip = (await response.text()).trim();
    if (/^[\d.]+$/.test(ip) || /^[0-9a-f:]+$/i.test(ip)) {
      runtime.directUrl = `http://${ip}:${port}`;
      log.info(`Endereço direto do painel: ${runtime.directUrl} (só abre se a host liberou a porta ${port} para você).`);
    }
  } catch {
    /* sem internet de saída ou serviço fora do ar: só não mostra a dica */
  }
}

/** Confere de tempos em tempos se o link público realmente chega no painel. */
function startMonitor() {
  let misses = 0;
  let sinceOnline = 0;
  monitor = setInterval(async () => {
    if (stopping || runtime.tunnel.state !== 'online' || !runtime.publicUrl) {
      sinceOnline = 0;
      return;
    }
    sinceOnline += 1;
    if (sinceOnline < 2) return; // dá tempo ao DNS do link novo

    try {
      const response = await fetch(`${runtime.publicUrl}/healthz`, {
        headers: { 'ngrok-skip-browser-warning': '1' },
        signal: AbortSignal.timeout(12000),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      misses = 0;
    } catch (err) {
      misses += 1;
      log.warn(`O link público não respondeu (${errorMessage(err)}) — ${misses}/3.`);
      if (misses >= 3) {
        misses = 0;
        sinceOnline = 0;
        log.warn('Reiniciando o túnel…');
        await closeProviders();
        launch().catch((e) => log.warn('Túnel:', errorMessage(e)));
      }
    }
  }, 60000);
  monitor.unref();
}

async function closeProviders() {
  generation += 1; // invalida tentativas em andamento
  try {
    await ngrokListener?.close();
  } catch { /* já caiu */ }
  ngrokListener = null;

  const child = cloudflareChild;
  cloudflareChild = null;
  if (child && child.exitCode === null) {
    try {
      if (!IS_WIN && child.pid) process.kill(-child.pid, 'SIGKILL');
      else child.kill('SIGKILL');
    } catch { /* já encerrou */ }
  }
  runtime.publicUrl = null;
}

async function start(panelPort) {
  port = panelPort;
  stopping = false;
  discoverDirectUrl();
  startMonitor();
  await launch();
}

async function stop() {
  stopping = true;
  clearInterval(monitor);
  await closeProviders();
}

module.exports = { start, stop, classifyNgrok };
