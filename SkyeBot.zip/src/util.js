'use strict';

const COLORS = {
  reset: '\x1b[0m',
  dim: '\x1b[2m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
};

function stamp() {
  return new Date().toLocaleTimeString('pt-BR', { hour12: false });
}

const log = {
  info: (...a) => console.log(`${COLORS.dim}${stamp()}${COLORS.reset} ${COLORS.blue}info${COLORS.reset} `, ...a),
  ok: (...a) => console.log(`${COLORS.dim}${stamp()}${COLORS.reset} ${COLORS.green}ok  ${COLORS.reset} `, ...a),
  warn: (...a) => console.warn(`${COLORS.dim}${stamp()}${COLORS.reset} ${COLORS.yellow}aviso${COLORS.reset}`, ...a),
  error: (...a) => console.error(`${COLORS.dim}${stamp()}${COLORS.reset} ${COLORS.red}erro${COLORS.reset} `, ...a),
  bot: (...a) => console.log(`${COLORS.dim}${stamp()}${COLORS.reset} ${COLORS.magenta}bot ${COLORS.reset} `, ...a),
};

/** IDs do Discord têm 17 a 20 dígitos. */
function isSnowflake(id) {
  return typeof id === 'string' && /^\d{17,20}$/.test(id.trim());
}

/** Devolve o ID limpo ou string vazia — nunca lança. */
function cleanId(id) {
  const value = String(id ?? '').trim().replace(/[<>@#&!]/g, '');
  return isSnowflake(value) ? value : '';
}

function clamp(value, min, max, fallback = min) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.trunc(n)));
}

function str(value, maxLength, fallback = '') {
  if (typeof value !== 'string') return fallback;
  return value.slice(0, maxLength);
}

/** Aceita "10m", "2h30m", "1d", "45s" ou um número em segundos. */
function parseDuration(input) {
  if (typeof input === 'number' && Number.isFinite(input)) return Math.max(0, input * 1000);
  const text = String(input || '').trim().toLowerCase();
  if (!text) return 0;
  if (/^\d+$/.test(text)) return Number(text) * 1000;

  const units = { s: 1000, m: 60000, h: 3600000, d: 86400000, w: 604800000 };
  let total = 0;
  let matched = false;
  for (const [, amount, unit] of text.matchAll(/(\d+)\s*([smhdw])/g)) {
    total += Number(amount) * units[unit];
    matched = true;
  }
  return matched ? total : 0;
}

function formatDuration(ms) {
  if (!ms || ms < 0) return '0s';
  const parts = [];
  const units = [
    ['d', 86400000],
    ['h', 3600000],
    ['m', 60000],
    ['s', 1000],
  ];
  let rest = ms;
  for (const [label, size] of units) {
    const value = Math.floor(rest / size);
    if (value > 0) {
      parts.push(`${value}${label}`);
      rest -= value * size;
    }
  }
  return parts.slice(0, 2).join(' ') || '0s';
}

const NUMBER_FORMAT = new Intl.NumberFormat('pt-BR');
const formatNumber = (value) => NUMBER_FORMAT.format(Math.round(Number(value) || 0));

/**
 * Substitui as variáveis dos textos configuráveis.
 * Aceita membro/guild ausentes sem quebrar.
 */
function applyVariables(text, { member, guild, extra } = {}) {
  if (typeof text !== 'string' || !text) return '';
  const user = member?.user ?? member;

  const values = {
    '{user}': member?.id ? `<@${member.id}>` : '@usuário',
    '{user.name}': user?.username ?? 'usuário',
    '{user.tag}': user?.tag ?? user?.username ?? 'usuário',
    '{user.id}': member?.id ?? '0',
    '{user.avatar}': typeof member?.displayAvatarURL === 'function' ? member.displayAvatarURL() : '',
    '{server.name}': guild?.name ?? 'servidor',
    '{server.id}': guild?.id ?? '0',
    '{member_count}': guild?.memberCount != null ? String(guild.memberCount) : '0',
    '{date}': new Date().toLocaleDateString('pt-BR'),
    '{time}': new Date().toLocaleTimeString('pt-BR'),
    ...(extra || {}),
  };

  return text.replace(/\{[a-z_.]+\}/gi, (token) => (token in values ? values[token] : token));
}

/** Evita que @everyone/@here escapem em textos vindos do painel. */
function escapeMentions(text) {
  return String(text ?? '').replace(/@(everyone|here)/g, '@\u200b$1');
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * O membro do próprio bot ("guild.members.me"), garantido completo.
 *
 * Se o discord.js ainda não tiver o membro do bot em cache, ele cria um
 * "membro parcial" (com o partial de GuildMember ligado nas intents) que não
 * tem cargos nenhum — e checar permissões nesse objeto faz o bot parecer sem
 * nenhuma permissão, mesmo quando o cargo dele tem tudo liberado no servidor.
 * Esta função busca o membro de verdade nesse caso, e guarda por pouco tempo
 * para não bater na API do Discord toda hora.
 */
const botMemberCache = new Map(); // guildId -> { member, at }
const BOT_MEMBER_TTL = 20000;

async function getBotMember(guild) {
  const cached = botMemberCache.get(guild.id);
  if (cached && !cached.member.partial && Date.now() - cached.at < BOT_MEMBER_TTL) return cached.member;

  let member = guild.members.me;
  if (!member || member.partial) {
    member = await guild.members.fetchMe().catch(() => member || null);
  }
  if (member && !member.partial) botMemberCache.set(guild.id, { member, at: Date.now() });
  return member;
}

/** Texto curto e legível de qualquer erro, sem despejar o stack no usuário. */
function errorMessage(err) {
  if (!err) return 'erro desconhecido';
  return String(err.message || err).split('\n')[0].slice(0, 300);
}

/** Normaliza para comparar texto sem se importar com acento ou maiúscula. */
function foldText(text) {
  return String(text ?? '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

function chunk(array, size) {
  const out = [];
  for (let i = 0; i < array.length; i += size) out.push(array.slice(i, i + size));
  return out;
}

module.exports = {
  log,
  isSnowflake,
  cleanId,
  clamp,
  str,
  parseDuration,
  formatDuration,
  formatNumber,
  applyVariables,
  escapeMentions,
  sleep,
  chunk,
  errorMessage,
  foldText,
  getBotMember,
};
