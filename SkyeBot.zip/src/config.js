'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const rootDir = path.join(__dirname, '..');
const dataDir = path.join(rootDir, 'data');

// Carrega o .env da pasta do projeto, não importa de onde o processo foi iniciado.
require('dotenv').config({ path: path.join(rootDir, '.env') });

function bool(value, fallback = false) {
  if (value === undefined || value === '') return fallback;
  return ['1', 'true', 'yes', 'sim', 'on'].includes(String(value).toLowerCase());
}

/** Tira aspas, espaços e o "Bot " que muita gente cola junto com o token. */
function cleanSecret(value) {
  return String(value || '')
    .trim()
    .replace(/^["']|["']$/g, '')
    .replace(/^Bot\s+/i, '')
    .trim();
}

/** Aceita o token puro OU o comando inteiro que o painel do ngrok mostra ("ngrok config add-authtoken XXXX"). */
function cleanNgrokToken(value) {
  let token = String(value || '').trim();
  const fromCommand = token.match(/add-authtoken\s+(\S+)/i);
  if (fromCommand) token = fromCommand[1];
  return token
    .replace(/^NGROK_AUTHTOKEN\s*=\s*/i, '')
    .replace(/["'`\s]/g, '');
}

/** Segredos gerados automaticamente ficam salvos, para não mudarem a cada reinício. */
const SECRETS_FILE = path.join(dataDir, 'secrets.json');
function loadSecrets() {
  try {
    return JSON.parse(fs.readFileSync(SECRETS_FILE, 'utf8')) || {};
  } catch {
    return {};
  }
}
function persistSecret(name, generate) {
  const secrets = loadSecrets();
  let created = false;
  if (!secrets[name]) {
    secrets[name] = generate();
    created = true;
    try {
      fs.mkdirSync(dataDir, { recursive: true });
      fs.writeFileSync(SECRETS_FILE, JSON.stringify(secrets, null, 2), { mode: 0o600 });
    } catch {
      /* sem permissão de escrita: o valor vale só até reiniciar */
    }
  }
  return { value: secrets[name], created };
}

const explicitPassword = process.env.PANEL_PASSWORD || '';
const generatedPassword = explicitPassword
  ? null
  : persistSecret('panelPassword', () => crypto.randomBytes(9).toString('base64url'));

const sessionSecret = process.env.SESSION_SECRET
  ? process.env.SESSION_SECRET
  : persistSecret('sessionSecret', () => crypto.randomBytes(32).toString('hex')).value;

const config = {
  // Hosts com painel (Pterodactyl) entregam a porta liberada em SERVER_PORT.
  port: Number(process.env.SERVER_PORT) || Number(process.env.PORT) || 8080,
  portFixedByHost: Boolean(process.env.SERVER_PORT),
  rootDir,
  dataDir,

  discord: {
    token: cleanSecret(process.env.DISCORD_TOKEN),
    clientId: cleanSecret(process.env.CLIENT_ID),
    devGuildId: cleanSecret(process.env.DEV_GUILD_ID),
    ownerIds: (process.env.OWNER_IDS || '')
      .split(',')
      .map((id) => id.trim())
      .filter(Boolean),
  },

  panel: {
    user: (process.env.PANEL_USER || 'admin').trim() || 'admin',
    password: explicitPassword || generatedPassword.value,
    passwordWasGenerated: Boolean(generatedPassword),
    sessionSecret,
    trustProxy: bool(process.env.TRUST_PROXY, true),
  },

  tunnel: {
    // auto = ngrok se houver token (e plano B sem conta se ele falhar) | ngrok | cloudflare | off
    mode: ['auto', 'ngrok', 'cloudflare', 'off'].includes(String(process.env.TUNNEL || 'auto').trim().toLowerCase())
      ? String(process.env.TUNNEL || 'auto').trim().toLowerCase()
      : 'auto',
  },

  ngrok: {
    authtoken: cleanNgrokToken(process.env.NGROK_AUTHTOKEN),
    // Aceita "https://nome.ngrok-free.app/" e devolve só "nome.ngrok-free.app".
    domain: String(process.env.NGROK_DOMAIN || '')
      .trim()
      .replace(/^https?:\/\//i, '')
      .replace(/\/.*$/, ''),
  },
};

/** Problemas que impedem o funcionamento, e avisos que não impedem. */
config.validate = function validate() {
  const errors = [];
  const warnings = [];

  const token = config.discord.token;
  if (!token) {
    warnings.push('DISCORD_TOKEN está vazio no .env — o painel abre, mas o bot não entra no Discord.');
  } else if (token.split('.').length !== 3) {
    warnings.push('O DISCORD_TOKEN não parece um token de bot (deveria ter 3 partes separadas por ponto). Confira se copiou inteiro.');
  }

  if (!config.discord.clientId) {
    warnings.push('CLIENT_ID vazio: os comandos de barra (/) não serão registrados.');
  } else if (!/^\d{17,20}$/.test(config.discord.clientId)) {
    warnings.push('CLIENT_ID deveria ser só números (o "Application ID" do Developer Portal).');
  }

  if (config.panel.password.length < 8) {
    warnings.push('PANEL_PASSWORD tem menos de 8 caracteres. Use uma senha mais longa.');
  }
  if (process.env.TUNNEL && !['auto', 'ngrok', 'cloudflare', 'off'].includes(String(process.env.TUNNEL).trim().toLowerCase())) {
    warnings.push('TUNNEL no .env deve ser auto, ngrok, cloudflare ou off. Usando "auto".');
  }
  if (config.ngrok.authtoken && config.ngrok.authtoken.length < 30) {
    warnings.push('NGROK_AUTHTOKEN parece curto demais para um authtoken. Copie de novo em dashboard.ngrok.com/get-started/your-authtoken.');
  }

  return { errors, warnings };
};

module.exports = config;
