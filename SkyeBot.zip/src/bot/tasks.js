'use strict';

/** Agendador único para tudo que tem prazo: enquetes, lembretes e tickets parados. */

const { log, errorMessage } = require('../util');
const polls = require('./polls');
const reminders = require('./reminders');
const tickets = require('./tickets');

let timer = null;
let running = false;

function start(client) {
  stop();
  const run = async () => {
    if (running) return; // evita rodadas empilhadas se o Discord estiver lento
    running = true;
    try {
      const jobs = { enquetes: polls.tick, lembretes: reminders.tick, tickets: tickets.sweepInactive };
      for (const [name, job] of Object.entries(jobs)) {
        try {
          await job(client);
        } catch (err) {
          log.warn(`Tarefa "${name}":`, errorMessage(err));
        }
      }
    } finally {
      running = false;
    }
  };
  timer = setInterval(run, 20000);
  timer.unref?.();
  run();
}

function stop() {
  if (timer) clearInterval(timer);
  timer = null;
}

module.exports = { start, stop };
