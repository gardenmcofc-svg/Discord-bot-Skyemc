'use strict';

const { store } = require('../store');
const { log, errorMessage, formatDuration, escapeMentions } = require('../util');

const MIN_MS = 10000;
const MAX_MS = 365 * 86400000;
const MAX_PER_USER = 10;

const data = (guildId) => store.guild(guildId);

function create({ guildId, userId, channelId, durationMs, text, dm }) {
  const clean = String(text || '').trim().slice(0, 500);
  if (!clean) return { error: true, message: 'Diga do que devo lembrar você.' };
  if (durationMs < MIN_MS || durationMs > MAX_MS) {
    return { error: true, message: 'O tempo deve ficar entre 10 segundos e 1 ano (ex: 30m, 2h, 1d).' };
  }

  const guildData = data(guildId);
  if (guildData.reminders.filter((r) => r.userId === userId).length >= MAX_PER_USER) {
    return { error: true, message: `Você já tem ${MAX_PER_USER} lembretes ativos. Cancele algum antes.` };
  }

  guildData.reminderSeq += 1;
  const reminder = {
    id: guildData.reminderSeq,
    userId,
    channelId,
    at: Date.now() + durationMs,
    text: clean,
    dm: Boolean(dm),
  };
  guildData.reminders.push(reminder);
  store.save();
  return {
    error: false,
    reminder,
    message: `Combinado! Lembro você em ${formatDuration(durationMs)} (<t:${Math.floor(reminder.at / 1000)}:R>).`,
  };
}

const listFor = (guildId, userId) => data(guildId).reminders.filter((r) => r.userId === userId);

function cancel(guildId, userId, id) {
  const guildData = data(guildId);
  const index = guildData.reminders.findIndex((r) => r.id === Number(id) && r.userId === userId);
  if (index < 0) return { error: true, message: 'Não encontrei um lembrete seu com esse número.' };
  guildData.reminders.splice(index, 1);
  store.save();
  return { error: false, message: `Lembrete #${id} cancelado.` };
}

async function deliver(client, reminder) {
  const content = `⏰ <@${reminder.userId}> lembrete: ${escapeMentions(reminder.text)}`;
  if (reminder.dm) {
    const user = await client.users.fetch(reminder.userId).catch(() => null);
    const sent = await user?.send(content).then(() => true).catch(() => false);
    if (sent) return;
  }
  const channel = await client.channels.fetch(reminder.channelId).catch(() => null);
  await channel?.send?.({ content, allowedMentions: { users: [reminder.userId] } }).catch((err) =>
    log.warn('Não consegui entregar o lembrete:', errorMessage(err)),
  );
}

async function tick(client) {
  for (const guildId of Object.keys(store.data.guilds)) {
    const guildData = store.guild(guildId);
    const due = guildData.reminders.filter((r) => r.at <= Date.now());
    if (!due.length) continue;
    guildData.reminders = guildData.reminders.filter((r) => r.at > Date.now());
    store.save();
    for (const reminder of due) await deliver(client, reminder);
  }
}

module.exports = { create, listFor, cancel, tick };
