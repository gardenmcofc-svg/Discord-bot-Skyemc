'use strict';

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
} = require('discord.js');

const { store } = require('../store');
const { log, formatDuration } = require('../util');
const { levelUser } = require('./progress');

const ENTER_PREFIX = 'giveaway:enter:';
const CHECK_INTERVAL = 15000;

let timer = null;
const busy = new Set();

function findGiveaway(guildId, giveawayId) {
  return store.guild(guildId).giveaways.find((g) => g.id === giveawayId) || null;
}

function buildEmbed(giveaway, guild) {
  const embed = new EmbedBuilder()
    .setTitle('🎉 Sorteio em andamento')
    .setColor('#E8B84B')
    .setDescription(
      [
        `**Prêmio:** ${giveaway.prize}`,
        `**Ganhadores:** ${giveaway.winnerCount}`,
        `**Termina:** <t:${Math.floor(giveaway.endsAt / 1000)}:R>`,
        giveaway.requiredRoleId ? `**Cargo obrigatório:** <@&${giveaway.requiredRoleId}>` : null,
        giveaway.requiredLevel ? `**Nível mínimo:** ${giveaway.requiredLevel}` : null,
        '',
        'Clique no botão abaixo para participar.',
      ]
        .filter(Boolean)
        .join('\n'),
    )
    .setFooter({ text: `${giveaway.participants.length} participando · ${guild?.name ?? ''}` });
  return embed;
}

function buildRow(giveaway, disabled = false) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`${ENTER_PREFIX}${giveaway.id}`)
      .setLabel(disabled ? 'Sorteio encerrado' : '🎉 Participar')
      .setStyle(ButtonStyle.Success)
      .setDisabled(disabled),
  );
}

async function create(client, guildId, options) {
  const guild = await client.guilds.fetch(guildId).catch(() => null);
  if (!guild) return { error: true, message: 'Servidor não encontrado.' };

  const channel = await client.channels.fetch(options.channelId).catch(() => null);
  if (!channel?.isTextBased()) return { error: true, message: 'Canal do sorteio não encontrado.' };

  const duration = Number(options.durationMs);
  if (!duration || duration < 30000) {
    return { error: true, message: 'A duração precisa ser de pelo menos 30 segundos.' };
  }
  if (!options.prize) return { error: true, message: 'Descreva o prêmio do sorteio.' };

  const giveaway = {
    id: `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
    channelId: channel.id,
    messageId: null,
    prize: String(options.prize).slice(0, 200),
    winnerCount: Math.max(1, Math.min(20, Number(options.winnerCount) || 1)),
    endsAt: Date.now() + duration,
    createdBy: options.createdBy || null,
    requiredRoleId: options.requiredRoleId || '',
    requiredLevel: Math.max(0, Number(options.requiredLevel) || 0),
    participants: [],
    ended: false,
    winners: [],
  };

  try {
    const message = await channel.send({
      embeds: [buildEmbed(giveaway, guild)],
      components: [buildRow(giveaway)],
    });
    giveaway.messageId = message.id;
    store.guild(guildId).giveaways.push(giveaway);
    store.save(0);
    store.addLog(guildId, 'Sorteio criado', `"${giveaway.prize}" em #${channel.name} (${formatDuration(duration)}).`);
    return { error: false, message: `Sorteio publicado em #${channel.name}.`, giveaway };
  } catch (err) {
    return { error: true, message: `Não consegui publicar o sorteio: ${err.message}` };
  }
}

async function enter(interaction) {
  const giveawayId = interaction.customId.slice(ENTER_PREFIX.length);
  const giveaway = findGiveaway(interaction.guild.id, giveawayId);

  if (!giveaway || giveaway.ended || giveaway.endsAt <= Date.now()) {
    return interaction.reply({ content: 'Este sorteio já foi encerrado.', flags: MessageFlags.Ephemeral });
  }
  if (giveaway.participants.includes(interaction.user.id)) {
    return interaction.reply({ content: 'Você já está participando.', flags: MessageFlags.Ephemeral });
  }
  if (giveaway.requiredRoleId && !interaction.member.roles.cache.has(giveaway.requiredRoleId)) {
    return interaction.reply({
      content: `Este sorteio é só para quem tem <@&${giveaway.requiredRoleId}>.`,
      flags: MessageFlags.Ephemeral,
    });
  }
  if (giveaway.requiredLevel > 0) {
    const level = levelUser(interaction.guild.id, interaction.user.id).level;
    if (level < giveaway.requiredLevel) {
      return interaction.reply({
        content: `Você precisa ser nível ${giveaway.requiredLevel} para entrar (você está no ${level}).`,
        flags: MessageFlags.Ephemeral,
      });
    }
  }

  giveaway.participants.push(interaction.user.id);
  store.save();

  await interaction.reply({ content: 'Entrada confirmada. Boa sorte!', flags: MessageFlags.Ephemeral });
  refreshMessage(interaction.client, interaction.guild.id, giveaway).catch(() => {});
}

async function refreshMessage(client, guildId, giveaway) {
  const channel = await client.channels.fetch(giveaway.channelId).catch(() => null);
  const message = await channel?.messages.fetch(giveaway.messageId).catch(() => null);
  if (!message) return;
  const guild = client.guilds.cache.get(guildId);
  await message.edit({ embeds: [buildEmbed(giveaway, guild)], components: [buildRow(giveaway)] }).catch(() => {});
}

function drawWinners(giveaway, count) {
  const pool = [...giveaway.participants];
  const winners = [];
  while (winners.length < count && pool.length) {
    const index = Math.floor(Math.random() * pool.length);
    winners.push(pool.splice(index, 1)[0]);
  }
  return winners;
}

async function end(client, guildId, giveawayId, { reroll = false } = {}) {
  const giveaway = findGiveaway(guildId, giveawayId);
  if (!giveaway) return { error: true, message: 'Sorteio não encontrado.' };
  if (giveaway.ended && !reroll) return { error: true, message: 'Este sorteio já foi encerrado.' };
  // Evita anúncio duplicado quando o agendador e um clique manual coincidem.
  if (busy.has(giveaway.id)) return { error: true, message: 'Este sorteio já está sendo encerrado.' };
  busy.add(giveaway.id);
  try {
    return await finish(client, guildId, giveaway, reroll);
  } finally {
    busy.delete(giveaway.id);
  }
}

async function finish(client, guildId, giveaway, reroll) {

  const channel = await client.channels.fetch(giveaway.channelId).catch(() => null);
  if (!channel?.isTextBased()) {
    giveaway.ended = true;
    store.save(0);
    return { error: true, message: 'O canal do sorteio não existe mais.' };
  }

  // No resorteio, evita repetir quem já ganhou enquanto houver outros participantes.
  const previous = reroll ? new Set(giveaway.winners || []) : new Set();
  let winners = drawWinners({ participants: giveaway.participants.filter((id) => !previous.has(id)) }, giveaway.winnerCount);
  if (reroll && !winners.length) winners = drawWinners(giveaway, giveaway.winnerCount);
  giveaway.ended = true;
  giveaway.winners = winners;
  store.save(0);

  const message = await channel.messages.fetch(giveaway.messageId).catch(() => null);
  if (message) {
    const embed = EmbedBuilder.from(message.embeds[0] ?? buildEmbed(giveaway, channel.guild))
      .setTitle(reroll ? '🎉 Sorteio resorteado' : '🎉 Sorteio encerrado')
      .setColor('#57C785')
      .setDescription(
        [
          `**Prêmio:** ${giveaway.prize}`,
          `**Participantes:** ${giveaway.participants.length}`,
          winners.length
            ? `**Ganhador(es):** ${winners.map((id) => `<@${id}>`).join(', ')}`
            : '**Ninguém participou.**',
        ].join('\n'),
      );
    await message.edit({ embeds: [embed], components: [buildRow(giveaway, true)] }).catch(() => {});
  }

  await channel
    .send(
      winners.length
        ? `🎊 Parabéns ${winners.map((id) => `<@${id}>`).join(', ')}! Vocês ganharam **${giveaway.prize}**.`
        : `Ninguém participou do sorteio de **${giveaway.prize}**.`,
    )
    .catch(() => {});

  store.addLog(
    guildId,
    reroll ? 'Sorteio resorteado' : 'Sorteio encerrado',
    `"${giveaway.prize}" — ${winners.length} ganhador(es) entre ${giveaway.participants.length} participantes.`,
  );
  return { error: false, message: 'Sorteio finalizado.', winners };
}

/** Verifica periodicamente os sorteios vencidos, inclusive os que venceram
 *  enquanto o bot estava desligado. */
function startScheduler(client) {
  if (timer) clearInterval(timer);
  timer = setInterval(async () => {
    const now = Date.now();
    for (const [guildId, guildData] of Object.entries(store.data.guilds)) {
      for (const giveaway of guildData.giveaways || []) {
        if (!giveaway.ended && giveaway.endsAt <= now) {
          await end(client, guildId, giveaway.id).catch((err) => log.error('Sorteio:', err.message));
        }
      }
      // Guarda apenas os 25 registros mais recentes por servidor.
      if (guildData.giveaways?.length > 25) {
        guildData.giveaways = guildData.giveaways.slice(-25);
        store.save();
      }
    }
  }, CHECK_INTERVAL);
  if (typeof timer.unref === 'function') timer.unref();
}

function stopScheduler() {
  if (timer) clearInterval(timer);
  timer = null;
}

module.exports = { create, enter, end, startScheduler, stopScheduler, ENTER_PREFIX };
