'use strict';

const {
  joinVoiceChannel,
  createAudioPlayer,
  createAudioResource,
  entersState,
  AudioPlayerStatus,
  VoiceConnectionStatus,
  NoSubscriberBehavior,
  StreamType,
} = require('@discordjs/voice');
const { ChannelType, EmbedBuilder } = require('discord.js');

const { log, errorMessage, getBotMember } = require('../util');
const audio = require('./audio');

const ACCENT = 0x57c785;
const EMPTY_CHANNEL_TIMEOUT = 120000;

/** guildId -> fila */
const queues = new Map();

function createQueue(guild, voiceChannel, textChannel) {
  const queue = {
    guildId: guild.id,
    guildName: guild.name,
    voiceChannelId: voiceChannel.id,
    voiceChannelName: voiceChannel.name,
    textChannel,
    connection: null,
    player: createAudioPlayer({ behaviors: { noSubscriber: NoSubscriberBehavior.Pause } }),
    songs: [],
    current: null,
    volume: 0.6,
    loop: 'off', // off | song | queue
    paused: false,
    skipping: false,
    destroyed: false,
    stopStream: null,
    emptyTimer: null,
  };
  queues.set(guild.id, queue);
  return queue;
}

function getQueue(guildId) {
  return queues.get(guildId) || null;
}

function say(queue, content) {
  if (!queue.textChannel?.send) return;
  queue.textChannel.send(content).catch(() => {});
}

function releaseStream(queue) {
  try {
    queue.stopStream?.();
  } catch {
    /* processo já encerrou */
  }
  queue.stopStream = null;
}

async function play(guild, voiceChannel, query, textChannel = null, requestedBy = null) {
  if (!voiceChannel || voiceChannel.type !== ChannelType.GuildVoice) {
    return { error: true, message: 'Esse canal não é um canal de voz.' };
  }
  if (!audio.ffmpegOk) {
    return { error: true, message: 'O ffmpeg não está disponível nesta host, então a música não funciona.' };
  }

  const me = await getBotMember(guild);
  if (!me) {
    return { error: true, message: 'Não consegui confirmar meu próprio cargo neste servidor. Tente de novo em alguns segundos.' };
  }

  const missing = [];
  const chanPerms = voiceChannel.permissionsFor(me);
  if (!chanPerms?.has('ViewChannel')) missing.push('Ver canal');
  if (!chanPerms?.has('Connect')) missing.push('Conectar');
  if (!chanPerms?.has('Speak')) missing.push('Falar');

  if (missing.length) {
    // O cargo do bot pode ter tudo liberado no servidor e ainda assim ser bloqueado
    // só naquele canal (ou na categoria dele) por uma permissão específica — é o caso
    // mais comum de "o bot tem todas as permissões e mesmo assim não entra".
    const hasOnServer = me.permissions.has(missing.map((label) =>
      ({ 'Ver canal': 'ViewChannel', Conectar: 'Connect', Falar: 'Speak' }[label])));
    const where = voiceChannel.parent ? `o canal "${voiceChannel.name}" ou a categoria "${voiceChannel.parent.name}"` : `o canal "${voiceChannel.name}"`;
    const message = hasOnServer
      ? `O cargo do bot tem ${missing.join(' e ')} liberado no servidor, mas ${where} tem uma permissão específica bloqueando isso. Clique no canal de voz → ⚙️ Editar canal → Permissões, e libere ${missing.join(' e ')} para o cargo do bot (ou para @everyone, se preferir).`
      : `Faltam estas permissões para o bot: ${missing.join(', ')}. Vá em Configurações do servidor → Cargos → cargo do bot, e libere Conectar e Falar.`;
    return { error: true, message };
  }

  const resolved = await audio.resolve(query);
  if (resolved.error) return { error: true, message: resolved.error };

  const tracks = resolved.tracks.map((track) => ({ ...track, requestedBy }));

  let queue = getQueue(guild.id);
  const fresh = !queue;
  if (!queue) queue = createQueue(guild, voiceChannel, textChannel);
  else if (textChannel) queue.textChannel = textChannel;

  queue.songs.push(...tracks);

  if (fresh) {
    try {
      const connection = joinVoiceChannel({
        channelId: voiceChannel.id,
        guildId: guild.id,
        adapterCreator: guild.voiceAdapterCreator,
        selfDeaf: true,
      });
      queue.connection = connection;
      connection.subscribe(queue.player);

      // Reconecta sozinho quando o Discord move o bot de canal.
      connection.on(VoiceConnectionStatus.Disconnected, async () => {
        try {
          await Promise.race([
            entersState(connection, VoiceConnectionStatus.Signalling, 5000),
            entersState(connection, VoiceConnectionStatus.Connecting, 5000),
          ]);
        } catch {
          destroy(guild.id);
        }
      });

      // Quando o áudio dá erro o player também vai para "Idle", então só o Idle avança a fila.
      queue.player.on(AudioPlayerStatus.Idle, () => advance(guild.id));
      queue.player.on('error', (err) => {
        log.error(`Player (${guild.name}):`, err.message);
        say(queue, `⚠️ Erro ao tocar **${queue.current?.title ?? 'a faixa'}**. Passando para a próxima.`);
      });

      await entersState(connection, VoiceConnectionStatus.Ready, 20000);
      await startNext(guild.id);
      return {
        error: false,
        message: resolved.playlistName
          ? `Playlist "${resolved.playlistName}" na fila: ${tracks.length} faixas.`
          : `Tocando agora: ${tracks[0].title}`,
        track: tracks[0],
      };
    } catch (err) {
      log.error('Falha ao conectar na call:', errorMessage(err));
      destroy(guild.id);
      return { error: true, message: 'Não consegui entrar no canal de voz. Verifique as permissões do bot.' };
    }
  }

  const message = resolved.playlistName
    ? `${tracks.length} faixas da playlist "${resolved.playlistName}" foram adicionadas.`
    : `**${tracks[0].title}** entrou na fila (posição ${queue.songs.length}).`;
  say(queue, `🎵 ${message}`);
  return { error: false, message, track: tracks[0] };
}

async function startNext(guildId) {
  const queue = getQueue(guildId);
  if (!queue || queue.destroyed) return;

  releaseStream(queue);
  const track = queue.songs.shift();
  if (!track) {
    queue.current = null;
    say(queue, '🎶 Fila terminada. Saindo do canal de voz.');
    destroy(guildId);
    return;
  }

  queue.current = track;
  try {
    const opened = await audio.openStream(track.url);
    if (queue.destroyed) {
      opened.kill();
      return;
    }
    queue.stopStream = opened.kill;

    const resource = createAudioResource(opened.stream, {
      inputType: StreamType.Arbitrary,
      inlineVolume: true,
    });
    resource.volume?.setVolume(queue.volume);
    queue.player.play(resource);
    queue.paused = false;

    const embed = new EmbedBuilder()
      .setColor(ACCENT)
      .setTitle('▶️ Tocando agora')
      .setDescription(`**[${track.title}](${track.url})**`)
      .addFields(
        { name: 'Duração', value: track.durationText || '—', inline: true },
        { name: 'Na fila', value: String(queue.songs.length), inline: true },
      );
    if (track.thumbnail) embed.setThumbnail(track.thumbnail);
    if (track.requestedBy) embed.setFooter({ text: `Pedido por ${track.requestedBy}` });
    if (queue.textChannel?.send) queue.textChannel.send({ embeds: [embed] }).catch(() => {});
  } catch (err) {
    const reason = audio.explain(errorMessage(err)) || errorMessage(err);
    log.error(`Não foi possível iniciar "${track.title}":`, reason);
    say(queue, `⚠️ Não consegui tocar **${track.title}**: ${reason}`);
    queue.current = null;
    setTimeout(() => startNext(guildId), 500).unref?.();
  }
}

function advance(guildId) {
  const queue = getQueue(guildId);
  if (!queue || queue.destroyed) return;

  // Um pulo manual nunca deve repetir a faixa que acabou de sair.
  const skipping = queue.skipping;
  queue.skipping = false;

  if (!skipping && queue.loop === 'song' && queue.current) {
    queue.songs.unshift(queue.current);
  } else if (queue.loop === 'queue' && queue.current) {
    queue.songs.push(queue.current);
  }
  startNext(guildId);
}

function skip(guildId) {
  const queue = getQueue(guildId);
  if (!queue || !queue.current) return { error: true, message: 'Não há nada tocando.' };
  const title = queue.current.title;
  queue.skipping = true;
  queue.player.stop();
  return { error: false, message: `**${title}** foi pulada.` };
}

function pause(guildId) {
  const queue = getQueue(guildId);
  if (!queue || !queue.current) return { error: true, message: 'Não há nada tocando.' };
  if (queue.paused) return { error: true, message: 'A música já está pausada.' };
  queue.player.pause();
  queue.paused = true;
  return { error: false, message: 'Música pausada.' };
}

function resume(guildId) {
  const queue = getQueue(guildId);
  if (!queue || !queue.paused) return { error: true, message: 'Não há música pausada.' };
  queue.player.unpause();
  queue.paused = false;
  return { error: false, message: 'Música retomada.' };
}

function setVolume(guildId, percent) {
  const queue = getQueue(guildId);
  if (!queue) return { error: true, message: 'O bot não está tocando.' };
  const value = Math.min(150, Math.max(0, Number(percent) || 0));
  queue.volume = value / 100;
  queue.player.state?.resource?.volume?.setVolume(queue.volume);
  return { error: false, message: `Volume em ${value}%.` };
}

function setLoop(guildId, mode) {
  const queue = getQueue(guildId);
  if (!queue) return { error: true, message: 'O bot não está tocando.' };
  if (!['off', 'song', 'queue'].includes(mode)) return { error: true, message: 'Modo de repetição inválido.' };
  queue.loop = mode;
  const labels = { off: 'desligada', song: 'repetindo a faixa atual', queue: 'repetindo a fila inteira' };
  return { error: false, message: `Repetição ${labels[mode]}.` };
}

function shuffle(guildId) {
  const queue = getQueue(guildId);
  if (!queue || queue.songs.length < 2) return { error: true, message: 'A fila é curta demais para embaralhar.' };
  for (let i = queue.songs.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [queue.songs[i], queue.songs[j]] = [queue.songs[j], queue.songs[i]];
  }
  return { error: false, message: 'Fila embaralhada.' };
}

function remove(guildId, index) {
  const queue = getQueue(guildId);
  const position = Number(index);
  if (!queue || !queue.songs[position - 1]) return { error: true, message: 'Não existe faixa nessa posição.' };
  const [removed] = queue.songs.splice(position - 1, 1);
  return { error: false, message: `**${removed.title}** saiu da fila.` };
}

function clear(guildId) {
  const queue = getQueue(guildId);
  if (!queue || !queue.songs.length) return { error: true, message: 'A fila já está vazia.' };
  const count = queue.songs.length;
  queue.songs = [];
  return { error: false, message: `${count} faixa(s) removidas da fila.` };
}

function destroy(guildId) {
  const queue = getQueue(guildId);
  if (!queue) return { error: true, message: 'O bot não está em nenhum canal de voz.' };
  queue.destroyed = true;
  if (queue.emptyTimer) clearTimeout(queue.emptyTimer);
  releaseStream(queue);
  try {
    queue.player.stop(true);
  } catch { /* o player já pode estar parado */ }
  try {
    queue.connection?.destroy();
  } catch { /* a conexão já pode ter caído */ }
  queues.delete(guildId);
  return { error: false, message: 'Player encerrado e bot desconectado.' };
}

/** Sai sozinho quando o canal fica vazio, e limpa a fila se o bot for tirado da call. */
function handleVoiceUpdate(oldState, newState) {
  const guildId = oldState.guild.id;
  const queue = getQueue(guildId);
  if (!queue) return;

  const botId = oldState.guild.client.user?.id;
  if (newState.id === botId) {
    if (!newState.channelId) {
      destroy(guildId);
      return;
    }
    if (newState.channelId !== queue.voiceChannelId) {
      queue.voiceChannelId = newState.channelId;
      queue.voiceChannelName = newState.channel?.name ?? queue.voiceChannelName;
    }
  }

  const channel = oldState.guild.channels.cache.get(queue.voiceChannelId);
  if (!channel) return;

  const humans = channel.members.filter((m) => !m.user.bot).size;
  if (humans === 0 && !queue.emptyTimer) {
    queue.emptyTimer = setTimeout(() => {
      const current = getQueue(guildId);
      if (!current) return;
      current.emptyTimer = null;
      const stillEmpty = channel.members.filter((m) => !m.user.bot).size === 0;
      if (stillEmpty) {
        say(current, '👋 Ninguém ficou na call, então saí para economizar recursos.');
        destroy(guildId);
      }
    }, EMPTY_CHANNEL_TIMEOUT);
    queue.emptyTimer.unref?.();
  } else if (humans > 0 && queue.emptyTimer) {
    clearTimeout(queue.emptyTimer);
    queue.emptyTimer = null;
  }
}

/** Resumo seguro para o painel (sem objetos do discord.js). */
function snapshot(guildId) {
  const queue = getQueue(guildId);
  if (!queue) return null;
  return {
    voiceChannelName: queue.voiceChannelName,
    current: queue.current,
    upcoming: queue.songs.slice(0, 15),
    total: queue.songs.length,
    volume: Math.round(queue.volume * 100),
    loop: queue.loop,
    paused: queue.paused,
    elapsed: queue.player.state?.resource?.playbackDuration ?? 0,
  };
}

function destroyAll() {
  for (const guildId of [...queues.keys()]) destroy(guildId);
}

module.exports = {
  play,
  skip,
  pause,
  resume,
  setVolume,
  setLoop,
  shuffle,
  remove,
  clear,
  destroy,
  destroyAll,
  getQueue,
  snapshot,
  handleVoiceUpdate,
  initEngine: audio.init,
  engineInfo: audio.engineInfo,
};
