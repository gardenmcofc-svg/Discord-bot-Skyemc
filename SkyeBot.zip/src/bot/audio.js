'use strict';

/**
 * Motor de áudio: acha músicas e abre o stream.
 *
 * O YouTube muda as proteções toda hora e as bibliotecas de download quebram.
 * Por isso o caminho principal é o yt-dlp (o programa mais bem mantido para
 * isso): o bot baixa o executável sozinho na primeira vez e o atualiza a cada
 * poucos dias. Se ele não estiver disponível, cai para o ytdl-core.
 *
 * Se o YouTube bloquear o IP da host ("confirme que você não é um robô"),
 * coloque um arquivo cookies.txt (exportado do navegador) na pasta do bot.
 */

const fs = require('fs');
const path = require('path');
const { spawn, spawnSync } = require('child_process');
const { PassThrough, Readable } = require('stream');
const { pipeline } = require('stream/promises');

const ytdl = require('@distube/ytdl-core');
const YouTube = require('youtube-sr').default;

const config = require('../config');
const { log, errorMessage } = require('../util');

const BIN_DIR = path.join(config.rootDir, 'bin');
const IS_WIN = process.platform === 'win32';
const BIN_FILE = path.join(BIN_DIR, IS_WIN ? 'yt-dlp.exe' : 'yt-dlp');
const COOKIES_FILE = path.join(config.rootDir, 'cookies.txt');
const MAX_AGE = 3 * 86400000;

const ASSETS = {
  'linux-x64': 'yt-dlp_linux',
  'linux-arm64': 'yt-dlp_linux_aarch64',
  'win32-x64': 'yt-dlp.exe',
  'darwin-x64': 'yt-dlp_macos',
  'darwin-arm64': 'yt-dlp_macos',
};

const ytdlp = { ready: false, version: null, error: null, jsRuntime: false, working: false };

// ---------------------------------------------------------------------------
// ffmpeg
// ---------------------------------------------------------------------------

function setupFfmpeg() {
  try {
    const ffmpegPath = require('ffmpeg-static');
    if (ffmpegPath && fs.existsSync(ffmpegPath)) {
      process.env.FFMPEG_PATH = ffmpegPath;
      return true;
    }
  } catch {
    /* segue para o ffmpeg do sistema */
  }
  const system = spawnSync('ffmpeg', ['-version'], { timeout: 5000 });
  return system.status === 0;
}
const ffmpegOk = setupFfmpeg();
if (!ffmpegOk) log.warn('ffmpeg não encontrado: a música não vai funcionar nesta host.');

// ---------------------------------------------------------------------------
// Instalação e atualização do yt-dlp
// ---------------------------------------------------------------------------

function probe(args = []) {
  const result = spawnSync(BIN_FILE, [...args, '--version'], { timeout: 30000, encoding: 'utf8' });
  return result.status === 0 ? String(result.stdout).trim() : null;
}

async function download() {
  const asset = ASSETS[`${process.platform}-${process.arch}`];
  if (!asset) throw new Error(`Sem executável do yt-dlp para ${process.platform}/${process.arch}.`);

  fs.mkdirSync(BIN_DIR, { recursive: true });
  const tmp = `${BIN_FILE}.download`;
  const response = await fetch(`https://github.com/yt-dlp/yt-dlp/releases/latest/download/${asset}`, {
    redirect: 'follow',
    signal: AbortSignal.timeout(180000),
  });
  if (!response.ok || !response.body) throw new Error(`Download recusado (HTTP ${response.status}).`);

  await pipeline(Readable.fromWeb(response.body), fs.createWriteStream(tmp));
  fs.chmodSync(tmp, 0o755);
  fs.renameSync(tmp, BIN_FILE);
}

/** Roda em segundo plano na inicialização; nunca derruba o bot. */
async function init() {
  try {
    let stale = true;
    if (fs.existsSync(BIN_FILE)) {
      stale = Date.now() - fs.statSync(BIN_FILE).mtimeMs > MAX_AGE;
      ytdlp.version = probe();
      ytdlp.ready = Boolean(ytdlp.version);
    }

    if (!ytdlp.ready || stale) {
      log.info(ytdlp.ready ? 'Atualizando o yt-dlp…' : 'Baixando o yt-dlp (motor de música)…');
      try {
        await download();
        ytdlp.version = probe();
        ytdlp.ready = Boolean(ytdlp.version);
        if (ytdlp.ready) log.ok(`yt-dlp ${ytdlp.version} pronto.`);
      } catch (err) {
        if (!ytdlp.ready) throw err;
        log.warn(`Não consegui atualizar o yt-dlp (${errorMessage(err)}); usando a versão atual.`);
      }
    } else {
      log.ok(`yt-dlp ${ytdlp.version} pronto.`);
    }

    // Versões novas precisam de um runtime JavaScript; o Node já está aqui.
    if (ytdlp.ready) ytdlp.jsRuntime = probe(['--js-runtimes', 'node']) !== null;
    ytdlp.error = ytdlp.ready ? null : 'yt-dlp não executou nesta host.';
  } catch (err) {
    ytdlp.ready = false;
    ytdlp.error = errorMessage(err);
    log.warn(`yt-dlp indisponível (${ytdlp.error}). A música usará o ytdl-core, que é menos estável.`);
  }
}

/** Mata o processo e tudo que ele abriu (o executável do yt-dlp cria um processo filho). */
function killTree(child) {
  if (!child || child.exitCode !== null || child.signalCode) return;
  try {
    if (!IS_WIN && child.pid) process.kill(-child.pid, 'SIGKILL');
    else child.kill('SIGKILL');
  } catch {
    try { child.kill('SIGKILL'); } catch { /* já encerrou */ }
  }
}

function baseArgs() {
  const args = ['--no-warnings', '--no-cache-dir', '--socket-timeout', '20'];
  if (ytdlp.jsRuntime) args.push('--js-runtimes', 'node');
  if (fs.existsSync(COOKIES_FILE)) args.push('--cookies', COOKIES_FILE);
  return args;
}

function engineInfo() {
  return {
    ytdlp: ytdlp.ready ? ytdlp.version : null,
    ytdlpError: ytdlp.ready ? null : ytdlp.error,
    cookies: fs.existsSync(COOKIES_FILE),
    ffmpeg: ffmpegOk,
  };
}

// ---------------------------------------------------------------------------
// Busca e metadados
// ---------------------------------------------------------------------------

function clock(ms) {
  const total = Math.max(0, Math.round((ms || 0) / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = String(total % 60).padStart(2, '0');
  return h ? `${h}:${String(m).padStart(2, '0')}:${s}` : `${m}:${s}`;
}

function fromSr(video) {
  return {
    title: video.title || 'Sem título',
    url: video.url,
    duration: video.duration || 0,
    durationText: video.durationFormatted || clock(video.duration),
    thumbnail: video.thumbnail?.url || null,
    author: video.channel?.name || '',
  };
}

function fromYtdlp(entry) {
  const id = entry.id || '';
  const url = entry.webpage_url || (/^https?:/.test(entry.url || '') ? entry.url : `https://www.youtube.com/watch?v=${id}`);
  const ms = Math.round((Number(entry.duration) || 0) * 1000);
  return {
    title: entry.title || 'Sem título',
    url,
    duration: ms,
    durationText: entry.duration_string || clock(ms),
    thumbnail: entry.thumbnail || entry.thumbnails?.at(-1)?.url || null,
    author: entry.channel || entry.uploader || '',
  };
}

function runJson(args, timeoutMs = 45000) {
  return new Promise((resolve, reject) => {
    const child = spawn(BIN_FILE, [...baseArgs(), '--dump-single-json', '--skip-download', ...args], {
      stdio: ['ignore', 'pipe', 'pipe'],
      detached: !IS_WIN,
    });
    let out = '';
    let err = '';
    let timedOut = false;
    const timer = setTimeout(() => {
      timedOut = true;
      killTree(child);
    }, timeoutMs);
    child.stdout.on('data', (chunk) => { out += chunk; });
    child.stderr.on('data', (chunk) => { err = (err + chunk).slice(-2000); });
    child.on('error', (e) => { clearTimeout(timer); reject(e); });
    child.on('close', (code) => {
      clearTimeout(timer);
      if (timedOut) return reject(new Error('O YouTube demorou demais para responder. Tente de novo.'));
      if (code !== 0) return reject(new Error(explain(err) || `yt-dlp saiu com código ${code}`));
      try {
        return resolve(JSON.parse(out));
      } catch {
        return reject(new Error('Resposta ilegível do yt-dlp.'));
      }
    });
  });
}

const isYoutubeUrl = (text) => /^https?:\/\/((www|m|music)\.)?(youtube\.com|youtu\.be)\//i.test(text);
const isPlaylistUrl = (text) => /[?&]list=/.test(text) && (!/[?&]v=/.test(text) || /\/playlist\?/.test(text));

/** @returns {Promise<{tracks?: object[], playlistName?: string, error?: string}>} */
async function resolve(query) {
  const text = String(query || '').trim();
  if (!text) return { error: 'Diga o nome ou cole o link da música.' };

  try {
    if (isPlaylistUrl(text)) return await resolvePlaylist(text);
    if (/^https?:\/\//i.test(text)) return await resolveUrl(text);
    return await resolveSearch(text);
  } catch (err) {
    log.error('Busca de música falhou:', errorMessage(err));
    return { error: explain(errorMessage(err)) || 'A busca falhou. Tente de novo em alguns segundos.' };
  }
}

async function resolvePlaylist(url) {
  try {
    const playlist = await YouTube.getPlaylist(url, { fetchAll: true, limit: 60 });
    const videos = (playlist?.videos || []).filter((v) => v?.url);
    if (videos.length) return { tracks: videos.map(fromSr), playlistName: playlist.title };
  } catch {
    /* tenta o yt-dlp */
  }
  if (ytdlp.ready) {
    const data = await runJson(['--flat-playlist', '--playlist-end', '60', url], 90000);
    const tracks = (data.entries || []).filter(Boolean).map(fromYtdlp);
    if (tracks.length) return { tracks, playlistName: data.title || 'Playlist' };
  }
  return { error: 'Essa playlist está vazia, é privada ou não consegui lê-la.' };
}

async function resolveUrl(url) {
  if (isYoutubeUrl(url)) {
    try {
      return { tracks: [fromSr(await YouTube.getVideo(url))] };
    } catch {
      /* tenta o yt-dlp */
    }
  }
  if (ytdlp.ready) {
    const data = await runJson(['--no-playlist', url]);
    return { tracks: [fromYtdlp(data)] };
  }
  if (isYoutubeUrl(url)) {
    // Sem metadados, mas o link ainda toca.
    return { tracks: [{ title: url, url, duration: 0, durationText: '—', thumbnail: null, author: '' }] };
  }
  return { error: 'Só consigo tocar links do YouTube (o yt-dlp não está disponível para outros sites).' };
}

async function resolveSearch(text) {
  try {
    const results = await YouTube.search(text, { limit: 1, type: 'video', safeSearch: false });
    if (results?.length) return { tracks: [fromSr(results[0])] };
  } catch {
    /* tenta o yt-dlp */
  }
  if (ytdlp.ready) {
    const data = await runJson(['--flat-playlist', `ytsearch1:${text}`]);
    const entry = data.entries?.[0];
    if (entry) return { tracks: [fromYtdlp(entry)] };
  }
  return { error: `Nada encontrado para "${text}".` };
}

// ---------------------------------------------------------------------------
// Stream de áudio
// ---------------------------------------------------------------------------

/** Traduz mensagens técnicas em algo que o dono do bot consiga agir. */
function explain(raw) {
  const text = String(raw || '');
  if (/sign in to confirm|not a bot|confirm you.re not/i.test(text)) {
    return 'O YouTube bloqueou o IP desta host (pediu login). Coloque um arquivo cookies.txt na pasta do bot para liberar.';
  }
  if (/private video|members-only|video unavailable|has been removed/i.test(text)) return 'Esse vídeo está indisponível ou é privado.';
  if (/age.restricted|confirm your age/i.test(text)) return 'Vídeo com restrição de idade (só toca com cookies.txt de uma conta logada).';
  if (/HTTP Error 429|too many requests/i.test(text)) return 'O YouTube limitou os pedidos desta host. Tente de novo em alguns minutos.';
  return text.split('\n').filter(Boolean).at(-1)?.slice(0, 200) || '';
}

/** Espera o primeiro pedaço de áudio chegar, para saber que o stream é de verdade. */
function firstData(stream, { child = null, timeout = 30000 } = {}) {
  return new Promise((resolve, reject) => {
    let stderr = '';
    if (child) child.stderr.on('data', (chunk) => { stderr = (stderr + chunk).slice(-2000); });

    const cleanup = () => {
      clearTimeout(timer);
      stream.off('data', onData);
      stream.off('error', onError);
      stream.off('end', onEnd);
    };
    const onData = (chunk) => {
      cleanup();
      stream.pause();
      stream.unshift(chunk);
      resolve();
    };
    const onError = (err) => { cleanup(); reject(err); };
    const onEnd = () => {
      cleanup();
      // Dá um instante para o stderr do processo chegar completo.
      setTimeout(() => reject(new Error(explain(stderr) || 'O stream terminou sem enviar áudio.')), 150);
    };
    const timer = setTimeout(() => { cleanup(); reject(new Error('Tempo esgotado abrindo o áudio.')); }, timeout);

    stream.on('data', onData);
    stream.once('error', onError);
    stream.once('end', onEnd);
  });
}

async function openWithYtdlp(url) {
  const child = spawn(BIN_FILE, [...baseArgs(), '--no-playlist', '-f', 'bestaudio/best', '-o', '-', '--no-part', url], {
    stdio: ['ignore', 'pipe', 'pipe'],
    detached: !IS_WIN,
  });
  const out = new PassThrough({ highWaterMark: 1 << 22 });
  child.stdout.pipe(out);
  child.on('error', (err) => out.destroy(err));
  child.stdin?.on?.('error', () => {});

  const kill = () => killTree(child);
  try {
    await firstData(out, { child });
  } catch (err) {
    kill();
    throw err;
  }
  return { stream: out, kill, engine: 'yt-dlp' };
}

async function openWithYtdlCore(url) {
  const stream = ytdl(url, {
    filter: 'audioonly',
    quality: 'highestaudio',
    highWaterMark: 1 << 25,
    dlChunkSize: 0,
  });
  try {
    await firstData(stream);
  } catch (err) {
    stream.destroy();
    throw err;
  }
  return { stream, kill: () => stream.destroy(), engine: 'ytdl-core' };
}

/** @returns {Promise<{stream: import('stream').Readable, kill: Function, engine: string}>} */
async function openStream(url) {
  let firstError = null;

  if (ytdlp.ready) {
    try {
      return await openWithYtdlp(url);
    } catch (err) {
      firstError = err;
      log.warn(`yt-dlp falhou (${errorMessage(err)}). Tentando o ytdl-core…`);
    }
  }

  try {
    return await openWithYtdlCore(url);
  } catch (err) {
    // A mensagem do yt-dlp costuma ser mais útil (ex.: pedido de cookies).
    throw firstError || err;
  }
}

module.exports = { init, resolve, openStream, engineInfo, explain, clock, ffmpegOk };
