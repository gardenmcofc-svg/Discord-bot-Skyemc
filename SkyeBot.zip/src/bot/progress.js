'use strict';

const { store } = require('../store');
const { applyVariables, formatNumber, log, getBotMember } = require('../util');

// ---------------------------------------------------------------------------
// Níveis
// ---------------------------------------------------------------------------

/** XP total necessário para sair do nível informado. Cresce de forma suave. */
function xpForLevel(level) {
  return 5 * level * level + 50 * level + 100;
}

function levelUser(guildId, userId) {
  const levels = store.guild(guildId).levels;
  levels.users[userId] ||= { xp: 0, level: 1, messages: 0, lastMessage: 0 };
  return levels.users[userId];
}

/** Chamado a cada mensagem. Respeita o tempo de espera para evitar farm de XP. */
async function grantMessageXp(message) {
  const guildData = store.guild(message.guild.id);
  const settings = guildData.levels;
  guildData.stats.messages += 1;

  if (!settings.enabled) return;
  if (settings.noXpChannelIds.includes(message.channel.id)) return;

  const user = levelUser(message.guild.id, message.author.id);
  const now = Date.now();
  user.messages += 1;

  if (now - user.lastMessage < settings.cooldownSeconds * 1000) {
    store.save(5000);
    return;
  }
  user.lastMessage = now;

  const min = Math.min(settings.xpMin, settings.xpMax);
  const max = Math.max(settings.xpMin, settings.xpMax);
  user.xp += Math.floor(Math.random() * (max - min + 1)) + min;

  let leveledUp = false;
  while (user.xp >= xpForLevel(user.level)) {
    user.xp -= xpForLevel(user.level);
    user.level += 1;
    leveledUp = true;
  }
  store.save();

  if (!leveledUp) return;

  // Cargos de recompensa: entrega todos os que o membro já alcançou
  // (cobre o caso de pular vários níveis de uma vez).
  const me = await getBotMember(message.guild);
  for (const reward of settings.rewards) {
    if (!reward.roleId || Number(reward.level) > user.level) continue;
    if (message.member.roles.cache.has(reward.roleId)) continue;
    const role = message.guild.roles.cache.get(reward.roleId);
    if (role && me && me.roles.highest.comparePositionTo(role) > 0) {
      await message.member.roles.add(role, `Recompensa do nível ${reward.level}`).catch(() => {});
    }
  }

  if (!settings.announce) return;
  const text = applyVariables(settings.announceMessage, {
    member: message.member,
    guild: message.guild,
    extra: { '{level}': String(user.level), '{xp}': String(user.xp) },
  });
  const target = settings.announceChannelId
    ? message.guild.channels.cache.get(settings.announceChannelId)
    : message.channel;
  target?.send?.(text).catch(() => {});
}

function levelLeaderboard(guildId, limit = 10) {
  const users = store.guild(guildId).levels.users;
  return Object.entries(users)
    .map(([userId, info]) => ({ userId, ...info, totalXp: totalXp(info) }))
    .sort((a, b) => b.totalXp - a.totalXp)
    .slice(0, limit);
}

function totalXp(info) {
  let sum = Number(info.xp) || 0;
  for (let level = 1; level < (info.level || 1); level++) sum += xpForLevel(level);
  return sum;
}

function levelRank(guildId, userId) {
  const board = Object.entries(store.guild(guildId).levels.users)
    .map(([id, info]) => ({ id, totalXp: totalXp(info) }))
    .sort((a, b) => b.totalXp - a.totalXp);
  const index = board.findIndex((entry) => entry.id === userId);
  return { position: index === -1 ? null : index + 1, total: board.length };
}

// ---------------------------------------------------------------------------
// Economia
// ---------------------------------------------------------------------------

const MAX_BALANCE = 1e12;

function account(guildId, userId) {
  const economy = store.guild(guildId).economy;
  economy.users[userId] ||= { balance: 0, bank: 0, lastDaily: 0, lastWork: 0 };
  return economy.users[userId];
}

function currencyLabel(guildId) {
  const economy = store.guild(guildId).economy;
  return { name: economy.currency, emoji: economy.currencyEmoji };
}

function addMoney(guildId, userId, amount) {
  const wallet = account(guildId, userId);
  wallet.balance = Math.min(MAX_BALANCE, Math.max(0, Math.round(wallet.balance + Number(amount || 0))));
  store.save();
  return wallet.balance;
}

function setMoney(guildId, userId, amount) {
  const wallet = account(guildId, userId);
  wallet.balance = Math.min(MAX_BALANCE, Math.max(0, Math.round(Number(amount) || 0)));
  store.save();
  return wallet.balance;
}

function transfer(guildId, fromId, toId, amount) {
  const value = Math.round(Number(amount) || 0);
  if (value <= 0) return { error: true, message: 'Informe um valor maior que zero.' };
  if (fromId === toId) return { error: true, message: 'Você não pode transferir para si mesmo.' };

  const from = account(guildId, fromId);
  if (from.balance < value) {
    return { error: true, message: `Saldo insuficiente. Você tem ${formatNumber(from.balance)}.` };
  }
  from.balance -= value;
  account(guildId, toId).balance += value;
  store.save();
  return { error: false, message: `Transferência de ${formatNumber(value)} concluída.` };
}

function claimDaily(guildId, userId) {
  const economy = store.guild(guildId).economy;
  const wallet = account(guildId, userId);
  const now = Date.now();
  const nextAt = wallet.lastDaily + 86400000;

  if (now < nextAt) {
    return { error: true, message: 'Você já pegou o bônus de hoje.', retryAt: nextAt };
  }
  wallet.lastDaily = now;
  wallet.balance += economy.dailyAmount;
  store.save();
  return { error: false, amount: economy.dailyAmount, balance: wallet.balance };
}

function work(guildId, userId) {
  const economy = store.guild(guildId).economy;
  const wallet = account(guildId, userId);
  const now = Date.now();
  const nextAt = wallet.lastWork + economy.workCooldownMinutes * 60000;

  if (now < nextAt) {
    return { error: true, message: 'Você ainda está descansando.', retryAt: nextAt };
  }
  const min = Math.min(economy.workMin, economy.workMax);
  const max = Math.max(economy.workMin, economy.workMax);
  const earned = Math.floor(Math.random() * (max - min + 1)) + min;

  wallet.lastWork = now;
  wallet.balance += earned;
  store.save();
  return { error: false, amount: earned, balance: wallet.balance };
}

function economyLeaderboard(guildId, limit = 10) {
  return Object.entries(store.guild(guildId).economy.users)
    .map(([userId, wallet]) => ({ userId, ...wallet }))
    .sort((a, b) => b.balance - a.balance)
    .slice(0, limit);
}

/** Resolve nomes para as tabelas do painel sem derrubar tudo se um usuário sumir. */
async function attachUsernames(client, entries) {
  return Promise.all(
    entries.map(async (entry) => {
      try {
        const user = await client.users.fetch(entry.userId);
        return { ...entry, tag: user.tag, avatar: user.displayAvatarURL({ size: 64 }) };
      } catch {
        return { ...entry, tag: 'usuário desconhecido', avatar: null };
      }
    }),
  ).catch((err) => {
    log.error('Falha ao buscar usuários:', err.message);
    return entries;
  });
}

module.exports = {
  xpForLevel,
  levelUser,
  grantMessageXp,
  levelLeaderboard,
  levelRank,
  totalXp,
  account,
  currencyLabel,
  addMoney,
  setMoney,
  transfer,
  claimDaily,
  work,
  economyLeaderboard,
  attachUsernames,
};
