'use strict';

const {
  Client,
  GatewayIntentBits,
  Partials,
  Events,
  EmbedBuilder,
  ActivityType,
  ChannelType,
  MessageFlags,
  PermissionsBitField,
} = require('discord.js');

const config = require('../config');
const runtime = require('../runtime');
const { store } = require('../store');
const { log, applyVariables, escapeMentions, formatNumber, errorMessage, getBotMember } = require('../util');
const { pingMinecraft, rememberPing } = require('../mcping');

const music = require('./music');
const progress = require('./progress');
const moderation = require('./moderation');
const tickets = require('./tickets');
const giveaways = require('./giveaways');
const suggestions = require('./suggestions');
const polls = require('./polls');
const tasks = require('./tasks');
const commands = require('./commands');

/** O cliente atual. Pode ser recriado se o Discord recusar as intents privilegiadas. */
let client = null;
let statusTimer = null;
let presenceTimer = null;
let retryTimer = null;
let shuttingDown = false;

const PRIVILEGED = [GatewayIntentBits.MessageContent, GatewayIntentBits.GuildMembers];

function buildClient({ limited }) {
  const intents = [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildModeration,
  ];
  if (!limited) intents.push(...PRIVILEGED);

  const instance = new Client({
    intents,
    partials: [Partials.Channel, Partials.GuildMember],
    allowedMentions: { parse: ['users', 'roles'], repliedUser: false },
  });
  attachHandlers(instance);
  return instance;
}

// ---------------------------------------------------------------------------
// Pronto
// ---------------------------------------------------------------------------

function attachHandlers(c) {
  c.once(Events.ClientReady, async (ready) => {
    log.bot(`Conectado como ${ready.user.tag} em ${ready.guilds.cache.size} servidor(es).`);
    runtime.botError = null;
    store.addLog(null, 'Sistema', `Bot conectado como ${ready.user.tag}.`);

    // Guarda o nome de cada servidor para o painel mostrar.
    for (const guild of ready.guilds.cache.values()) {
      store.guild(guild.id).name = guild.name;
    }
    store.save(0);

    await commands.register(ready, {
      clientId: config.discord.clientId || ready.user.id,
      devGuildId: config.discord.devGuildId,
    });

    giveaways.startScheduler(ready);
    tasks.start(ready);
    startStatusLoop(ready);
    updatePresence(ready);
    presenceTimer = setInterval(() => updatePresence(ready), 300000);
    presenceTimer.unref?.();
  });

  c.on(Events.GuildCreate, (guild) => {
    store.guild(guild.id).name = guild.name;
    store.addLog(guild.id, 'Sistema', `Bot adicionado em ${guild.name}.`);
    store.save(0);
  });

  c.on(Events.GuildDelete, (guild) => {
    if (guild.available === false) return; // queda temporária do Discord, não uma saída
    store.addLog(guild.id, 'Sistema', `Bot removido de ${guild.name || guild.id}. Os dados foram mantidos.`);
    music.destroy(guild.id);
  });

  c.on(Events.MessageCreate, onMessage);
  c.on(Events.MessageUpdate, onMessageEdit);
  c.on(Events.GuildMemberAdd, onMemberAdd);
  c.on(Events.GuildMemberRemove, onMemberRemove);
  c.on(Events.InteractionCreate, onInteraction);
  c.on(Events.ChannelDelete, (channel) => {
    try {
      tickets.onChannelDelete(channel);
    } catch (err) {
      log.error('Canal apagado:', err.message);
    }
  });

  c.on(Events.VoiceStateUpdate, (oldState, newState) => {
    try {
      music.handleVoiceUpdate(oldState, newState);
    } catch (err) {
      log.error('Estado de voz:', err.message);
    }
  });

  c.on(Events.Error, (err) => log.error('Erro do cliente Discord:', err.message));
  c.on(Events.Warn, (message) => log.warn('Discord:', message));

  moderation.attachAntiNuke(c);
}

function updatePresence(readyClient) {
  const members = readyClient.guilds.cache.reduce((total, guild) => total + guild.memberCount, 0);
  readyClient.user.setPresence({
    status: 'online',
    activities: [{ name: `${formatNumber(members)} membros · /ajuda`, type: ActivityType.Watching }],
  });
}

// ---------------------------------------------------------------------------
// Contador de jogadores do Minecraft
// ---------------------------------------------------------------------------

function startStatusLoop(readyClient) {
  if (statusTimer) clearInterval(statusTimer);

  const tick = async () => {
    const cache = new Map(); // o mesmo servidor de Minecraft só é consultado uma vez por rodada

    for (const guild of readyClient.guilds.cache.values()) {
      try {
        const settings = store.guild(guild.id).serverStatus;
        if (!settings.enabled || !settings.host) continue;

        const key = `${settings.host}:${settings.port}`;
        if (!cache.has(key)) cache.set(key, await pingMinecraft(settings.host, settings.port));
        const result = cache.get(key);
        settings.lastPing = rememberPing(guild.id, result);

        if (!settings.counterChannelId) continue;
        const channel = guild.channels.cache.get(settings.counterChannelId);
        if (!channel) continue;

        const name = result.online
          ? (settings.counterTemplate || '🟢 {online}/{max} jogando')
              .replaceAll('{online}', result.players.online)
              .replaceAll('{max}', result.players.max)
          : '🔴 servidor offline';

        if (channel.name !== name) await channel.setName(name.slice(0, 100)).catch(() => {});
      } catch (err) {
        log.warn(`Status do Minecraft (${guild.name}):`, errorMessage(err));
      }
    }
    store.save();
  };

  tick().catch((err) => log.error('Ping do Minecraft:', err.message));
  // O Discord limita renomear canal a 2 vezes por 10 minutos.
  statusTimer = setInterval(() => tick().catch(() => {}), 360000);
  statusTimer.unref?.();
}

// ---------------------------------------------------------------------------
// Mensagens
// ---------------------------------------------------------------------------

async function onMessage(message) {
  if (message.author.bot || !message.guild) return;

  try {
    const removed = await moderation.runAutomod(message);
    if (removed) return;

    await progress.grantMessageXp(message);

    const guildData = store.guild(message.guild.id);
    const prefix = guildData.prefix || '!';
    if (!message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/\s+/);
    const name = args.shift()?.toLowerCase();
    if (!name) return;

    if (await runPrefixCommand(message, name, args, guildData)) return;
    await runCustomCommand(message, name, guildData);
  } catch (err) {
    log.error('Erro ao processar mensagem:', err);
  }
}

/** Quem edita a mensagem para escapar do filtro também é pego. */
async function onMessageEdit(oldMessage, newMessage) {
  try {
    if (!newMessage.guild || newMessage.author?.bot || newMessage.partial) return;
    if (oldMessage.content === newMessage.content) return;
    await moderation.runAutomod(newMessage, { edited: true });
  } catch (err) {
    log.error('Erro ao processar edição:', err);
  }
}

async function runPrefixCommand(message, name, args, guildData) {
  const guildId = message.guild.id;

  switch (name) {
    case 'ajuda':
    case 'help':
      await message.reply(
        'Use os comandos de barra digitando **/** — eles têm autocompletar e ficam mais fáceis de usar. Comece por `/ajuda`.',
      );
      return true;

    case 'ping':
      await message.reply(`🏓 Pong! ${Math.max(0, message.client.ws.ping)}ms`);
      return true;

    case 'saldo':
    case 'folhas': {
      const wallet = progress.account(guildId, message.author.id);
      const { name: currency, emoji } = progress.currencyLabel(guildId);
      await message.reply(`${emoji} Você tem **${formatNumber(wallet.balance)} ${currency}**.`);
      return true;
    }

    case 'rank':
    case 'nivel': {
      const info = progress.levelUser(guildId, message.author.id);
      await message.reply(
        `⭐ Nível **${info.level}** com ${formatNumber(info.xp)}/${formatNumber(progress.xpForLevel(info.level))} XP.`,
      );
      return true;
    }

    case 'status': {
      const settings = guildData.serverStatus;
      const result = settings.lastPing ?? (await pingMinecraft(settings.host, settings.port));
      await message.reply(
        result.online
          ? `🎮 **${settings.name}** — \`${settings.host}:${settings.port}\` · ${result.players.online}/${result.players.max} online.`
          : `🔴 **${settings.name}** está offline no momento.`,
      );
      return true;
    }

    case 'play':
    case 'p':
    case 'tocar': {
      const query = args.join(' ');
      if (!query) {
        await message.reply('Diga o nome ou cole o link da música.');
        return true;
      }
      const voiceChannel = message.member.voice.channel;
      if (!voiceChannel) {
        await message.reply('Entre em um canal de voz primeiro.');
        return true;
      }
      const result = await music.play(message.guild, voiceChannel, query, message.channel, message.author.tag);
      if (result.error) await message.reply(`⚠️ ${result.message}`);
      return true;
    }

    case 'skip':
    case 'pular': {
      const result = music.skip(guildId);
      await message.reply(result.message);
      return true;
    }

    case 'stop':
    case 'parar':
    case 'sair': {
      const result = music.destroy(guildId);
      await message.reply(result.message);
      return true;
    }

    case 'fila':
    case 'queue': {
      const snapshot = music.snapshot(guildId);
      if (!snapshot?.current) {
        await message.reply('Não há nada tocando agora.');
        return true;
      }
      const lines = snapshot.upcoming.map((track, i) => `**${i + 1}.** ${track.title}`).join('\n');
      await message.reply(`▶️ **${snapshot.current.title}**\n${lines || 'Nada depois desta.'}`);
      return true;
    }

    default:
      return false;
  }
}

/** userId:comando -> quando usou pela última vez (impede farm de moedas/cargos) */
const customCooldowns = new Map();

async function runCustomCommand(message, name, guildData) {
  const command = guildData.customCommands.find(
    (item) => String(item.name || '').replace(/^!/, '').toLowerCase() === name,
  );
  if (!command) return;

  const cooldown = (Number(command.cooldown) >= 0 ? Number(command.cooldown) : 10) * 1000;
  const key = `${message.guild.id}:${message.author.id}:${command.name}`;
  const last = customCooldowns.get(key) || 0;
  if (Date.now() - last < cooldown) {
    const wait = Math.ceil((cooldown - (Date.now() - last)) / 1000);
    const notice = await message.reply(`⏳ Aguarde ${wait}s para usar esse comando de novo.`).catch(() => null);
    if (notice) setTimeout(() => notice.delete().catch(() => {}), 4000).unref?.();
    return;
  }
  customCooldowns.set(key, Date.now());
  if (customCooldowns.size > 5000) customCooldowns.clear();

  for (const action of command.actions || []) {
    try {
      if (action.type === 'reply' && action.content) {
        await message.channel.send(
          escapeMentions(applyVariables(action.content, { member: message.member, guild: message.guild })),
        );
      } else if (action.type === 'send_dm' && action.content) {
        await message.author.send(
          escapeMentions(applyVariables(action.content, { member: message.member, guild: message.guild })),
        );
      } else if (action.type === 'add_role' && action.roleId) {
        const role = message.guild.roles.cache.get(action.roleId);
        const me = await getBotMember(message.guild);
        if (role && me && !role.managed && me.roles.highest.comparePositionTo(role) > 0) {
          await message.member.roles.add(role, `Comando ${command.name}`);
        }
      } else if (action.type === 'add_money' && action.amount) {
        progress.addMoney(message.guild.id, message.author.id, Number(action.amount));
      }
    } catch (err) {
      log.error(`Ação do comando ${command.name} falhou:`, err.message);
    }
  }
}

// ---------------------------------------------------------------------------
// Entradas e saídas
// ---------------------------------------------------------------------------

async function onMemberAdd(member) {
  const settings = store.guild(member.guild.id).welcome;
  if (!settings.enabled) return;

  try {
    if (settings.autoRoleId) {
      const role = member.guild.roles.cache.get(settings.autoRoleId);
      const me = await getBotMember(member.guild);
      if (role && me?.roles.highest.comparePositionTo(role) > 0) {
        await member.roles.add(role, 'Cargo automático de entrada').catch(() => {});
      }
    }

    const text = escapeMentions(applyVariables(settings.message, { member, guild: member.guild }));

    if (settings.channelId) {
      const channel = member.guild.channels.cache.get(settings.channelId);
      if (channel?.isTextBased()) {
        const payload = settings.useEmbed
          ? {
              content: `${member}`,
              embeds: [
                new EmbedBuilder()
                  .setColor(settings.embedColor || '#57C785')
                  .setDescription(text)
                  .setThumbnail(member.displayAvatarURL({ size: 128 }))
                  .setTimestamp(),
              ],
            }
          : { content: text };
        await channel.send(payload).catch(() => {});
      }
    }

    if (settings.dmEnabled && settings.dmMessage) {
      await member
        .send(applyVariables(settings.dmMessage, { member, guild: member.guild }))
        .catch(() => {});
    }

    store.addLog(member.guild.id, 'Entrada', `${member.user.tag} entrou no servidor.`);
  } catch (err) {
    log.error('Boas-vindas:', err.message);
  }
}

async function onMemberRemove(member) {
  const settings = store.guild(member.guild.id).welcome;
  if (!settings.leaveEnabled || !settings.leaveChannelId) return;

  const channel = member.guild.channels.cache.get(settings.leaveChannelId);
  if (!channel?.isTextBased()) return;
  await channel
    .send(escapeMentions(applyVariables(settings.leaveMessage, { member, guild: member.guild })))
    .catch(() => {});
}

// ---------------------------------------------------------------------------
// Interações
// ---------------------------------------------------------------------------

async function onInteraction(interaction) {
  try {
    if (interaction.isChatInputCommand()) {
      if (!interaction.guild) {
        return await interaction.reply({
          content: 'Os comandos funcionam apenas dentro de um servidor.',
          flags: MessageFlags.Ephemeral,
        });
      }
      return await commands.handle(interaction);
    }

    if (interaction.isStringSelectMenu() && interaction.customId === tickets.SELECT_ID) {
      return await tickets.handleSelect(interaction);
    }

    if (interaction.isButton()) {
      if (interaction.customId.startsWith('ticket:')) return await tickets.handleButton(interaction);
      if (interaction.customId.startsWith(suggestions.UP) || interaction.customId.startsWith(suggestions.DOWN)) {
        return await suggestions.handleButton(interaction);
      }
      if (interaction.customId.startsWith(polls.PREFIX)) return await polls.vote(interaction);
      if (interaction.customId.startsWith(giveaways.ENTER_PREFIX)) return await giveaways.enter(interaction);
      if (interaction.customId.startsWith('role:')) return await handleReactionRole(interaction);
    }
  } catch (err) {
    log.error('Interação falhou:', err);
    if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
      await interaction
        .reply({ content: 'Não consegui processar essa ação.', flags: MessageFlags.Ephemeral })
        .catch(() => {});
    }
  }
  return undefined;
}

/** Botões de cargo criados pelo painel: customId "role:<roleId>" */
async function handleReactionRole(interaction) {
  const roleId = interaction.customId.slice('role:'.length);
  const role = interaction.guild.roles.cache.get(roleId);
  if (!role) {
    return interaction.reply({ content: 'Esse cargo não existe mais.', flags: MessageFlags.Ephemeral });
  }
  const me = await getBotMember(interaction.guild);
  if (role.managed || !me || me.roles.highest.comparePositionTo(role) <= 0) {
    return interaction.reply({
      content: 'Meu cargo está abaixo desse cargo, então não consigo entregá-lo.',
      flags: MessageFlags.Ephemeral,
    });
  }

  const has = interaction.member.roles.cache.has(roleId);
  try {
    await (has ? interaction.member.roles.remove(role) : interaction.member.roles.add(role));
  } catch {
    return interaction.reply({ content: 'Não consegui mexer nesse cargo. Confira minhas permissões.', flags: MessageFlags.Ephemeral });
  }
  return interaction.reply({
    content: has ? `Cargo ${role.name} removido.` : `Cargo ${role.name} adicionado.`,
    flags: MessageFlags.Ephemeral,
  });
}

// ---------------------------------------------------------------------------
// Utilidades para o painel
// ---------------------------------------------------------------------------

const TEXT_TYPES = [ChannelType.GuildText, ChannelType.GuildAnnouncement];
const byName = (a, b) => a.name.localeCompare(b.name);
const simple = (channel) => ({ id: channel.id, name: channel.name });

/** Canais e cargos para os seletores do painel. */
function listGuildResources(guildId) {
  const guild = client.guilds.cache.get(guildId);
  if (!guild) return null;
  return {
    id: guild.id,
    name: guild.name,
    icon: guild.iconURL({ size: 128 }),
    memberCount: guild.memberCount,
    textChannels: guild.channels.cache.filter((c) => TEXT_TYPES.includes(c.type)).map(simple).sort(byName),
    voiceChannels: guild.channels.cache
      .filter((c) => c.type === ChannelType.GuildVoice)
      .map(simple)
      .sort(byName),
    categories: guild.channels.cache
      .filter((c) => c.type === ChannelType.GuildCategory)
      .map(simple)
      .sort(byName),
    roles: guild.roles.cache
      .filter((role) => role.id !== guild.id && !role.managed)
      .map((role) => ({ id: role.id, name: role.name, color: role.hexColor }))
      .sort(byName),
  };
}

/** Link para convidar o bot, já com as permissões que ele usa. */
function inviteUrl() {
  const id = config.discord.clientId || client?.user?.id;
  if (!id) return null;
  const permissions = new PermissionsBitField([
    'ViewChannel',
    'SendMessages',
    'EmbedLinks',
    'AttachFiles',
    'ReadMessageHistory',
    'ManageMessages',
    'ManageChannels',
    'ManageRoles',
    'KickMembers',
    'BanMembers',
    'ModerateMembers',
    'ViewAuditLog',
    'Connect',
    'Speak',
  ]).bitfield;
  return `https://discord.com/oauth2/authorize?client_id=${id}&scope=bot%20applications.commands&permissions=${permissions}`;
}

// ---------------------------------------------------------------------------
// Ciclo de vida
// ---------------------------------------------------------------------------

/**
 * Entra no Discord. Se as intents privilegiadas não estiverem ligadas no
 * Developer Portal, o bot entra mesmo assim com as intents básicas e avisa
 * o que fica sem funcionar, em vez de ficar fora do ar.
 */
async function login({ limited }) {
  await client?.destroy().catch(() => {}); // descarta o cliente anterior (ou o inicial, ainda desconectado)
  client = buildClient({ limited });
  try {
    await client.login(config.discord.token);
    runtime.limitedIntents = limited ? ['Server Members Intent', 'Message Content Intent'] : [];
    runtime.botError = null;
    if (limited) {
      log.warn('O bot entrou SEM as intents privilegiadas. Boas-vindas, XP, auto-moderação e comandos com prefixo não vão funcionar.');
      log.warn('Ligue "Server Members Intent" e "Message Content Intent" no Developer Portal → Bot e reinicie.');
    }
    return { ok: true };
  } catch (err) {
    await client.destroy().catch(() => {});
    return { ok: false, error: err };
  }
}

async function start() {
  if (!config.discord.token) {
    runtime.botError = 'DISCORD_TOKEN está vazio no arquivo .env.';
    client = buildClient({ limited: true });
    return false;
  }

  let attempt = await login({ limited: false });
  if (!attempt.ok && /disallowed intents/i.test(errorMessage(attempt.error))) {
    log.warn('O Discord recusou as intents privilegiadas. Tentando entrar só com as básicas…');
    attempt = await login({ limited: true });
  }
  if (attempt.ok) return true;

  const message = errorMessage(attempt.error);
  const invalidToken = /invalid token|incorrect login|tokeninvalid/i.test(message);
  runtime.botError = invalidToken
    ? 'Token inválido. Gere um novo em Developer Portal → Bot → Reset Token e cole no .env.'
    : /no description/i.test(message)
      ? 'O Discord recusou a conexão. Confira o DISCORD_TOKEN e se a host tem acesso à internet.'
      : `Não consegui entrar no Discord: ${message}`;
  log.error(runtime.botError);

  // Problemas de rede são temporários: tenta de novo sozinho. Token inválido não.
  if (!invalidToken && !shuttingDown) scheduleRetry(30000);
  return false;
}

function scheduleRetry(delay) {
  clearTimeout(retryTimer);
  retryTimer = setTimeout(async () => {
    if (shuttingDown) return;
    log.info('Tentando conectar ao Discord de novo…');
    let attempt = await login({ limited: false });
    if (!attempt.ok && /disallowed intents/i.test(errorMessage(attempt.error))) {
      attempt = await login({ limited: true });
    }
    if (!attempt.ok && !shuttingDown) {
      runtime.botError = /no description/i.test(errorMessage(attempt.error))
        ? 'O Discord recusou a conexão. Confira o DISCORD_TOKEN e se a host tem acesso à internet.'
        : `Não consegui entrar no Discord: ${errorMessage(attempt.error)}`;
      scheduleRetry(Math.min(delay * 2, 300000));
    }
  }, delay);
  retryTimer.unref?.();
}

async function shutdown() {
  shuttingDown = true;
  clearTimeout(retryTimer);
  giveaways.stopScheduler();
  tasks.stop();
  if (statusTimer) clearInterval(statusTimer);
  if (presenceTimer) clearInterval(presenceTimer);
  music.destroyAll();
  await client?.destroy().catch(() => {});
}

module.exports = {
  get client() {
    return client;
  },
  start,
  shutdown,
  listGuildResources,
  inviteUrl,
};

// Cliente inicial (ainda desconectado) para o painel poder responder desde o primeiro segundo.
client = buildClient({ limited: true });
