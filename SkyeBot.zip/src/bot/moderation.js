'use strict';

const { PermissionFlagsBits, EmbedBuilder, AuditLogEvent } = require('discord.js');
const { store } = require('../store');
const { log, escapeMentions, foldText, getBotMember } = require('../util');

const INVITE_RE = /(discord\.(gg|io|me|li)|discord(app)?\.com\/invite)\/[a-z0-9-]+/i;
const URL_RE = /https?:\/\/([^\s/?#]+)[^\s]*/gi;

/** guildId:userId -> timestamps das mensagens recentes (anti-spam) */
const spamTracker = new Map();
/** guildId:userId:tipo -> timestamps das ações destrutivas (anti-nuke) */
const nukeTracker = new Map();

// Limpeza periódica: sem isto os mapas cresceriam para sempre.
const sweeper = setInterval(() => {
  const now = Date.now();
  for (const [key, times] of spamTracker) {
    if (!times.length || now - times[times.length - 1] > 120000) spamTracker.delete(key);
  }
  for (const [key, times] of nukeTracker) {
    if (!times.length || now - times[times.length - 1] > 3600000) nukeTracker.delete(key);
  }
}, 120000);
sweeper.unref();

function sendModLog(guild, channelId, embed) {
  if (!channelId) return;
  const channel = guild.channels.cache.get(channelId);
  if (!channel?.isTextBased()) return;
  channel.send({ embeds: [embed] }).catch(() => {});
}

// ---------------------------------------------------------------------------
// Palavras bloqueadas
// ---------------------------------------------------------------------------

const escapeRegex = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const badWordCache = new Map();

/**
 * Compila a lista em uma única expressão. Por padrão a palavra precisa aparecer
 * inteira ("ass" não pega "classe"); use * para pegar parte ("idiot*").
 * Acentos e maiúsculas não importam.
 */
function compileBadWords(list) {
  const key = list.join('\u0000');
  if (badWordCache.has(key)) return badWordCache.get(key);

  const parts = list
    .map((word) => foldText(word).trim())
    .filter(Boolean)
    .map((word) => {
      const startOpen = word.startsWith('*');
      const endOpen = word.endsWith('*');
      const core = escapeRegex(word.replace(/^\*+|\*+$/g, ''));
      if (!core) return null;
      return `${startOpen ? '' : '(?<![\\p{L}\\p{N}])'}${core}${endOpen ? '' : '(?![\\p{L}\\p{N}])'}`;
    })
    .filter(Boolean);

  const regex = parts.length ? new RegExp(parts.join('|'), 'iu') : null;
  if (badWordCache.size > 50) badWordCache.clear();
  badWordCache.set(key, regex);
  return regex;
}

function hasBlockedLink(content, allowedDomains) {
  URL_RE.lastIndex = 0;
  let match;
  while ((match = URL_RE.exec(content))) {
    const host = match[1].toLowerCase().replace(/^www\./, '');
    const allowed = allowedDomains.some((domain) => host === domain || host.endsWith(`.${domain}`));
    if (!allowed) return true;
  }
  return false;
}

// ---------------------------------------------------------------------------
// Auto-moderação
// ---------------------------------------------------------------------------

/** @returns {Promise<boolean>} true se a mensagem foi removida. */
async function runAutomod(message, { edited = false } = {}) {
  const guildData = store.guild(message.guild.id);
  const rules = guildData.automod;
  if (!rules.enabled) return false;

  const member = message.member;
  if (!member) return false;

  // Equipe e cargos liberados não passam pelo filtro.
  if (member.permissions.has(PermissionFlagsBits.ManageMessages)) return false;
  if (rules.ignoredChannelIds.includes(message.channel.id)) return false;
  if (rules.ignoredRoleIds.some((roleId) => member.roles.cache.has(roleId))) return false;

  const content = message.content || '';
  let reason = null;

  if (rules.antiInvite && INVITE_RE.test(content)) {
    reason = 'convite de outro servidor';
  } else if (rules.antiLink && hasBlockedLink(content, rules.allowedDomains || [])) {
    reason = 'link não permitido';
  } else if (rules.badWords.length) {
    const regex = compileBadWords(rules.badWords);
    if (regex && regex.test(foldText(content))) reason = 'palavra bloqueada';
  }

  if (!reason && rules.maxMentions > 0) {
    const mentions = message.mentions.users.size + message.mentions.roles.size;
    if (mentions > rules.maxMentions) reason = `marcações demais (${mentions})`;
  }

  if (!reason && rules.capsPercent > 0 && content.length >= 12) {
    const letters = content.replace(/[^a-zA-ZÀ-ÿ]/g, '');
    if (letters.length >= 10) {
      const caps = letters.replace(/[^A-ZÀ-Þ]/g, '').length;
      if ((caps / letters.length) * 100 >= rules.capsPercent) reason = 'excesso de letras maiúsculas';
    }
  }

  // Edições não contam como flood: só o conteúdo é reavaliado.
  if (!reason && rules.antiSpam && !edited) {
    const key = `${message.guild.id}:${member.id}`;
    const window = rules.spamSeconds * 1000;
    const now = Date.now();
    const recent = (spamTracker.get(key) || []).filter((time) => now - time < window);
    recent.push(now);
    spamTracker.set(key, recent);
    if (recent.length > rules.spamMessages) {
      reason = 'flood de mensagens';
      spamTracker.set(key, []);
    }
  }

  if (!reason) return false;

  await message.delete().catch(() => {});

  const warning = await message.channel
    .send(`⚠️ ${member}, sua mensagem foi removida: ${reason}.`)
    .catch(() => null);
  if (warning) setTimeout(() => warning.delete().catch(() => {}), 6000).unref?.();

  if (rules.punishment === 'timeout' && member.moderatable) {
    await member.timeout(rules.timeoutMinutes * 60000, `Automod: ${reason}`).catch(() => {});
  } else if (rules.punishment === 'warn') {
    addWarn(message.guild.id, member.id, message.client.user.id, `Automod: ${reason}`);
  }

  store.addLog(message.guild.id, 'Automod', `Mensagem de ${member.user.tag} removida (${reason}).`);
  sendModLog(
    message.guild,
    rules.logChannelId,
    new EmbedBuilder()
      .setColor(0xd4614a)
      .setTitle('Mensagem removida pelo automod')
      .setDescription(escapeMentions(content).slice(0, 500) || '(sem texto)')
      .addFields(
        { name: 'Autor', value: `${member} (${member.user.tag})`, inline: true },
        { name: 'Canal', value: `${message.channel}`, inline: true },
        { name: 'Motivo', value: reason, inline: true },
      )
      .setTimestamp(),
  );
  return true;
}

// ---------------------------------------------------------------------------
// Avisos
// ---------------------------------------------------------------------------

function addWarn(guildId, userId, moderatorId, reason) {
  const guildData = store.guild(guildId);
  guildData.warns[userId] ||= [];
  guildData.warns[userId].push({
    at: Date.now(),
    by: moderatorId,
    reason: String(reason || 'Sem motivo informado').slice(0, 300),
  });
  store.save();
  return guildData.warns[userId].length;
}

function getWarns(guildId, userId) {
  return store.guild(guildId).warns[userId] || [];
}

function clearWarns(guildId, userId) {
  const guildData = store.guild(guildId);
  const count = guildData.warns[userId]?.length || 0;
  delete guildData.warns[userId];
  store.save();
  return count;
}

// ---------------------------------------------------------------------------
// Anti-nuke
// ---------------------------------------------------------------------------

/**
 * Descobre quem fez a ação lendo o registro de auditoria. O Discord às vezes
 * demora um instante para gravar a entrada, então tentamos duas vezes, e só
 * aceitamos uma entrada que seja mesmo sobre o alvo do evento.
 */
async function findExecutor(guild, auditType, targetId) {
  if (!store.guild(guild.id).antinuke.enabled) return null;
  const me = await getBotMember(guild);
  if (!me?.permissions.has(PermissionFlagsBits.ViewAuditLog)) return null;

  for (let attempt = 0; attempt < 2; attempt++) {
    if (attempt) await new Promise((resolve) => setTimeout(resolve, 1200));
    try {
      const logs = await guild.fetchAuditLogs({ type: auditType, limit: 5 });
      const entry = logs.entries.find(
        (item) => Date.now() - item.createdTimestamp < 10000 && (!targetId || item.targetId === targetId),
      );
      if (entry) return entry.executor || null;
    } catch {
      return null;
    }
  }
  return null;
}

async function registerNukeAction(guild, executor, kind, limitKey) {
  const settings = store.guild(guild.id).antinuke;
  if (!settings.enabled || !executor || executor.id === guild.client.user.id) return;
  if (executor.id === guild.ownerId) return;
  if (settings.whitelistIds.includes(executor.id)) return;

  const key = `${guild.id}:${executor.id}:${kind}`;
  const window = settings.windowSeconds * 1000;
  const now = Date.now();
  const hits = (nukeTracker.get(key) || []).filter((time) => now - time < window);
  hits.push(now);
  nukeTracker.set(key, hits);

  const limit = Number(settings[limitKey]) || 3;
  if (hits.length < limit) return;
  nukeTracker.set(key, []);

  const member = await guild.members.fetch(executor.id).catch(() => null);
  let applied = 'nenhuma (sem permissão para punir)';

  if (member) {
    try {
      if (settings.punishment === 'ban' && member.bannable) {
        await member.ban({ reason: 'Anti-nuke: ações destrutivas em série' });
        applied = 'banido';
      } else if (settings.punishment === 'kick' && member.kickable) {
        await member.kick('Anti-nuke: ações destrutivas em série');
        applied = 'expulso';
      } else if (member.manageable) {
        await member.roles.set([], 'Anti-nuke: cargos removidos por segurança');
        applied = 'cargos removidos';
      }
    } catch (err) {
      log.error('Anti-nuke não conseguiu punir:', err.message);
    }
  }

  const details = `${executor.tag} passou do limite de ${kind} (${hits.length}/${limit}) — ${applied}.`;
  store.addLog(guild.id, 'Anti-nuke', details);
  log.warn(`[${guild.name}] ${details}`);

  sendModLog(
    guild,
    settings.alertChannelId,
    new EmbedBuilder()
      .setColor(0xd4614a)
      .setTitle('🛡️ Anti-nuke acionado')
      .setDescription(`${executor} passou do limite configurado para **${kind}**.`)
      .addFields(
        { name: 'Ações no período', value: `${hits.length} em ${settings.windowSeconds}s`, inline: true },
        { name: 'Punição aplicada', value: applied, inline: true },
      )
      .setTimestamp(),
  );
}

function attachAntiNuke(client) {
  client.on('channelDelete', async (channel) => {
    if (!channel.guild) return;
    const executor = await findExecutor(channel.guild, AuditLogEvent.ChannelDelete, channel.id);
    await registerNukeAction(channel.guild, executor, 'exclusão de canais', 'maxChannelDelete');
  });

  client.on('roleDelete', async (role) => {
    const executor = await findExecutor(role.guild, AuditLogEvent.RoleDelete, role.id);
    await registerNukeAction(role.guild, executor, 'exclusão de cargos', 'maxRoleDelete');
  });

  client.on('guildBanAdd', async (ban) => {
    const executor = await findExecutor(ban.guild, AuditLogEvent.MemberBanAdd, ban.user.id);
    await registerNukeAction(ban.guild, executor, 'banimentos', 'maxBans');
  });

  client.on('guildMemberRemove', async (member) => {
    const executor = await findExecutor(member.guild, AuditLogEvent.MemberKick, member.id);
    if (executor) await registerNukeAction(member.guild, executor, 'expulsões', 'maxKicks');
  });
}

module.exports = { runAutomod, addWarn, getWarns, clearWarns, attachAntiNuke };
