'use strict';

const fs = require('fs');
const {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
  MessageFlags,
  ChannelType,
} = require('discord.js');

const { store } = require('../store');
const { pingMinecraft, rememberPing } = require('../mcping');
const { log, formatNumber, formatDuration, parseDuration, escapeMentions } = require('../util');
const music = require('./music');
const progress = require('./progress');
const moderation = require('./moderation');
const giveaways = require('./giveaways');
const tickets = require('./tickets');
const suggestions = require('./suggestions');
const polls = require('./polls');
const reminders = require('./reminders');

const ACCENT = 0x57c785;
const GOLD = 0xe8b84b;
const CLAY = 0xd4614a;

const ephemeral = (content) => ({ content, flags: MessageFlags.Ephemeral });

function baseEmbed(title, color = ACCENT) {
  return new EmbedBuilder().setColor(color).setTitle(title).setTimestamp();
}

/** Garante que o membro está em call antes de mexer no player. */
function voiceCheck(interaction) {
  const channel = interaction.member?.voice?.channel;
  if (!channel) return { ok: false, message: 'Entre em um canal de voz primeiro.' };
  const queue = music.getQueue(interaction.guild.id);
  if (queue && queue.voiceChannelId !== channel.id) {
    return { ok: false, message: 'Você precisa estar no mesmo canal de voz que o bot.' };
  }
  return { ok: true, channel };
}

/**
 * Impede que alguém use o bot para punir quem está acima dele na hierarquia.
 */
function hierarchyBlock(interaction, member) {
  if (!member) return null;
  if (member.id === interaction.user.id) return 'Você não pode fazer isso consigo mesmo.';
  if (member.id === interaction.client.user.id) return 'Eu não vou fazer isso comigo mesmo.';
  if (interaction.guild.ownerId === interaction.user.id) return null;
  if (member.id === interaction.guild.ownerId) return 'Não dá para punir o dono do servidor.';
  if (interaction.member.roles.highest.comparePositionTo(member.roles.highest) <= 0) {
    return 'Esse membro tem um cargo igual ou acima do seu.';
  }
  return null;
}

const commands = [];
const define = (data, run) => commands.push({ data, run });

// ---------------------------------------------------------------------------
// Geral
// ---------------------------------------------------------------------------

define(
  new SlashCommandBuilder().setName('ajuda').setDescription('Lista tudo o que o bot sabe fazer'),
  async (interaction) => {
    const prefix = store.guild(interaction.guild.id).prefix;
    const embed = baseEmbed('Comandos disponíveis')
      .setDescription(`Os comandos de texto também funcionam com o prefixo \`${prefix}\`.`)
      .addFields(
        {
          name: '🍃 Economia',
          value: '`/saldo` `/daily` `/trabalhar` `/pagar` `/top economia`',
        },
        { name: '⭐ Níveis', value: '`/rank` `/top xp`' },
        {
          name: '🎵 Música',
          value: '`/tocar` `/pular` `/parar` `/fila` `/pausar` `/retomar` `/volume` `/repetir`',
        },
        { name: '🎮 Servidor', value: '`/status` mostra quem está online no Minecraft\n`/serverinfo` `/userinfo` `/avatar` `/ping`' },
        { name: '🛡️ Moderação', value: '`/limpar` `/avisar` `/avisos` `/castigo` `/expulsar` `/banir`' },
        { name: '🎉 Sorteios', value: '`/sorteio criar` `/sorteio encerrar` `/sorteio resortear` `/sorteio listar`' },
        { name: '🎫 Tickets (equipe)', value: '`/ticket adicionar` `/ticket remover` `/ticket fechar`' },
        { name: '💡 Comunidade', value: '`/sugerir` `/sugestao aprovar|negar` `/enquete criar|encerrar` `/lembrar criar|listar|cancelar`' },
      );
    return interaction.reply({ embeds: [embed] });
  },
);

define(
  new SlashCommandBuilder().setName('ping').setDescription('Mostra a latência do bot'),
  async (interaction) => {
    const embed = baseEmbed('Pong')
      .addFields(
        { name: 'Gateway', value: `${Math.max(0, interaction.client.ws.ping)}ms`, inline: true },
        { name: 'Online há', value: formatDuration(interaction.client.uptime), inline: true },
      );
    return interaction.reply({ embeds: [embed] });
  },
);

define(
  new SlashCommandBuilder()
    .setName('serverinfo')
    .setDescription('Informações do servidor do Discord'),
  async (interaction) => {
    const guild = interaction.guild;
    const embed = baseEmbed(guild.name)
      .setThumbnail(guild.iconURL({ size: 256 }))
      .addFields(
        { name: 'Membros', value: formatNumber(guild.memberCount), inline: true },
        { name: 'Canais', value: String(guild.channels.cache.size), inline: true },
        { name: 'Cargos', value: String(guild.roles.cache.size), inline: true },
        { name: 'Criado em', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true },
        { name: 'Dono', value: `<@${guild.ownerId}>`, inline: true },
        { name: 'Impulsos', value: String(guild.premiumSubscriptionCount ?? 0), inline: true },
      );
    return interaction.reply({ embeds: [embed] });
  },
);

define(
  new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('Mostra informações de um membro')
    .addUserOption((option) => option.setName('usuario').setDescription('De quem (padrão: você)')),
  async (interaction) => {
    const user = interaction.options.getUser('usuario') ?? interaction.user;
    const member = interaction.options.getMember('usuario') ?? (user.id === interaction.user.id ? interaction.member : null);

    const embed = baseEmbed(user.tag)
      .setThumbnail(user.displayAvatarURL({ size: 256 }))
      .addFields(
        { name: 'ID', value: `\`${user.id}\``, inline: true },
        { name: 'Conta criada', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:D>`, inline: true },
      );
    if (member?.joinedTimestamp) {
      embed.addFields({ name: 'Entrou no servidor', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:D>`, inline: true });
      const roles = member.roles.cache.filter((role) => role.id !== interaction.guild.id).map((role) => `${role}`);
      if (roles.length) embed.addFields({ name: 'Cargos', value: roles.slice(0, 15).join(' ') });
    }
    return interaction.reply({ embeds: [embed] });
  },
);

define(
  new SlashCommandBuilder()
    .setName('avatar')
    .setDescription('Mostra o avatar de um membro em tamanho grande')
    .addUserOption((option) => option.setName('usuario').setDescription('De quem (padrão: você)')),
  async (interaction) => {
    const user = interaction.options.getUser('usuario') ?? interaction.user;
    const embed = baseEmbed(`Avatar de ${user.username}`).setImage(user.displayAvatarURL({ size: 1024 }));
    return interaction.reply({ embeds: [embed] });
  },
);

// ---------------------------------------------------------------------------
// Minecraft
// ---------------------------------------------------------------------------

define(
  new SlashCommandBuilder().setName('status').setDescription('Mostra o status do servidor de Minecraft'),
  async (interaction) => {
    const settings = store.guild(interaction.guild.id).serverStatus;
    await interaction.deferReply();

    const result = await pingMinecraft(settings.host, settings.port);
    settings.lastPing = rememberPing(interaction.guild.id, result);
    store.save();

    const embed = baseEmbed(settings.name || 'Servidor Minecraft', result.online ? ACCENT : CLAY)
      .addFields({ name: 'Endereço', value: `\`${settings.host}:${settings.port}\`` });

    if (result.online) {
      embed.addFields(
        { name: 'Jogadores', value: `${result.players.online}/${result.players.max}`, inline: true },
        { name: 'Versão', value: result.version || '—', inline: true },
        { name: 'Resposta', value: `${result.latency}ms`, inline: true },
      );
      if (result.motd) embed.setDescription(result.motd);
    } else {
      embed.setDescription(`Servidor offline. ${result.error ?? ''}`.trim());
    }
    return interaction.editReply({ embeds: [embed] });
  },
);

// ---------------------------------------------------------------------------
// Economia
// ---------------------------------------------------------------------------

define(
  new SlashCommandBuilder()
    .setName('saldo')
    .setDescription('Mostra quantas moedas alguém tem')
    .addUserOption((option) => option.setName('usuario').setDescription('De quem é o saldo')),
  async (interaction) => {
    const target = interaction.options.getUser('usuario') ?? interaction.user;
    const wallet = progress.account(interaction.guild.id, target.id);
    const { name, emoji } = progress.currencyLabel(interaction.guild.id);

    const embed = baseEmbed(`Carteira de ${target.username}`, GOLD)
      .setThumbnail(target.displayAvatarURL({ size: 128 }))
      .addFields({ name: name, value: `${emoji}${formatNumber(wallet.balance)}` });
    return interaction.reply({ embeds: [embed] });
  },
);

define(
  new SlashCommandBuilder().setName('daily').setDescription('Resgata o bônus diário'),
  async (interaction) => {
    const result = progress.claimDaily(interaction.guild.id, interaction.user.id);
    const { name, emoji } = progress.currencyLabel(interaction.guild.id);

    if (result.error) {
      return interaction.reply(
        ephemeral(`${result.message} Volte <t:${Math.floor(result.retryAt / 1000)}:R>.`),
      );
    }
    return interaction.reply(
      `${emoji} Você recebeu **${formatNumber(result.amount)}${name}**. Saldo: ${formatNumber(result.balance)}.`,
    );
  },
);

define(
  new SlashCommandBuilder().setName('trabalhar').setDescription('Trabalha para ganhar moedas'),
  async (interaction) => {
    const result = progress.work(interaction.guild.id, interaction.user.id);
    const { name, emoji } = progress.currencyLabel(interaction.guild.id);

    if (result.error) {
      return interaction.reply(
        ephemeral(`${result.message} Você pode trabalhar de novo <t:${Math.floor(result.retryAt / 1000)}:R>.`),
      );
    }
    const jobs = [
      'colheu folhas na estufa',
      'minerou por algumas horas',
      'vendeu batatas no mercado',
      'ajudou na construção da spawn',
      'domou um cavalo e revendeu',
    ];
    const job = jobs[Math.floor(Math.random() * jobs.length)];
    return interaction.reply(
      `${emoji} Você ${job} e ganhou **${formatNumber(result.amount)}${name}**. Saldo: ${formatNumber(result.balance)}.`,
    );
  },
);

define(
  new SlashCommandBuilder()
    .setName('pagar')
    .setDescription('Transfere moedas para outro membro')
    .addUserOption((option) => option.setName('usuario').setDescription('Quem recebe').setRequired(true))
    .addIntegerOption((option) =>
      option.setName('valor').setDescription('Quanto transferir').setRequired(true).setMinValue(1),
    ),
  async (interaction) => {
    const target = interaction.options.getUser('usuario');
    const amount = interaction.options.getInteger('valor');
    if (target.bot) return interaction.reply(ephemeral('Bots não têm carteira.'));

    const result = progress.transfer(interaction.guild.id, interaction.user.id, target.id, amount);
    if (result.error) return interaction.reply(ephemeral(result.message));

    const { name, emoji } = progress.currencyLabel(interaction.guild.id);
    return interaction.reply(`${emoji}${interaction.user} enviou **${formatNumber(amount)}${name}** para ${target}.`);
  },
);

// ---------------------------------------------------------------------------
// Níveis
// ---------------------------------------------------------------------------

define(
  new SlashCommandBuilder()
    .setName('rank')
    .setDescription('Mostra o nível e o XP de alguém')
    .addUserOption((option) => option.setName('usuario').setDescription('De quem é o rank')),
  async (interaction) => {
    const target = interaction.options.getUser('usuario') ?? interaction.user;
    const info = progress.levelUser(interaction.guild.id, target.id);
    const needed = progress.xpForLevel(info.level);
    const percent = needed ? Math.min(100, Math.floor((info.xp / needed) * 100)) : 0;
    const filled = Math.round(percent / 5);
    const bar = '█'.repeat(filled) + '░'.repeat(20 - filled);
    const { position, total } = progress.levelRank(interaction.guild.id, target.id);

    const embed = baseEmbed(`Progresso de ${target.username}`)
      .setThumbnail(target.displayAvatarURL({ size: 128 }))
      .setDescription(`\`${bar}\` ${percent}%`)
      .addFields(
        { name: 'Nível', value: String(info.level), inline: true },
        { name: 'XP', value: `${formatNumber(info.xp)} /${formatNumber(needed)}`, inline: true },
        { name: 'Posição', value: position ? `${position}º de ${total}` : 'sem ranking', inline: true },
      );
    return interaction.reply({ embeds: [embed] });
  },
);

define(
  new SlashCommandBuilder()
    .setName('top')
    .setDescription('Ranking do servidor')
    .addStringOption((option) =>
      option
        .setName('tipo')
        .setDescription('Qual ranking mostrar')
        .addChoices({ name: 'XP', value: 'xp' }, { name: 'Economia', value: 'economia' }),
    ),
  async (interaction) => {
    const type = interaction.options.getString('tipo') ?? 'xp';
    await interaction.deferReply();

    if (type === 'economia') {
      const entries = progress.economyLeaderboard(interaction.guild.id, 10);
      const { name, emoji } = progress.currencyLabel(interaction.guild.id);
      const lines = entries.map((entry, i) => `**${i + 1}.** <@${entry.userId}> — ${emoji}${formatNumber(entry.balance)}`);
      const embed = baseEmbed(`Ranking de ${name}`, GOLD).setDescription(
        lines.join('\n') || 'Ninguém tem moedas ainda.',
      );
      return interaction.editReply({ embeds: [embed] });
    }

    const entries = progress.levelLeaderboard(interaction.guild.id, 10);
    const lines = entries.map(
      (entry, i) => `**${i + 1}.** <@${entry.userId}> — nível ${entry.level} (${formatNumber(entry.totalXp)} XP)`,
    );
    const embed = baseEmbed('Ranking de XP').setDescription(lines.join('\n') || 'Ninguém ganhou XP ainda.');
    return interaction.editReply({ embeds: [embed] });
  },
);

// ---------------------------------------------------------------------------
// Música
// ---------------------------------------------------------------------------
const play = require('play-dl');

/** Leitor de cookies.txt para o play-dl */
function loadCookies() {
  if (!fs.existsSync('cookies.txt')) return null;
  const content = fs.readFileSync('cookies.txt', 'utf8');

  if (!content.includes('\t') && content.includes('=')) {
    return content.trim();
  }

  const cookies = [];
  const lines = content.split('\n');
  for (const line of lines) {
    if (line.startsWith('#') || !line.trim()) continue;
    const parts = line.split('\t');
    if (parts.length >= 7) {
      const name = parts[5].trim();
      const value = parts[6].trim();
      cookies.push(`${name}=${value}`);
    }
  }
  return cookies.join('; ');
}

const cookieString = loadCookies();
if (cookieString) {
  play.setToken({
    youtube: {
      cookie: cookieString,
    },
  });
}

define(
  new SlashCommandBuilder()
    .setName('tocar')
    .setDescription('Toca uma música ou playlist do YouTube')
    .addStringOption((option) =>
      option.setName('busca').setDescription('Nome da música ou link').setRequired(true),
    ),
  async (interaction) => {
    const check = voiceCheck(interaction);
    if (!check.ok) return interaction.reply(ephemeral(check.message));

    await interaction.deferReply();
    const result = await music.play(
      interaction.guild,
      check.channel,
      interaction.options.getString('busca'),
      interaction.channel,
      interaction.user.tag,
    );
    return interaction.editReply(result.error ? `⚠️ ${result.message}` : `✅ ${result.message}`);
  },
);

const simpleMusic = [
  ['pular', 'Pula a faixa atual', () => music.skip],
  ['parar', 'Para a música e tira o bot da call', () => music.destroy],
  ['pausar', 'Pausa a música', () => music.pause],
  ['retomar', 'Continua a música pausada', () => music.resume],
];

for (const [name, description, getter] of simpleMusic) {
  define(new SlashCommandBuilder().setName(name).setDescription(description), async (interaction) => {
    const check = voiceCheck(interaction);
    if (!check.ok) return interaction.reply(ephemeral(check.message));
    const result = getter()(interaction.guild.id);
    return interaction.reply(result.error ? ephemeral(result.message) : result.message);
  });
}

define(
  new SlashCommandBuilder()
    .setName('volume')
    .setDescription('Ajusta o volume do player')
    .addIntegerOption((option) =>
      option.setName('nivel').setDescription('0 a 150').setRequired(true).setMinValue(0).setMaxValue(150),
    ),
  async (interaction) => {
    const check = voiceCheck(interaction);
    if (!check.ok) return interaction.reply(ephemeral(check.message));
    const result = music.setVolume(interaction.guild.id, interaction.options.getInteger('nivel'));
    return interaction.reply(result.error ? ephemeral(result.message) : result.message);
  },
);

define(
  new SlashCommandBuilder()
    .setName('repetir')
    .setDescription('Controla a repetição da fila')
    .addStringOption((option) =>
      option
        .setName('modo')
        .setDescription('Como repetir')
        .setRequired(true)
        .addChoices(
          { name: 'Desligar', value: 'off' },
          { name: 'Faixa atual', value: 'song' },
          { name: 'Fila inteira', value: 'queue' },
        ),
    ),
  async (interaction) => {
    const result = music.setLoop(interaction.guild.id, interaction.options.getString('modo'));
    return interaction.reply(result.error ? ephemeral(result.message) : result.message);
  },
);

define(
  new SlashCommandBuilder().setName('fila').setDescription('Mostra as próximas músicas'),
  async (interaction) => {
    const snapshot = music.snapshot(interaction.guild.id);
    if (!snapshot?.current) return interaction.reply(ephemeral('Não há nada tocando agora.'));

    const upcoming = snapshot.upcoming
      .map((track, i) => `**${i + 1}.**${track.title} \`${track.durationText}\``)
      .join('\n');

    const embed = baseEmbed('Fila de reprodução')
      .setDescription(`▶️ **${snapshot.current.title}**\n\n${upcoming || 'Nada depois desta.'}`)
      .setFooter({
        text: `${snapshot.total} na fila · volume ${snapshot.volume}\% · repetição ${snapshot.loop}`,
      });
    return interaction.reply({ embeds: [embed] });
  },
);

// ---------------------------------------------------------------------------
// Moderação
// ---------------------------------------------------------------------------

define(
  new SlashCommandBuilder()
    .setName('limpar')
    .setDescription('Apaga mensagens recentes do canal')
    .addIntegerOption((option) =>
      option.setName('quantidade').setDescription('1 a 100').setRequired(true).setMinValue(1).setMaxValue(100),
    )
    .addUserOption((option) => option.setName('usuario').setDescription('Apagar só deste membro'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  async (interaction) => {
    const amount = interaction.options.getInteger('quantidade');
    const target = interaction.options.getUser('usuario');
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const messages = await interaction.channel.messages.fetch({ limit: 100 });
    const cutoff = Date.now() - 14 * 86400000;
    const selected = [...messages.values()]
      .filter((message) => message.createdTimestamp > cutoff)
      .filter((message) => !target || message.author.id === target.id)
      .slice(0, amount);

    if (!selected.length) {
      return interaction.editReply('Nada para apagar: as mensagens têm mais de 14 dias ou não existem.');
    }

    const deleted = await interaction.channel.bulkDelete(selected, true).catch(() => null);
    if (!deleted) return interaction.editReply('Não consegui apagar. Confira a permissão "Gerenciar mensagens".');

    store.addLog(
      interaction.guild.id,
      'Limpeza',
      `${interaction.user.tag} apagou${deleted.size} mensagens em #${interaction.channel.name}.`,
    );
    return interaction.editReply(`${deleted.size} mensagens apagadas.`);
  },
);

define(
  new SlashCommandBuilder()
    .setName('avisar')
    .setDescription('Registra um aviso para um membro')
    .addUserOption((option) => option.setName('usuario').setDescription('Quem será avisado').setRequired(true))
    .addStringOption((option) => option.setName('motivo').setDescription('Motivo do aviso'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async (interaction) => {
    const target = interaction.options.getUser('usuario');
    const reason = interaction.options.getString('motivo') || 'Sem motivo informado';
    const total = moderation.addWarn(interaction.guild.id, target.id, interaction.user.id, reason);

    await target.send(`Você recebeu um aviso em **${interaction.guild.name}**:${reason}`).catch(() => {});
    store.addLog(interaction.guild.id, 'Aviso', `${target.tag} avisado por ${interaction.user.tag}:${reason}`);
    return interaction.reply(`${target} recebeu um aviso (${total} no total). Motivo: ${escapeMentions(reason)}`);
  },
);

define(
  new SlashCommandBuilder()
    .setName('avisos')
    .setDescription('Lista os avisos de um membro')
    .addUserOption((option) => option.setName('usuario').setDescription('De quem').setRequired(true))
    .addBooleanOption((option) => option.setName('limpar').setDescription('Apagar todos os avisos deste membro'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async (interaction) => {
    const target = interaction.options.getUser('usuario');
    if (interaction.options.getBoolean('limpar')) {
      const removed = moderation.clearWarns(interaction.guild.id, target.id);
      return interaction.reply(`${removed} aviso(s) de${target} foram apagados.`);
    }

    const warns = moderation.getWarns(interaction.guild.id, target.id);
    const embed = baseEmbed(`Avisos de ${target.username}`, CLAY).setDescription(
      warns
        .map((warn, i) => `**${i + 1}.** <t:${Math.floor(warn.at / 1000)}:d> — ${warn.reason} (por <@${warn.by}>)`)
        .join('\n') || 'Este membro não tem avisos.',
    );
    return interaction.reply({ embeds: [embed] });
  },
);

define(
  new SlashCommandBuilder()
    .setName('castigo')
    .setDescription('Deixa um membro de castigo por um tempo')
    .addUserOption((option) => option.setName('usuario').setDescription('Quem').setRequired(true))
    .addStringOption((option) =>
      option.setName('tempo').setDescription('Ex: 10m, 2h, 1d').setRequired(true),
    )
    .addStringOption((option) => option.setName('motivo').setDescription('Motivo'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async (interaction) => {
    const member = interaction.options.getMember('usuario');
    const duration = parseDuration(interaction.options.getString('tempo'));
    const reason = interaction.options.getString('motivo') || 'Sem motivo informado';

    if (!member) return interaction.reply(ephemeral('Esse membro não está no servidor.'));
    const blockedTimeout = hierarchyBlock(interaction, member);
    if (blockedTimeout) return interaction.reply(ephemeral(blockedTimeout));
    if (!duration || duration > 28 * 86400000) {
      return interaction.reply(ephemeral('Use um tempo entre 1 minuto e 28 dias, como `10m` ou `2h`.'));
    }
    if (!member.moderatable) return interaction.reply(ephemeral('Não consigo aplicar castigo nesse membro.'));

    await member.timeout(duration, `${reason} — por${interaction.user.tag}`);
    store.addLog(interaction.guild.id, 'Castigo', `${member.user.tag} por ${formatDuration(duration)}:${reason}`);
    return interaction.reply(`${member} ficou de castigo por ${formatDuration(duration)}. Motivo: ${escapeMentions(reason)}`);
  },
);

define(
  new SlashCommandBuilder()
    .setName('expulsar')
    .setDescription('Expulsa um membro')
    .addUserOption((option) => option.setName('usuario').setDescription('Quem').setRequired(true))
    .addStringOption((option) => option.setName('motivo').setDescription('Motivo'))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
  async (interaction) => {
    const member = interaction.options.getMember('usuario');
    const reason = interaction.options.getString('motivo') || 'Sem motivo informado';
    if (!member) return interaction.reply(ephemeral('Esse membro não está no servidor.'));
    const blockedKick = hierarchyBlock(interaction, member);
    if (blockedKick) return interaction.reply(ephemeral(blockedKick));
    if (!member.kickable) return interaction.reply(ephemeral('Não consigo expulsar esse membro.'));

    await member.kick(`${reason} — por${interaction.user.tag}`);
    store.addLog(interaction.guild.id, 'Expulsão', `${member.user.tag} expulso por ${interaction.user.tag}:${reason}`);
    return interaction.reply(`${member.user.tag} foi expulso. Motivo: ${escapeMentions(reason)}`);
  },
);

define(
  new SlashCommandBuilder()
    .setName('banir')
    .setDescription('Bane um membro')
    .addUserOption((option) => option.setName('usuario').setDescription('Quem').setRequired(true))
    .addStringOption((option) => option.setName('motivo').setDescription('Motivo'))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  async (interaction) => {
    const user = interaction.options.getUser('usuario');
    const member = interaction.options.getMember('usuario');
    const reason = interaction.options.getString('motivo') || 'Sem motivo informado';
    if (user.id === interaction.user.id) return interaction.reply(ephemeral('Você não pode banir a si mesmo.'));
    const blockedBan = hierarchyBlock(interaction, member);
    if (blockedBan) return interaction.reply(ephemeral(blockedBan));
    if (member && !member.bannable) return interaction.reply(ephemeral('Não consigo banir esse membro.'));

    await interaction.guild.members.ban(user.id, { reason: `${reason} — por${interaction.user.tag}` });
    store.addLog(interaction.guild.id, 'Banimento', `${user.tag} banido por ${interaction.user.tag}:${reason}`);
    return interaction.reply(`${user.tag} foi banido. Motivo: ${escapeMentions(reason)}`);
  },
);

// ---------------------------------------------------------------------------
// Sorteios
// ---------------------------------------------------------------------------

define(
  new SlashCommandBuilder()
    .setName('sorteio')
    .setDescription('Gerencia sorteios')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((sub) =>
      sub
        .setName('criar')
        .setDescription('Inicia um sorteio')
        .addStringOption((o) => o.setName('premio').setDescription('O que será sorteado').setRequired(true))
        .addStringOption((o) => o.setName('duracao').setDescription('Ex: 30m, 2h, 1d').setRequired(true))
        .addIntegerOption((o) => o.setName('ganhadores').setDescription('Quantos ganhadores').setMinValue(1).setMaxValue(20))
        .addChannelOption((o) =>
          o.setName('canal').setDescription('Onde publicar').addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement),
        )
        .addRoleOption((o) => o.setName('cargo').setDescription('Cargo obrigatório para participar'))
        .addIntegerOption((o) => o.setName('nivel').setDescription('Nível mínimo para participar').setMinValue(1)),
    )
    .addSubcommand((sub) =>
      sub
        .setName('encerrar')
        .setDescription('Encerra um sorteio agora')
        .addStringOption((o) => o.setName('id').setDescription('ID do sorteio').setRequired(true)),
    )
    .addSubcommand((sub) =>
      sub
        .setName('resortear')
        .setDescription('Sorteia novos ganhadores')
        .addStringOption((o) => o.setName('id').setDescription('ID do sorteio').setRequired(true)),
    )
    .addSubcommand((sub) => sub.setName('listar').setDescription('Lista os sorteios do servidor')),
  async (interaction) => {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (sub === 'criar') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const result = await giveaways.create(interaction.client, guildId, {
        channelId: (interaction.options.getChannel('canal') ?? interaction.channel).id,
        prize: interaction.options.getString('premio'),
        durationMs: parseDuration(interaction.options.getString('duracao')),
        winnerCount: interaction.options.getInteger('ganhadores') ?? 1,
        requiredRoleId: interaction.options.getRole('cargo')?.id ?? '',
        requiredLevel: interaction.options.getInteger('nivel') ?? 0,
        createdBy: interaction.user.tag,
      });
      return interaction.editReply(
        result.error ? result.message : `${result.message} ID: \`${result.giveaway.id}\``,
      );
    }

    if (sub === 'listar') {
      const list = store.guild(guildId).giveaways.slice(-10).reverse();
      const embed = baseEmbed('Sorteios', GOLD).setDescription(
        list
          .map(
            (g) =>
              `\`${g.id}\` — ${g.prize} · ${g.ended ? 'encerrado' : `termina <t:${Math.floor(g.endsAt / 1000)}:R>`}`,
          )
          .join('\n') || 'Nenhum sorteio criado ainda.',
      );
      return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const result = await giveaways.end(interaction.client, guildId, interaction.options.getString('id'), {
      reroll: sub === 'resortear',
    });
    return interaction.editReply(result.message);
  },
);

// ---------------------------------------------------------------------------
// Tickets
// ---------------------------------------------------------------------------

define(
  new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Ferramentas da equipe dentro de um ticket')
    .addSubcommand((sub) =>
      sub
        .setName('adicionar')
        .setDescription('Adiciona um membro a este ticket')
        .addUserOption((o) => o.setName('usuario').setDescription('Quem entra no ticket').setRequired(true)),
    )
    .addSubcommand((sub) =>
      sub
        .setName('remover')
        .setDescription('Tira um membro deste ticket')
        .addUserOption((o) => o.setName('usuario').setDescription('Quem sai do ticket').setRequired(true)),
    )
    .addSubcommand((sub) =>
      sub
        .setName('fechar')
        .setDescription('Fecha este ticket guardando o motivo')
        .addStringOption((o) => o.setName('motivo').setDescription('Por que está fechando').setMaxLength(300)),
    ),
  async (interaction) => {
    const sub = interaction.options.getSubcommand();
    if (sub === 'fechar') return tickets.closeWithReason(interaction);
    return tickets.manageMember(interaction, sub === 'adicionar');
  },
);

// ---------------------------------------------------------------------------
// Sugestões
// ---------------------------------------------------------------------------

define(
  new SlashCommandBuilder()
    .setName('sugerir')
    .setDescription('Envia uma sugestão para o servidor')
    .addStringOption((o) => o.setName('ideia').setDescription('Descreva a sua sugestão').setRequired(true).setMaxLength(1500)),
  async (interaction) => {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const result = await suggestions.create(interaction.client, interaction.guild, interaction.user, interaction.options.getString('ideia'));
    return interaction.editReply(result.error ? `⚠️ ${result.message}` : `✅ ${result.message}`);
  },
);

define(
  new SlashCommandBuilder()
    .setName('sugestao')
    .setDescription('Responde a uma sugestão (equipe)')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((sub) =>
      sub
        .setName('aprovar')
        .setDescription('Aprova uma sugestão')
        .addIntegerOption((o) => o.setName('numero').setDescription('Número da sugestão').setRequired(true).setMinValue(1))
        .addStringOption((o) => o.setName('motivo').setDescription('Motivo da aprovação')),
    )
    .addSubcommand((sub) =>
      sub
        .setName('negar')
        .setDescription('Nega uma sugestão')
        .addIntegerOption((o) => o.setName('numero').setDescription('Número da sugestão').setRequired(true).setMinValue(1))
        .addStringOption((o) => o.setName('motivo').setDescription('Motivo do indeferimento')),
    ),
  async (interaction) => {
    const sub = interaction.options.getSubcommand();
    const id = interaction.options.getInteger('numero');
    const reason = interaction.options.getString('motivo') || 'Sem motivo informado';
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const result = await suggestions.respond(
      interaction.client,
      interaction.guild,
      id,
      sub === 'aprovar',
      reason,
      interaction.user,
    );
    return interaction.editReply(result.error ? `⚠️ ${result.message}` : `✅ ${result.message}`);
  },
);

// ---------------------------------------------------------------------------
// Funções de Registro e Tratamento exportadas para o index.js
// ---------------------------------------------------------------------------

async function register(client) {
  if (!client.application) return;
  const payload = commands.map((c) => (c.data.toJSON ? c.data.toJSON() : c.data));
  await client.application.commands.set(payload);
}

async function handle(interaction) {
  if (!interaction.isChatInputCommand()) return;
  const cmd = commands.find((c) => c.data.name === interaction.commandName);
  if (!cmd) return;
  try {
    await cmd.run(interaction);
  } catch (err) {
    console.error(`Erro no comando /${interaction.commandName}:`, err);
    const method = interaction.deferred || interaction.replied ? 'editReply' : 'reply';
    await interaction[method]({
      content: '⚠️ Ocorreu um erro ao processar o comando.',
      flags: MessageFlags.Ephemeral,
    }).catch(() => {});
  }
}

module.exports = { commands, register, handle };