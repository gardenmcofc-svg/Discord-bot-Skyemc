'use strict';

const {
  ChannelType,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  MessageFlags,
  AttachmentBuilder,
  SnowflakeUtil,
} = require('discord.js');

const { store } = require('../store');
const { applyVariables, log, escapeMentions, errorMessage, getBotMember } = require('../util');

const OPEN_ID = 'ticket:open';
const SELECT_ID = 'ticket:category';
const CLAIM_ID = 'ticket:claim';
const CLOSE_ID = 'ticket:close';
const CONFIRM_ID = 'ticket:close:confirm';
const CANCEL_ID = 'ticket:close:cancel';
const RATE_PREFIX = 'ticket:rate:';

const MAX_RECORDS = 500; // tickets guardados no histórico
const KEEP_TRANSCRIPTS = 60; // só os mais recentes guardam a conversa completa
const MAX_LINES = 250;

const ephemeral = (content) => ({ content, flags: MessageFlags.Ephemeral });

// ---------------------------------------------------------------------------
// Registros (o histórico que o painel mostra)
// ---------------------------------------------------------------------------

const guildData = (guildId) => store.guild(guildId);

function findOpenByChannel(guildId, channelId) {
  return guildData(guildId).ticketList.find((t) => t.channelId === channelId && t.status === 'open') || null;
}

function findById(guildId, id) {
  return guildData(guildId).ticketList.find((t) => t.id === Number(id)) || null;
}

/** Mantém o histórico enxuto: poucos registros e transcrições só dos mais novos. */
function trimRecords(guildId) {
  const list = guildData(guildId).ticketList;
  if (list.length > MAX_RECORDS) list.splice(0, list.length - MAX_RECORDS);
  const cutoff = list.length - KEEP_TRANSCRIPTS;
  list.forEach((ticket, index) => {
    if (index < cutoff && ticket.transcript) delete ticket.transcript;
  });
}

function newRecord(guildId, fields) {
  const data = guildData(guildId);
  data.ticketSeq += 1;
  const record = {
    id: data.ticketSeq,
    channelId: '',
    userId: '',
    userTag: '',
    category: null,
    categoryLabel: '',
    status: 'open',
    claimedBy: null,
    openedAt: Date.now(),
    closedAt: null,
    closedBy: null,
    closeReason: '',
    messageCount: 0,
    rating: null,
    ...fields,
  };
  data.ticketList.push(record);
  trimRecords(guildId);
  store.save();
  return record;
}

/** Resumo sem a conversa, leve para a lista do painel. */
function summary(record) {
  const { transcript, ...rest } = record; // eslint-disable-line no-unused-vars
  return rest;
}

function stats(guildId) {
  const list = guildData(guildId).ticketList;
  const rated = list.filter((t) => t.rating);
  return {
    total: list.length,
    open: list.filter((t) => t.status === 'open').length,
    closed: list.filter((t) => t.status === 'closed').length,
    ratedCount: rated.length,
    averageRating: rated.length ? Number((rated.reduce((sum, t) => sum + t.rating, 0) / rated.length).toFixed(2)) : null,
  };
}

// ---------------------------------------------------------------------------
// Painel público (botão ou menu de categorias)
// ---------------------------------------------------------------------------

function panelPayload(settings) {
  const embed = new EmbedBuilder()
    .setTitle(settings.embedTitle || '🎫 Central de suporte')
    .setDescription(settings.embedDesc || 'Clique no botão abaixo para abrir um ticket.')
    .setColor(settings.embedColor || '#57C785');

  if (settings.categories?.length) {
    const menu = new StringSelectMenuBuilder()
      .setCustomId(SELECT_ID)
      .setPlaceholder((settings.buttonText || 'Escolha o assunto do ticket').slice(0, 100))
      .addOptions(
        settings.categories.slice(0, 25).map((category) => {
          const option = {
            label: `${category.emoji ? `${category.emoji} ` : ''}${category.label}`.slice(0, 100),
            value: category.id,
          };
          if (category.description) option.description = category.description.slice(0, 100);
          return option;
        }),
      );
    return { embeds: [embed], components: [new ActionRowBuilder().addComponents(menu)] };
  }

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(OPEN_ID)
      .setLabel(settings.buttonText || '📩 Abrir ticket')
      .setStyle(ButtonStyle.Success),
  );
  return { embeds: [embed], components: [row] };
}

async function sendPanel(client, guildId) {
  const settings = store.guild(guildId).tickets;
  if (!settings.channelId) {
    return { error: true, message: 'Escolha primeiro o canal onde o painel deve aparecer.' };
  }
  const channel = await client.channels.fetch(settings.channelId).catch(() => null);
  if (!channel?.isTextBased()) {
    return { error: true, message: 'Canal do painel não encontrado. Ele foi apagado?' };
  }
  try {
    await channel.send(panelPayload(settings));
    store.addLog(guildId, 'Tickets', `Painel publicado em #${channel.name}.`);
    return { error: false, message: `Painel publicado em #${channel.name}.` };
  } catch (err) {
    return { error: true, message: `Não consegui publicar: ${errorMessage(err)}` };
  }
}

// ---------------------------------------------------------------------------
// Identificação do canal
// ---------------------------------------------------------------------------

/** O tópico do canal guarda o dono ("Ticket de nome (id)"); o nome pode mudar ao assumir. */
const TOPIC_RE = /^Ticket de .* \((\d{17,20})\)$/;

const isTicketChannel = (channel) => TOPIC_RE.test(channel?.topic || '');
const ticketOwnerId = (channel) => channel?.topic?.match(TOPIC_RE)?.[1] || null;

function isSupport(member, settings) {
  return (
    member.permissions.has(PermissionFlagsBits.ManageChannels) ||
    Boolean(settings.supportRoleId && member.roles.cache.has(settings.supportRoleId))
  );
}

// ---------------------------------------------------------------------------
// Abrir
// ---------------------------------------------------------------------------

async function openTicket(interaction, categoryId = null) {
  const guild = interaction.guild;
  const settings = store.guild(guild.id).tickets;
  const member = interaction.member;

  if (!settings.enabled) {
    return interaction.reply(ephemeral('O sistema de tickets está desligado no momento.'));
  }

  const category = categoryId ? settings.categories.find((c) => c.id === categoryId) : null;
  if (categoryId && !category) {
    return interaction.reply(ephemeral('Essa categoria não existe mais. Peça à equipe para publicar o painel de novo.'));
  }

  const existing = guild.channels.cache.filter(
    (channel) => isTicketChannel(channel) && ticketOwnerId(channel) === member.id,
  );
  if (existing.size >= (settings.maxPerUser || 1)) {
    return interaction.reply(ephemeral(`Você já tem um ticket aberto em ${existing.first()}.`));
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const botMember = await getBotMember(guild);
  if (!botMember?.permissions.has(PermissionFlagsBits.ManageChannels)) {
    return interaction.editReply('O bot não tem a permissão "Gerenciar canais" neste servidor. Confira o cargo do bot em Configurações do servidor → Cargos.');
  }

  try {
    const base = [
      PermissionFlagsBits.ViewChannel,
      PermissionFlagsBits.SendMessages,
      PermissionFlagsBits.ReadMessageHistory,
    ];
    const overwrites = [
      { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
      { id: member.id, allow: [...base, PermissionFlagsBits.AttachFiles] },
      { id: botMember.id, allow: [...base, PermissionFlagsBits.ManageChannels] },
    ];
    if (settings.supportRoleId && guild.roles.cache.has(settings.supportRoleId)) {
      overwrites.push({ id: settings.supportRoleId, allow: base });
    }

    const parent = settings.categoryId ? guild.channels.cache.get(settings.categoryId) : null;
    const number = store.guild(guild.id).ticketSeq + 1;
    const slug = member.user.username.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 20) || 'membro';

    const channel = await guild.channels.create({
      name: `ticket-${String(number).padStart(4, '0')}-${slug}`,
      type: ChannelType.GuildText,
      parent: parent?.type === ChannelType.GuildCategory ? parent.id : null,
      topic: `Ticket de ${member.user.tag} (${member.id})`,
      permissionOverwrites: overwrites,
    });

    const record = newRecord(guild.id, {
      channelId: channel.id,
      userId: member.id,
      userTag: member.user.tag,
      category: category?.id ?? null,
      categoryLabel: category ? `${category.emoji ? `${category.emoji} ` : ''}${category.label}` : '',
    });

    const embed = new EmbedBuilder()
      .setTitle(`Ticket #${record.id}${category ? ` · ${category.label}` : ''}`)
      .setDescription(applyVariables(settings.ticketWelcomeMsg, { member, guild }))
      .setColor(settings.embedColor || '#57C785')
      .setFooter({ text: `Aberto por ${member.user.username}` })
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(CLAIM_ID).setLabel('Assumir atendimento').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(CLOSE_ID).setLabel('Fechar ticket').setStyle(ButtonStyle.Danger),
    );

    const mention = settings.supportRoleId ? `<@&${settings.supportRoleId}> ` : '';
    await channel.send({ content: `${mention}${member}`, embeds: [embed], components: [row] });

    store.guild(guild.id).stats.ticketsOpened += 1;
    store.addLog(guild.id, 'Ticket aberto', `#${record.id} de ${member.user.tag}${category ? ` (${category.label})` : ''}.`);
    await interaction.editReply(`Pronto, seu ticket #${record.id} está em ${channel}.`);
  } catch (err) {
    log.error('Erro ao abrir ticket:', errorMessage(err));
    await interaction.editReply('Não consegui criar o canal. Confira as permissões do bot e a categoria escolhida.');
  }
  return undefined;
}

/** Menu de categorias: abre o ticket e devolve o menu ao estado inicial. */
async function handleSelect(interaction) {
  const categoryId = interaction.values?.[0];
  const result = await openTicket(interaction, categoryId);
  // O Discord mantém a opção marcada; recarregar o painel deixa o membro escolher a mesma de novo depois.
  const settings = store.guild(interaction.guild.id).tickets;
  await interaction.message?.edit(panelPayload(settings)).catch(() => {});
  return result;
}

// ---------------------------------------------------------------------------
// Assumir e fechar
// ---------------------------------------------------------------------------

async function claimTicket(interaction) {
  const settings = store.guild(interaction.guild.id).tickets;
  if (!isSupport(interaction.member, settings)) {
    return interaction.reply(ephemeral('Só a equipe de suporte pode assumir tickets.'));
  }
  const record = findOpenByChannel(interaction.guild.id, interaction.channel.id);
  if (record?.claimedBy && record.claimedBy.id !== interaction.user.id) {
    return interaction.reply(ephemeral(`Este ticket já foi assumido por ${record.claimedBy.tag}.`));
  }
  if (record) {
    record.claimedBy = { id: interaction.user.id, tag: interaction.user.tag };
    store.save();
  }
  await interaction.reply(`🙋 ${interaction.user} assumiu este atendimento.`);
  await interaction.channel.setName(interaction.channel.name.replace(/^ticket-/, 'atend-')).catch(() => {});
  return undefined;
}

const canClose = (interaction) =>
  ticketOwnerId(interaction.channel) === interaction.user.id ||
  isSupport(interaction.member, store.guild(interaction.guild.id).tickets);

async function requestClose(interaction) {
  if (!canClose(interaction)) {
    return interaction.reply(ephemeral('Só quem abriu o ticket ou a equipe pode fechá-lo.'));
  }
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(CONFIRM_ID).setLabel('Confirmar fechamento').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(CANCEL_ID).setLabel('Cancelar').setStyle(ButtonStyle.Secondary),
  );
  return interaction.reply({ content: 'Fechar este ticket? O canal será apagado.', components: [row] });
}

async function cancelClose(interaction) {
  if (!canClose(interaction)) {
    return interaction.reply(ephemeral('Só quem abriu o ticket ou a equipe pode decidir isso.'));
  }
  return interaction.update({ content: 'Fechamento cancelado. O ticket continua aberto.', components: [] });
}

async function confirmClose(interaction) {
  if (!canClose(interaction)) {
    return interaction.reply(ephemeral('Só quem abriu o ticket ou a equipe pode fechá-lo.'));
  }
  await interaction.update({ content: 'Fechando o ticket em 5 segundos…', components: [] });
  await finalizeClose(interaction.client, interaction.guild, interaction.channel, {
    id: interaction.user.id,
    tag: interaction.user.tag,
  });
  return undefined;
}

/** Ticket criado antes desta versão: cria o registro na hora para o histórico não perdê-lo. */
function adoptLegacy(guild, channel) {
  return newRecord(guild.id, {
    channelId: channel.id,
    userId: ticketOwnerId(channel) || '',
    userTag: channel.topic?.replace(/^Ticket de /, '').replace(/ \(\d+\)$/, '') || 'desconhecido',
    openedAt: channel.createdTimestamp || Date.now(),
  });
}

const closing = new Set();

/**
 * Fecha de verdade: guarda a conversa no histórico, manda a cópia para o canal de registros,
 * pede a avaliação no privado e apaga o canal. Serve para o botão, o comando e o painel.
 */
async function finalizeClose(client, guild, channel, by, reason = '') {
  if (closing.has(channel.id)) return null;
  closing.add(channel.id);

  const settings = store.guild(guild.id).tickets;
  const record = findOpenByChannel(guild.id, channel.id) || adoptLegacy(guild, channel);

  let lines = [];
  try {
    lines = await collectTranscript(channel);
  } catch (err) {
    log.error('Não consegui ler a conversa do ticket:', errorMessage(err));
  }

  record.status = 'closed';
  record.closedAt = Date.now();
  record.closedBy = by.tag;
  record.closeReason = String(reason || '').slice(0, 300);
  record.messageCount = lines.length;
  record.transcript = lines.slice(-MAX_LINES);
  trimRecords(guild.id);
  store.save();

  if (settings.transcripts && settings.logChannelId) {
    await sendTranscriptToLog(guild, channel, record, lines, settings.logChannelId).catch((err) =>
      log.error('Transcrição falhou:', errorMessage(err)),
    );
  }
  if (settings.ratings && record.userId) {
    await askForRating(client, guild, record).catch(() => {});
  }

  store.addLog(guild.id, 'Ticket fechado', `#${record.id} fechado por ${by.tag}${reason ? ` — ${reason}` : ''}.`);
  setTimeout(() => {
    channel.delete().catch(() => {});
    closing.delete(channel.id);
  }, 5000).unref?.();
  return record;
}

// ---------------------------------------------------------------------------
// Conversa (transcrição)
// ---------------------------------------------------------------------------

function messageText(message) {
  const embeds = message.embeds
    .map((embed) => [embed.title, embed.description].filter(Boolean).join(' — '))
    .filter(Boolean)
    .join(' ');
  return (message.content || embeds || '').slice(0, 1500);
}

/** Últimas mensagens do canal, da mais antiga para a mais nova. */
async function collectTranscript(channel) {
  const messages = await channel.messages.fetch({ limit: 100 });
  return [...messages.values()]
    .reverse()
    .map((message) => ({
      at: message.createdTimestamp,
      author: message.author?.tag || 'desconhecido',
      authorId: message.author?.id || '',
      bot: Boolean(message.author?.bot),
      content: messageText(message),
      attachments: [...message.attachments.values()].map((a) => a.url).slice(0, 5),
    }));
}

async function sendTranscriptToLog(guild, channel, record, lines, logChannelId) {
  const logChannel = guild.channels.cache.get(logChannelId);
  if (!logChannel?.isTextBased()) return;

  const text = lines
    .map((line) => {
      const time = new Date(line.at).toLocaleString('pt-BR');
      return `[${time}] ${line.author}: ${line.content} ${line.attachments.join(' ')}`.trim();
    })
    .join('\n');

  const file = new AttachmentBuilder(Buffer.from(text || 'Ticket sem mensagens.', 'utf8'), {
    name: `ticket-${String(record.id).padStart(4, '0')}.txt`,
  });

  const embed = new EmbedBuilder()
    .setTitle(`Ticket #${record.id} encerrado`)
    .setColor('#8ba394')
    .addFields(
      { name: 'Aberto por', value: record.userTag || '—', inline: true },
      { name: 'Fechado por', value: record.closedBy || '—', inline: true },
      { name: 'Mensagens', value: String(lines.length), inline: true },
    )
    .setTimestamp();
  if (record.categoryLabel) embed.addFields({ name: 'Categoria', value: record.categoryLabel, inline: true });
  if (record.claimedBy) embed.addFields({ name: 'Atendido por', value: record.claimedBy.tag, inline: true });
  if (record.closeReason) embed.addFields({ name: 'Motivo', value: record.closeReason });

  await logChannel.send({ embeds: [embed], files: [file] });
}

// ---------------------------------------------------------------------------
// Avaliação no privado
// ---------------------------------------------------------------------------

async function askForRating(client, guild, record) {
  const user = await client.users.fetch(record.userId);
  const buttons = [1, 2, 3, 4, 5].map((n) =>
    new ButtonBuilder()
      .setCustomId(`${RATE_PREFIX}${guild.id}:${record.id}:${n}`)
      .setLabel(`${n} ⭐`)
      .setStyle(n >= 4 ? ButtonStyle.Success : n === 3 ? ButtonStyle.Secondary : ButtonStyle.Danger),
  );
  const embed = new EmbedBuilder()
    .setTitle('Como foi o seu atendimento?')
    .setDescription(`Seu ticket #${record.id} em **${guild.name}** foi encerrado. Dê uma nota de 1 a 5 — leva um segundo e ajuda a equipe.`)
    .setColor('#e8b84b');
  await user.send({ embeds: [embed], components: [new ActionRowBuilder().addComponents(buttons)] });
}

async function handleRating(interaction) {
  const [, , guildId, ticketId, value] = interaction.customId.split(':');
  const record = findById(guildId, ticketId);
  const rating = Number(value);

  if (!record || record.userId !== interaction.user.id || !(rating >= 1 && rating <= 5)) {
    return interaction.reply(ephemeral('Não consegui registrar essa avaliação.'));
  }
  record.rating = rating;
  store.save();
  store.addLog(guildId, 'Avaliação', `Ticket #${record.id} recebeu nota ${rating}/5 de ${record.userTag}.`);
  return interaction.update({
    content: `Obrigado! Você avaliou o ticket #${record.id} com ${'⭐'.repeat(rating)}.`,
    embeds: [],
    components: [],
  });
}

// ---------------------------------------------------------------------------
// Comandos da equipe dentro do ticket: /ticket adicionar | remover | fechar
// ---------------------------------------------------------------------------

async function manageMember(interaction, add) {
  const settings = store.guild(interaction.guild.id).tickets;
  if (!isTicketChannel(interaction.channel)) {
    return interaction.reply(ephemeral('Use este comando dentro de um canal de ticket.'));
  }
  if (!isSupport(interaction.member, settings)) {
    return interaction.reply(ephemeral('Só a equipe de suporte pode fazer isso.'));
  }

  const user = interaction.options.getUser('usuario');
  if (add) {
    await interaction.channel.permissionOverwrites.edit(user.id, {
      ViewChannel: true,
      SendMessages: true,
      ReadMessageHistory: true,
      AttachFiles: true,
    });
    return interaction.reply(`➕ ${user} foi adicionado(a) ao ticket.`);
  }
  if (user.id === ticketOwnerId(interaction.channel)) {
    return interaction.reply(ephemeral('Não dá para remover quem abriu o ticket. Feche o ticket no lugar.'));
  }
  await interaction.channel.permissionOverwrites.delete(user.id);
  return interaction.reply(`➖ ${user.tag} foi removido(a) do ticket.`);
}

async function closeWithReason(interaction) {
  const settings = store.guild(interaction.guild.id).tickets;
  if (!isTicketChannel(interaction.channel)) {
    return interaction.reply(ephemeral('Use este comando dentro de um canal de ticket.'));
  }
  if (!isSupport(interaction.member, settings)) {
    return interaction.reply(ephemeral('Só a equipe de suporte pode fechar tickets por comando.'));
  }
  const reason = interaction.options.getString('motivo') || '';
  await interaction.reply(`🔒 Fechando o ticket em 5 segundos…${reason ? `\n**Motivo:** ${escapeMentions(reason)}` : ''}`);
  await finalizeClose(interaction.client, interaction.guild, interaction.channel, {
    id: interaction.user.id,
    tag: interaction.user.tag,
  }, reason);
  return undefined;
}

// ---------------------------------------------------------------------------
// Ações pelo painel web
// ---------------------------------------------------------------------------

function list(guildId, { status = 'all', query = '' } = {}) {
  const term = String(query).trim().toLowerCase();
  return guildData(guildId)
    .ticketList.filter((t) => status === 'all' || t.status === status)
    .filter((t) => !term || `${t.id} ${t.userTag} ${t.categoryLabel} ${t.claimedBy?.tag ?? ''}`.toLowerCase().includes(term))
    .reverse()
    .slice(0, 200)
    .map(summary);
}

/** Aberto: lê a conversa ao vivo. Fechado: usa a que ficou guardada. */
async function detail(client, guildId, ticketId) {
  const record = findById(guildId, ticketId);
  if (!record) return null;

  let transcript = record.transcript || [];
  if (record.status === 'open') {
    const channel = await client.channels.fetch(record.channelId).catch(() => null);
    if (channel?.messages) transcript = await collectTranscript(channel).catch(() => []);
  }
  return { ticket: summary(record), transcript };
}

async function closeFromPanel(client, guildId, ticketId, reason) {
  const record = findById(guildId, ticketId);
  if (!record) return { error: true, message: 'Ticket não encontrado.' };
  if (record.status !== 'open') return { error: true, message: 'Este ticket já está fechado.' };

  const guild = client.guilds.cache.get(guildId);
  const channel = await client.channels.fetch(record.channelId).catch(() => null);

  if (!channel || !guild) {
    record.status = 'closed';
    record.closedAt = Date.now();
    record.closedBy = 'Painel web';
    record.closeReason = 'O canal já não existia.';
    store.save();
    return { error: false, message: `Ticket #${record.id} marcado como fechado (o canal já não existia).` };
  }

  await finalizeClose(client, guild, channel, { id: 'painel', tag: 'Painel web' }, reason);
  return { error: false, message: `Ticket #${record.id} fechado.` };
}

async function replyFromPanel(client, guildId, ticketId, text) {
  const record = findById(guildId, ticketId);
  if (!record || record.status !== 'open') return { error: true, message: 'Só dá para responder tickets abertos.' };
  const content = String(text || '').trim().slice(0, 1800);
  if (!content) return { error: true, message: 'Escreva a resposta antes de enviar.' };

  const channel = await client.channels.fetch(record.channelId).catch(() => null);
  if (!channel?.isTextBased()) return { error: true, message: 'O canal deste ticket não existe mais.' };

  const embed = new EmbedBuilder()
    .setColor('#57C785')
    .setAuthor({ name: 'Equipe de suporte' })
    .setDescription(escapeMentions(content))
    .setFooter({ text: 'Resposta enviada pelo painel' })
    .setTimestamp();
  await channel.send({ content: `<@${record.userId}>`, embeds: [embed] });
  store.addLog(guildId, 'Ticket', `Resposta enviada no ticket #${record.id} pelo painel.`);
  return { error: false, message: 'Resposta enviada no ticket.' };
}

/** Alguém apagou o canal na mão: o registro não pode ficar "aberto" para sempre. */
function onChannelDelete(channel) {
  if (!channel.guild) return;
  const record = findOpenByChannel(channel.guild.id, channel.id);
  if (!record || closing.has(channel.id)) return;
  record.status = 'closed';
  record.closedAt = Date.now();
  record.closedBy = 'canal apagado';
  record.closeReason = 'O canal foi apagado manualmente.';
  store.save();
  store.addLog(channel.guild.id, 'Ticket fechado', `#${record.id}: o canal foi apagado manualmente.`);
}

// ---------------------------------------------------------------------------
// Fechamento por inatividade (opt-in: autoCloseHours > 0)
// ---------------------------------------------------------------------------

let lastSweep = 0;

async function sweepInactive(client) {
  if (Date.now() - lastSweep < 600000) return;
  lastSweep = Date.now();

  for (const guild of client.guilds.cache.values()) {
    const settings = store.guild(guild.id).tickets;
    const hours = Number(settings.autoCloseHours) || 0;
    if (!hours) continue;

    for (const record of store.guild(guild.id).ticketList.filter((t) => t.status === 'open')) {
      const channel = guild.channels.cache.get(record.channelId);
      if (!channel) continue;
      const lastActivity = channel.lastMessageId
        ? SnowflakeUtil.timestampFrom(channel.lastMessageId)
        : record.openedAt;
      if (Date.now() - lastActivity < hours * 3600000) continue;

      await channel
        .send(`⏰ Este ticket ficou ${hours}h sem mensagens e será fechado por inatividade.`)
        .catch(() => {});
      await finalizeClose(client, guild, channel, { id: 'auto', tag: 'Fechamento automático' }, `Sem atividade por ${hours}h.`);
    }
  }
}

// ---------------------------------------------------------------------------
// Roteador dos botões
// ---------------------------------------------------------------------------

async function handleButton(interaction) {
  // A avaliação chega por mensagem privada, fora de qualquer servidor.
  if (interaction.customId.startsWith(RATE_PREFIX)) return handleRating(interaction);

  if (interaction.customId !== OPEN_ID && !isTicketChannel(interaction.channel)) {
    return interaction.reply(ephemeral('Este botão só funciona dentro de um ticket.'));
  }
  switch (interaction.customId) {
    case OPEN_ID:
      return openTicket(interaction);
    case CLAIM_ID:
      return claimTicket(interaction);
    case CLOSE_ID:
      return requestClose(interaction);
    case CONFIRM_ID:
      return confirmClose(interaction);
    case CANCEL_ID:
      return cancelClose(interaction);
    default:
      return false;
  }
}

module.exports = {
  sendPanel,
  panelPayload,
  handleButton,
  handleSelect,
  manageMember,
  closeWithReason,
  list,
  detail,
  stats,
  closeFromPanel,
  replyFromPanel,
  onChannelDelete,
  sweepInactive,
  SELECT_ID,
  OPEN_ID,
  CLAIM_ID,
  CLOSE_ID,
  CONFIRM_ID,
  CANCEL_ID,
};
