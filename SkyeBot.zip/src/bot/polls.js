'use strict';

const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');
const { store } = require('../store');
const { escapeMentions, errorMessage, formatDuration } = require('../util');

const PREFIX = 'poll:';
const MIN_MS = 30000;
const MAX_MS = 14 * 86400000;
const DEFAULT_MS = 86400000;
const MAX_KEPT = 100;

const ephemeral = (content) => ({ content, flags: MessageFlags.Ephemeral });
const data = (guildId) => store.guild(guildId);
const find = (guildId, id) => data(guildId).polls.find((p) => p.id === Number(id)) || null;

function tally(poll) {
  const counts = poll.options.map(() => 0);
  for (const index of Object.values(poll.votes)) counts[index] += 1;
  return { counts, total: counts.reduce((a, b) => a + b, 0) };
}

const bar = (share) => {
  const filled = Math.round(share * 10);
  return `${'▰'.repeat(filled)}${'▱'.repeat(10 - filled)}`;
};

function embedFor(poll) {
  const { counts, total } = tally(poll);
  const lines = poll.options.map((option, i) => {
    const share = total ? counts[i] / total : 0;
    return `**${i + 1}. ${escapeMentions(option)}**\n${bar(share)} ${Math.round(share * 100)}% · ${counts[i]} voto${counts[i] === 1 ? '' : 's'}`;
  });

  const embed = new EmbedBuilder()
    .setColor(poll.ended ? 0x8ba394 : 0x57c785)
    .setTitle(`📊 ${escapeMentions(poll.question)}`)
    .setDescription(lines.join('\n\n'))
    .setFooter({ text: `${total} voto${total === 1 ? '' : 's'} · ${poll.ended ? 'Enquete encerrada' : 'Você pode trocar o seu voto a qualquer momento'}` });
  if (!poll.ended) embed.addFields({ name: 'Termina', value: `<t:${Math.floor(poll.endsAt / 1000)}:R>` });
  return embed;
}

function rowFor(poll) {
  return new ActionRowBuilder().addComponents(
    poll.options.map((option, i) =>
      new ButtonBuilder()
        .setCustomId(`${PREFIX}${poll.id}:${i}`)
        .setLabel(`${i + 1}. ${option}`.slice(0, 80))
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(poll.ended),
    ),
  );
}

async function create(interaction, question, rawOptions, durationMs) {
  const options = String(rawOptions || '')
    .split('|')
    .map((o) => o.trim().slice(0, 70))
    .filter(Boolean);
  if (options.length < 2 || options.length > 5) {
    return { error: true, message: 'Informe de 2 a 5 opções separadas por | (ex: Sim | Não | Talvez).' };
  }
  const duration = durationMs || DEFAULT_MS;
  if (duration < MIN_MS || duration > MAX_MS) {
    return { error: true, message: 'A duração deve ficar entre 30 segundos e 14 dias.' };
  }

  const guildData = data(interaction.guild.id);
  guildData.pollSeq += 1;
  const poll = {
    id: guildData.pollSeq,
    question: String(question).trim().slice(0, 200),
    options,
    votes: {},
    channelId: interaction.channel.id,
    messageId: '',
    endsAt: Date.now() + duration,
    ended: false,
    createdBy: interaction.user.tag,
  };

  try {
    const message = await interaction.channel.send({ embeds: [embedFor(poll)], components: [rowFor(poll)] });
    poll.messageId = message.id;
  } catch (err) {
    guildData.pollSeq -= 1;
    return { error: true, message: `Não consegui publicar a enquete neste canal: ${errorMessage(err)}` };
  }

  guildData.polls.push(poll);
  if (guildData.polls.length > MAX_KEPT) guildData.polls.splice(0, guildData.polls.length - MAX_KEPT);
  store.save();
  return { error: false, message: `Enquete #${poll.id} publicada. Termina em ${formatDuration(duration)}.`, poll };
}

async function vote(interaction) {
  const [id, index] = interaction.customId.slice(PREFIX.length).split(':');
  const poll = find(interaction.guild.id, id);
  const option = Number(index);

  if (!poll) return interaction.reply(ephemeral('Essa enquete não existe mais.'));
  if (poll.ended || poll.endsAt <= Date.now()) return interaction.reply(ephemeral('Essa enquete já foi encerrada.'));
  if (!(option >= 0 && option < poll.options.length)) return interaction.reply(ephemeral('Opção inválida.'));

  const mine = interaction.user.id;
  if (poll.votes[mine] === option) delete poll.votes[mine]; // clicar de novo tira o voto
  else poll.votes[mine] = option;
  store.save();

  return interaction.update({ embeds: [embedFor(poll)], components: [rowFor(poll)] });
}

async function end(client, guildId, id) {
  const poll = find(guildId, id);
  if (!poll) return { error: true, message: 'Enquete não encontrada.' };
  if (poll.ended) return { error: true, message: 'Essa enquete já foi encerrada.' };

  poll.ended = true;
  store.save();

  const channel = await client.channels.fetch(poll.channelId).catch(() => null);
  const message = await channel?.messages?.fetch(poll.messageId).catch(() => null);
  await message?.edit({ embeds: [embedFor(poll)], components: [rowFor(poll)] }).catch(() => {});

  const { counts, total } = tally(poll);
  const top = Math.max(...counts);
  const winners = poll.options.filter((_, i) => counts[i] === top);
  const result = total === 0
    ? 'Ninguém votou.'
    : winners.length > 1
      ? `Empate entre: ${winners.map(escapeMentions).join(', ')}.`
      : `Venceu: **${escapeMentions(winners[0])}** (${top} de ${total} votos).`;

  await channel?.send?.(`📊 A enquete **${escapeMentions(poll.question)}** terminou. ${result}`).catch(() => {});
  store.addLog(guildId, 'Enquete', `#${poll.id} encerrada. ${result.replace(/\*\*/g, '')}`);
  return { error: false, message: `Enquete #${poll.id} encerrada. ${result.replace(/\*\*/g, '')}` };
}

async function tick(client) {
  for (const guildId of Object.keys(store.data.guilds)) {
    const due = store.guild(guildId).polls.filter((p) => !p.ended && p.endsAt <= Date.now());
    for (const poll of due) await end(client, guildId, poll.id);
  }
}

module.exports = { create, end, tick, vote, PREFIX };
