'use strict';

const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');
const { store } = require('../store');
const { escapeMentions, errorMessage, log } = require('../util');

const UP = 'sug:up:';
const DOWN = 'sug:down:';
const MAX_RECORDS = 300;
const COOLDOWN = 60000;

const COLORS = { pending: 0x8ba394, approved: 0x57c785, denied: 0xd4614a };
const LABELS = { pending: '⏳ Em votação', approved: '✅ Aprovada', denied: '❌ Negada' };

const ephemeral = (content) => ({ content, flags: MessageFlags.Ephemeral });
const lastSuggestion = new Map(); // guildId:userId -> quando

const data = (guildId) => store.guild(guildId);
const find = (guildId, id) => data(guildId).suggestionList.find((s) => s.id === Number(id)) || null;

function embedFor(record) {
  const embed = new EmbedBuilder()
    .setColor(COLORS[record.status])
    .setTitle(`Sugestão #${record.id}`)
    .setDescription(escapeMentions(record.text))
    .addFields(
      { name: 'Autor', value: `<@${record.userId}>`, inline: true },
      { name: 'Situação', value: LABELS[record.status], inline: true },
      { name: 'Votos', value: `👍 ${record.up.length} · 👎 ${record.down.length}`, inline: true },
    )
    .setTimestamp(record.createdAt);
  if (record.note) {
    embed.addFields({
      name: `Resposta da equipe${record.reviewedBy ? ` (${record.reviewedBy})` : ''}`,
      value: escapeMentions(record.note).slice(0, 1000),
    });
  }
  return embed;
}

function rowFor(record, disabled = false) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`${UP}${record.id}`).setLabel(`👍 ${record.up.length}`).setStyle(ButtonStyle.Success).setDisabled(disabled),
    new ButtonBuilder().setCustomId(`${DOWN}${record.id}`).setLabel(`👎 ${record.down.length}`).setStyle(ButtonStyle.Danger).setDisabled(disabled),
  );
}

async function create(client, guild, user, text) {
  const settings = data(guild.id).suggestions;
  if (!settings.enabled || !settings.channelId) {
    return { error: true, message: 'O sistema de sugestões não está ligado neste servidor.' };
  }
  const clean = String(text || '').trim();
  if (clean.length < 10) return { error: true, message: 'Descreva melhor a sua ideia (pelo menos 10 caracteres).' };
  if (clean.length > 1500) return { error: true, message: 'Texto grande demais. Resuma em até 1500 caracteres.' };

  const key = `${guild.id}:${user.id}`;
  const wait = COOLDOWN - (Date.now() - (lastSuggestion.get(key) || 0));
  if (wait > 0) return { error: true, message: `Espere ${Math.ceil(wait / 1000)}s para enviar outra sugestão.` };

  const channel = await client.channels.fetch(settings.channelId).catch(() => null);
  if (!channel?.isTextBased()) return { error: true, message: 'O canal de sugestões não existe mais. Avise a equipe.' };

  const guildData = data(guild.id);
  guildData.suggestionSeq += 1;
  const record = {
    id: guildData.suggestionSeq,
    userId: user.id,
    userTag: user.tag,
    text: clean,
    channelId: channel.id,
    messageId: '',
    status: 'pending',
    up: [],
    down: [],
    reviewedBy: null,
    note: '',
    createdAt: Date.now(),
    reviewedAt: null,
  };

  try {
    const message = await channel.send({ embeds: [embedFor(record)], components: [rowFor(record)] });
    record.messageId = message.id;
  } catch (err) {
    guildData.suggestionSeq -= 1;
    return { error: true, message: `Não consegui publicar no canal de sugestões: ${errorMessage(err)}` };
  }

  guildData.suggestionList.push(record);
  if (guildData.suggestionList.length > MAX_RECORDS) guildData.suggestionList.splice(0, guildData.suggestionList.length - MAX_RECORDS);
  lastSuggestion.set(key, Date.now());
  if (lastSuggestion.size > 2000) lastSuggestion.clear();
  store.addLog(guild.id, 'Sugestão', `#${record.id} enviada por ${user.tag}.`);
  return { error: false, message: `Sugestão #${record.id} enviada em ${channel}. Obrigado!`, record };
}

async function vote(interaction) {
  const up = interaction.customId.startsWith(UP);
  const id = interaction.customId.slice((up ? UP : DOWN).length);
  const record = find(interaction.guild.id, id);

  if (!record) return interaction.reply(ephemeral('Essa sugestão não existe mais.'));
  if (record.status !== 'pending') return interaction.reply(ephemeral('A votação dessa sugestão já foi encerrada.'));

  const mine = interaction.user.id;
  const same = up ? record.up : record.down;
  const other = up ? record.down : record.up;

  const otherIndex = other.indexOf(mine);
  if (otherIndex >= 0) other.splice(otherIndex, 1);
  const sameIndex = same.indexOf(mine);
  if (sameIndex >= 0) same.splice(sameIndex, 1); // clicar de novo tira o voto
  else same.push(mine);
  store.save();

  return interaction.update({ embeds: [embedFor(record)], components: [rowFor(record)] });
}

/** Aprova ou nega (equipe, pelo Discord ou pelo painel). */
async function review(client, guildId, id, status, note, reviewer) {
  if (!['approved', 'denied'].includes(status)) return { error: true, message: 'Situação inválida.' };
  const record = find(guildId, id);
  if (!record) return { error: true, message: 'Sugestão não encontrada.' };

  record.status = status;
  record.note = String(note || '').trim().slice(0, 1000);
  record.reviewedBy = reviewer;
  record.reviewedAt = Date.now();
  store.save();

  const channel = await client.channels.fetch(record.channelId).catch(() => null);
  const message = await channel?.messages?.fetch(record.messageId).catch(() => null);
  await message?.edit({ embeds: [embedFor(record)], components: [rowFor(record, true)] }).catch((err) =>
    log.warn('Não consegui atualizar a mensagem da sugestão:', errorMessage(err)),
  );

  if (data(guildId).suggestions.dmAuthor) {
    const user = await client.users.fetch(record.userId).catch(() => null);
    await user
      ?.send(`Sua sugestão #${record.id} foi **${status === 'approved' ? 'aprovada ✅' : 'negada ❌'}**.${record.note ? `\n> ${record.note}` : ''}`)
      .catch(() => {});
  }

  store.addLog(guildId, 'Sugestão', `#${record.id} ${status === 'approved' ? 'aprovada' : 'negada'} por ${reviewer}.`);
  return { error: false, message: `Sugestão #${record.id} ${status === 'approved' ? 'aprovada' : 'negada'}.` };
}

function list(guildId, status = 'all') {
  return data(guildId)
    .suggestionList.filter((s) => status === 'all' || s.status === status)
    .slice()
    .reverse()
    .slice(0, 150)
    .map((s) => ({
      id: s.id,
      userId: s.userId,
      userTag: s.userTag,
      text: s.text,
      status: s.status,
      up: s.up.length,
      down: s.down.length,
      note: s.note,
      reviewedBy: s.reviewedBy,
      createdAt: s.createdAt,
    }));
}

function handleButton(interaction) {
  return vote(interaction);
}

module.exports = { create, review, list, handleButton, UP, DOWN };
