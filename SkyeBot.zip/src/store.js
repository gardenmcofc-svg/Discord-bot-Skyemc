'use strict';

const fs = require('fs');
const path = require('path');
const config = require('./config');
const { log } = require('./util');

const DATA_DIR = config.dataDir;
const DB_FILE = path.join(DATA_DIR, 'database.json');
const DB_COPY = `${DB_FILE}.bak`;
const BACKUP_DIR = path.join(DATA_DIR, 'backups');
const LEGACY_FILE = path.join(config.rootDir, 'database.json');

const SCHEMA_VERSION = 2;
const MAX_LOGS = 300;
const DAY = 86400000;

/** Configuração padrão de um servidor. Toda leitura passa por aqui, então
 *  campos novos aparecem automaticamente em bancos antigos. */
function defaultGuild() {
  return {
    name: '',
    prefix: '!',
    automod: {
      enabled: true,
      antiInvite: true,
      antiLink: false,
      allowedDomains: [],
      antiSpam: true,
      spamMessages: 5,
      spamSeconds: 5,
      maxMentions: 5,
      capsPercent: 0,
      badWords: [],
      ignoredRoleIds: [],
      ignoredChannelIds: [],
      logChannelId: '',
      punishment: 'delete',
      timeoutMinutes: 10,
    },
    welcome: {
      enabled: false,
      channelId: '',
      message: 'Bem-vindo(a) {user} ao **{server.name}**! Você é o membro nº {member_count}.',
      useEmbed: true,
      embedColor: '#57C785',
      autoRoleId: '',
      dmEnabled: false,
      dmMessage: 'Olá {user.name}, bem-vindo(a) ao {server.name}! Leia as regras e aproveite.',
      leaveEnabled: false,
      leaveChannelId: '',
      leaveMessage: '{user.tag} saiu do servidor. Agora somos {member_count}.',
    },
    tickets: {
      enabled: true,
      channelId: '',
      categoryId: '',
      supportRoleId: '',
      logChannelId: '',
      embedTitle: '🎫 Central de suporte',
      embedDesc: 'Clique no botão abaixo para falar com a equipe em um canal privado.',
      buttonText: '📩 Abrir ticket',
      ticketWelcomeMsg: 'Olá {user}! Descreva seu problema com detalhes que a equipe já vem te atender.',
      embedColor: '#57C785',
      transcripts: true,
      maxPerUser: 1,
      categories: [], // [{ id, label, emoji, description }] — com categorias o painel vira um menu de seleção
      ratings: true, // pede uma nota de 1 a 5 no privado ao fechar
      autoCloseHours: 0, // 0 = nunca fecha por inatividade
    },
    suggestions: {
      enabled: false,
      channelId: '',
      dmAuthor: true,
    },
    serverStatus: {
      enabled: true,
      name: 'SkyeMC Network',
      host: 'play.skyemc.com',
      port: 25565,
      counterChannelId: '',
      counterTemplate: '🟢 {online}/{max} jogando',
      lastPing: null,
    },
    levels: {
      enabled: true,
      xpMin: 5,
      xpMax: 12,
      cooldownSeconds: 60,
      announce: true,
      announceChannelId: '',
      announceMessage: '🌱 {user} subiu para o **nível {level}**!',
      noXpChannelIds: [],
      rewards: [],
      users: {},
    },
    economy: {
      enabled: true,
      currency: 'Folhas',
      currencyEmoji: '🍃',
      dailyAmount: 250,
      workMin: 40,
      workMax: 160,
      workCooldownMinutes: 60,
      users: {},
    },
    antinuke: {
      enabled: false,
      maxChannelDelete: 3,
      maxRoleDelete: 3,
      maxBans: 3,
      maxKicks: 5,
      windowSeconds: 60,
      punishment: 'removeRoles',
      whitelistIds: [],
      alertChannelId: '',
    },
    customCommands: [],
    giveaways: [],
    ticketSeq: 0,
    ticketList: [],
    suggestionSeq: 0,
    suggestionList: [],
    pollSeq: 0,
    polls: [],
    reminderSeq: 0,
    reminders: [],
    warns: {},
    stats: { messages: 0, commands: 0, ticketsOpened: 0 },
  };
}

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

/** Mescla em profundidade sem deixar chaves perigosas passarem. */
function deepMerge(base, patch) {
  if (!isPlainObject(patch)) return base;
  const out = Array.isArray(base) ? [...base] : { ...base };
  for (const [key, value] of Object.entries(patch)) {
    if (key === '__proto__' || key === 'constructor' || key === 'prototype') continue;
    if (isPlainObject(value) && isPlainObject(out[key])) {
      out[key] = deepMerge(out[key], value);
    } else {
      out[key] = value;
    }
  }
  return out;
}

class Store {
  constructor() {
    this.data = { version: SCHEMA_VERSION, guilds: {}, logs: [], createdAt: Date.now() };
    this.saveTimer = null;
    this.saveDeadline = 0;
    this.dirty = false;
    this.normalized = new Set();
    this.lastCopyAt = 0;
    this.backupTimer = null;
  }

  load() {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.mkdirSync(BACKUP_DIR, { recursive: true });

    let raw = null;
    if (fs.existsSync(DB_FILE)) {
      raw = this.#readJson(DB_FILE);
      if (!raw) {
        // Arquivo corrompido: guarda o original e tenta a última cópia boa.
        const broken = path.join(BACKUP_DIR, `corrompido-${Date.now()}.json`);
        try {
          fs.copyFileSync(DB_FILE, broken);
          log.warn(`database.json estava corrompido. O original foi guardado em ${path.basename(broken)}.`);
        } catch { /* nada a fazer */ }
        raw = fs.existsSync(DB_COPY) ? this.#readJson(DB_COPY) : null;
        if (raw) log.ok('Recuperei os dados a partir da última cópia automática (database.json.bak).');
        else log.warn('Não havia cópia utilizável. Um banco novo foi criado.');
      }
    } else if (fs.existsSync(LEGACY_FILE)) {
      raw = this.#readJson(LEGACY_FILE);
      if (raw) log.info('Banco antigo encontrado na raiz do projeto. Convertendo para o formato novo.');
    }

    if (raw) {
      this.data = raw.version === SCHEMA_VERSION ? raw : this.#migrate(raw);
    }

    this.data.guilds ||= {};
    this.data.logs ||= [];
    this.normalized.clear();
    this.data.version = SCHEMA_VERSION;
    this.saveNow();
    return this;
  }

  #readJson(file) {
    try {
      const text = fs.readFileSync(file, 'utf8');
      const parsed = JSON.parse(text);
      return isPlainObject(parsed) ? parsed : null;
    } catch (err) {
      log.error(`Não foi possível ler ${path.basename(file)}:`, err.message);
      return null;
    }
  }

  /** v1 guardava tudo de forma global. Isso vira um "servidor pendente" que
   *  é adotado pelo primeiro servidor em que o bot entrar. */
  #migrate(old) {
    const guild = defaultGuild();
    guild.automod = deepMerge(guild.automod, {
      enabled: old.automod?.enabled ?? true,
      antiInvite: old.automod?.antiInvite ?? true,
      badWords: typeof old.automod?.badWords === 'string'
        ? old.automod.badWords.split(',').map((w) => w.trim()).filter(Boolean)
        : [],
    });
    guild.welcome = deepMerge(guild.welcome, old.welcome || {});
    guild.tickets = deepMerge(guild.tickets, old.tickets || {});
    guild.serverStatus = deepMerge(guild.serverStatus, {
      name: old.serverStatus?.name,
      host: old.serverStatus?.serverIp,
      port: Number(old.serverStatus?.port) || 25565,
    });
    guild.customCommands = Array.isArray(old.customCommands) ? old.customCommands : [];

    for (const [userId, balance] of Object.entries(old.economy || {})) {
      guild.economy.users[userId] = { balance: Number(balance) || 0, bank: 0, lastDaily: 0, lastWork: 0 };
    }
    for (const [userId, info] of Object.entries(old.levels || {})) {
      guild.levels.users[userId] = {
        xp: Number(info?.xp) || 0,
        level: Number(info?.level) || 1,
        lastMessage: 0,
        messages: 0,
      };
    }

    return {
      version: SCHEMA_VERSION,
      guilds: {},
      pendingImport: guild,
      logs: Array.isArray(old.logs) ? old.logs.slice(0, MAX_LOGS) : [],
      createdAt: Date.now(),
      migratedFrom: 1,
    };
  }

  /**
   * Dados de um servidor, criando-os na primeira vez.
   * A normalização (preencher campos que versões novas trouxeram) roda uma
   * única vez por servidor — refazê-la a cada mensagem clonaria os mapas de
   * usuários inteiros e derrubaria o desempenho.
   */
  guild(guildId) {
    if (!guildId) return defaultGuild();

    if (!this.data.guilds[guildId]) {
      if (this.data.pendingImport) {
        this.data.guilds[guildId] = this.data.pendingImport;
        delete this.data.pendingImport;
        log.ok(`Configurações antigas importadas para o servidor ${guildId}.`);
      } else {
        this.data.guilds[guildId] = defaultGuild();
      }
      this.save();
    }

    if (!this.normalized.has(guildId)) {
      this.data.guilds[guildId] = deepMerge(defaultGuild(), this.data.guilds[guildId]);
      this.normalized.add(guildId);
    }
    return this.data.guilds[guildId];
  }

  updateGuild(guildId, section, patch) {
    const guild = this.guild(guildId);
    guild[section] = deepMerge(guild[section], patch);
    this.save();
    return guild[section];
  }

  addLog(guildId, action, details) {
    this.data.logs.unshift({
      at: Date.now(),
      guildId: guildId || null,
      action: String(action).slice(0, 60),
      details: String(details).slice(0, 400),
    });
    if (this.data.logs.length > MAX_LOGS) this.data.logs.length = MAX_LOGS;
    this.save();
  }

  logsFor(guildId, limit = 100) {
    return this.data.logs.filter((entry) => !guildId || entry.guildId === guildId).slice(0, limit);
  }

  /**
   * Salvamento adiado: mensagens de chat alteram XP a todo instante e gravar o
   * arquivo a cada mensagem travava o bot. Se já existe uma gravação marcada
   * para mais tarde e chega um pedido mais urgente, o prazo é encurtado.
   */
  save(delay = 1500) {
    this.dirty = true;
    const deadline = Date.now() + delay;

    if (this.saveTimer) {
      if (deadline >= this.saveDeadline) return;
      clearTimeout(this.saveTimer);
    }

    this.saveDeadline = deadline;
    this.saveTimer = setTimeout(() => {
      this.saveTimer = null;
      this.saveNow();
    }, delay);
    if (typeof this.saveTimer.unref === 'function') this.saveTimer.unref();
  }

  /** Grava em arquivo temporário e renomeia: nunca deixa um JSON pela metade. */
  saveNow() {
    if (this.saveTimer) {
      clearTimeout(this.saveTimer);
      this.saveTimer = null;
    }
    try {
      fs.mkdirSync(DATA_DIR, { recursive: true });

      // Cópia rápida da versão anterior (no máximo a cada 10 min) para recuperação.
      if (fs.existsSync(DB_FILE) && Date.now() - this.lastCopyAt > 600000) {
        fs.copyFileSync(DB_FILE, DB_COPY);
        this.lastCopyAt = Date.now();
      }

      const tmp = `${DB_FILE}.${process.pid}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify(this.data));
      fs.renameSync(tmp, DB_FILE);
      this.dirty = false;
      return true;
    } catch (err) {
      log.error('Falha ao salvar o banco de dados:', err.message);
      return false;
    }
  }

  backup() {
    this.saveNow();
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
    const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
    const file = path.join(BACKUP_DIR, `backup-${stamp}.json`);
    fs.copyFileSync(DB_FILE, file);
    this.#trimBackups();
    return file;
  }

  listBackups() {
    try {
      return fs
        .readdirSync(BACKUP_DIR)
        .filter((name) => name.startsWith('backup-'))
        .sort()
        .reverse()
        .map((name) => {
          const stat = fs.statSync(path.join(BACKUP_DIR, name));
          return { name, size: stat.size, at: stat.mtimeMs };
        });
    } catch {
      return [];
    }
  }

  /** Um backup automático por dia enquanto o bot estiver ligado. */
  startAutoBackup() {
    const run = () => {
      try {
        const newest = this.listBackups()[0];
        if (!newest || Date.now() - newest.at > DAY) {
          this.backup();
          log.info('Backup automático diário criado.');
        }
      } catch (err) {
        log.warn('Backup automático falhou:', err.message);
      }
    };
    run();
    this.backupTimer = setInterval(run, 3600000);
    if (typeof this.backupTimer.unref === 'function') this.backupTimer.unref();
  }

  #trimBackups(keep = 15) {
    const files = fs
      .readdirSync(BACKUP_DIR)
      .filter((f) => f.startsWith('backup-'))
      .sort()
      .reverse();
    for (const old of files.slice(keep)) {
      fs.unlinkSync(path.join(BACKUP_DIR, old));
    }
  }
}

const store = new Store();

module.exports = { store, defaultGuild, deepMerge, DB_FILE, BACKUP_DIR };
