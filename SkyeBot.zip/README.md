# SkyeBot 2.1

Bot de Discord + painel web para a rede SkyeMC: boas-vindas, tickets, níveis, economia,
sorteios, música, auto-moderação, anti-nuke, status do servidor de Minecraft e comandos personalizados.

## Como colocar para rodar (bot-hosting)

1. Envie o arquivo `.tar.gz` para a pasta do seu servidor, clique nele e escolha **Unarchive**.
   Os arquivos ficam direto na raiz (`index.js`, `package.json`, `src/`…).
2. Abra o arquivo **`.env`** e preencha só estas duas linhas:
   - `DISCORD_TOKEN` → Developer Portal → **Bot** → *Reset Token*
   - `CLIENT_ID` → Developer Portal → **General Information** → *Application ID*
3. Aperte **Iniciar**. Na primeira vez o bot instala as dependências sozinho (1 a 3 minutos).
   Não precisa rodar `npm` nem nenhum comando.
4. O console mostra o endereço do painel, o usuário e a senha (a senha está no `.env`, em `PANEL_PASSWORD`).

O arquivo principal da host precisa ser `index.js` (é o padrão).

### No Discord Developer Portal (aba Bot)
Ligue **Server Members Intent** e **Message Content Intent**. Sem elas o bot ainda entra,
mas boas-vindas, XP, auto-moderação e comandos com prefixo ficam desativados (o painel avisa).

Para convidar o bot, abra o painel: quando ele ainda não está em nenhum servidor aparece o botão **Convidar o bot**.

### Abrir o painel (host sem localhost)
Numa host o painel não abre em `localhost`. Você tem três caminhos, e o bot tenta sozinho:
1. **ngrok** — preencha `NGROK_AUTHTOKEN` no `.env` (o "Your Authtoken" do painel do ngrok, não a "API key").
   Pode colar até o comando inteiro que o ngrok mostra; aspas e espaços são removidos.
2. **Plano B automático (Cloudflare)** — se o ngrok recusar o token ou não conectar, o bot sobe um túnel
   do Cloudflare que não precisa de conta. O link (`https://…trycloudflare.com`) aparece no console e no topo do painel.
   Ele muda a cada reinício. Para usar só ele, ponha `TUNNEL=cloudflare` no `.env`.
3. **Endereço direto** — o console também mostra `http://IP:PORTA`. Só abre se a host liberou essa porta para você.

Um vigia confere a cada minuto se o link responde e reinicia o túnel se ele cair. `TUNNEL=off` desliga tudo isso.

## Música
O bot baixa o **yt-dlp** sozinho na primeira vez e o atualiza a cada poucos dias.
Se o YouTube bloquear o IP da host ("confirme que você não é um robô"), exporte os cookies do navegador
para um arquivo **`cookies.txt`** e coloque na mesma pasta do `index.js`. Só isso.

## Arquivos que importam
| Arquivo | Para quê |
|---|---|
| `.env` | token, senha do painel, ngrok |
| `data/database.json` | todos os dados (faça backup pelo painel → Sistema) |
| `data/backups/` | backups automáticos (1 por dia, guarda 15) |
| `cookies.txt` | opcional, só para música |

## O bot não entra na call de música
Se aparecer "tenho tudo liberado mas o bot diz que falta permissão": o aviso agora conta exatamente onde
está o bloqueio. Duas causas comuns:
- **Falta no cargo do bot**: Configurações do servidor → Cargos → cargo do bot → libere Conectar e Falar.
- **O canal de voz (ou a categoria dele) bloqueia por conta própria**, mesmo com o cargo liberado no servidor
  inteiro — é a causa mais comum. Clique no canal → ⚙️ Editar canal → Permissões, e libere Conectar e Falar
  para o cargo do bot ali dentro.

## Problemas comuns
- **"Token inválido"**: gere um token novo no Developer Portal e cole no `.env` sem aspas.
- **Comandos `/` não aparecem**: confira o `CLIENT_ID`. Com `DEV_GUILD_ID` preenchido eles aparecem na hora; sem ele, podem levar até 1 hora.
- **Painel não abre**: procure no console a linha "Painel público" (link do túnel). Se ela não aparecer, veja a mensagem do ngrok logo acima dela.
- **"O NGROK_AUTHTOKEN está errado"**: pegue o token em dashboard.ngrok.com/get-started/your-authtoken. Enquanto isso o plano B do Cloudflare já te dá acesso.
- **Esqueci a senha do painel**: troque `PANEL_PASSWORD` no `.env` e reinicie.
- **Não dá para instalar os pacotes**: a host precisa de internet e espaço em disco livre.

## Novidades da 2.1
Painel novo (busca de membros por nome, prévias ao vivo, checklist de configuração, avisos claros),
`index.js` que se instala sozinho, motor de música com yt-dlp, filtro de palavras sem falsos positivos,
proteção de hierarquia nos comandos de punição, sessões e ngrok que sobrevivem a reinícios,
backups diários, e correções de bugs (música pulando duas faixas, tickets após assumir, sorteios duplicados,
painel quebrando em conexão http, entre outros).
