'use strict';

/**
 * SkyeBot — arquivo de entrada.
 *
 * Na host (bot-hosting e similares) basta descompactar o projeto e apertar
 * "Iniciar". Este arquivo cuida do resto:
 *   1. confere a versão do Node;
 *   2. cria o .env se ele não existir;
 *   3. instala as dependências sozinho quando a pasta node_modules não existe;
 *   4. entrega o controle para o bot de verdade (src/index.js).
 */

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const ROOT = __dirname;
const paint = (code, text) => `\x1b[${code}m${text}\x1b[0m`;
const say = (text) => console.log(`${paint(90, new Date().toLocaleTimeString('pt-BR', { hour12: false }))} ${text}`);

function die(message, hint) {
  console.error('');
  console.error(paint(31, `✖ ${message}`));
  if (hint) console.error(hint);
  console.error('');
  process.exit(1);
}

// 1. Versão do Node -----------------------------------------------------------
const [major, minor] = process.versions.node.split('.').map(Number);
if (major < 18 || (major === 18 && minor < 17)) {
  die(
    `Este bot precisa do Node.js 18.17 ou mais novo (a host está com ${process.versions.node}).`,
    'Na host, procure a opção de versão do Node (Startup / Node version) e escolha 20 ou 22.',
  );
}

// 2. Arquivo .env --------------------------------------------------------------
const envFile = path.join(ROOT, '.env');
const envExample = path.join(ROOT, '.env.example');
if (!fs.existsSync(envFile) && fs.existsSync(envExample)) {
  fs.copyFileSync(envExample, envFile);
  say(paint(33, 'Criei o arquivo .env a partir do .env.example. Preencha DISCORD_TOKEN e CLIENT_ID nele.'));
}

// 3. Dependências --------------------------------------------------------------
function missingDependencies() {
  const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  return Object.keys(pkg.dependencies || {}).filter(
    (name) => !fs.existsSync(path.join(ROOT, 'node_modules', name, 'package.json')),
  );
}

const missing = missingDependencies();
if (missing.length) {
  say(paint(36, `Primeira execução: instalando ${missing.length} pacote(s). Isso leva de 1 a 3 minutos, só desta vez…`));
  const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
  const result = spawnSync(npm, ['install', '--omit=dev', '--no-audit', '--no-fund', '--loglevel=error'], {
    cwd: ROOT,
    stdio: 'inherit',
    env: { ...process.env, npm_config_update_notifier: 'false' },
  });

  if (result.error || result.status !== 0 || missingDependencies().length) {
    die(
      'Não consegui instalar as dependências automaticamente.',
      [
        'O que fazer:',
        '  • Confira se a host tem espaço livre em disco e acesso à internet.',
        '  • Se a host tiver um botão/console de comandos, rode:  npm install',
        result.error ? `  • Detalhe técnico: ${result.error.message}` : '',
      ]
        .filter(Boolean)
        .join('\n'),
    );
  }
  say(paint(32, 'Dependências instaladas.'));
}

// 4. Bot -----------------------------------------------------------------------
require('./src/index.js');
