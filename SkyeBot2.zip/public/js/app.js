'use strict';

/* ==========================================================================
   Painel do SkyeBot — interface
   ========================================================================== */

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const state = {
  guildId: null,
  resources: null,
  config: null,
  status: null,
  view: 'overview',
  viewTimer: null,
  bannerKey: '',
  commandBeingEdited: null,
};

const VIEWS = ['overview', 'minecraft', 'music', 'welcome', 'levels', 'economy', 'giveaways', 'suggestions', 'tickets', 'messages', 'commands', 'automod', 'antinuke', 'logs', 'system'];

/* ------------------------------------------------------------------ helpers */

const esc = (value) =>
  String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const fmtNum = (n) => Number(n || 0).toLocaleString('pt-BR');

function fmtDuration(ms) {
  const total = Math.floor((ms || 0) / 1000);
  const d = Math.floor(total / 86400);
  const h = Math.floor((total % 86400) / 3600);
  const m = Math.floor((total % 3600) / 60);
  if (d) return `${d}d ${h}h`;
  if (h) return `${h}h ${m}min`;
  if (m) return `${m}min`;
  return `${total}s`;
}

function fmtClock(ms) {
  const total = Math.max(0, Math.round((ms || 0) / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = String(total % 60).padStart(2, '0');
  return h ? `${h}:${String(m).padStart(2, '0')}:${s}` : `${m}:${s}`;
}

function fmtTime(ts) {
  const date = new Date(ts);
  const time = date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  const day = date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
  return `${day} ${time}`;
}

function fmtBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1048576).toFixed(1)} MB`;
}

function timeUntil(ts) {
  const diff = ts - Date.now();
  if (diff <= 0) return 'terminando…';
  return `em ${fmtDuration(diff)}`;
}

const icon = (name) => `<svg class="ic"><use href="#i-${name}"/></svg>`;
const debounce = (fn, wait) => {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), wait);
  };
};

/* Markdown básico só para as pré-visualizações */
function mdLite(text) {
  return esc(text)
    .replace(/`([^`\n]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*\n]+)\*\*/g, '<b>$1</b>')
    .replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g, '$1<i>$2</i>');
}

function toast(message, type = 'ok') {
  const box = $('#toasts');
  const node = document.createElement('div');
  node.className = `toast ${type === 'ok' ? '' : 'bad'}`;
  node.innerHTML = `${icon(type === 'ok' ? 'check' : 'alert')}<span>${esc(message)}</span>`;
  box.appendChild(node);
  const remove = () => {
    node.classList.add('out');
    setTimeout(() => node.remove(), 250);
  };
  setTimeout(remove, type === 'ok' ? 3800 : 6500);
  node.addEventListener('click', remove);
}

function confirmBox({ title, text, confirmText = 'Confirmar', danger = false }) {
  return new Promise((resolve) => {
    const back = document.createElement('div');
    back.className = 'modal-back';
    back.innerHTML = `
      <div class="modal" role="dialog" aria-modal="true">
        <h3>${esc(title)}</h3>
        <p>${esc(text)}</p>
        <div class="btn-row">
          <button class="btn ghost" data-answer="no">Cancelar</button>
          <button class="btn ${danger ? 'danger' : ''}" data-answer="yes">${esc(confirmText)}</button>
        </div>
      </div>`;
    const finish = (answer) => {
      document.removeEventListener('keydown', onKey);
      back.remove();
      resolve(answer);
    };
    const onKey = (event) => { if (event.key === 'Escape') finish(false); };
    back.addEventListener('click', (event) => {
      if (event.target === back) finish(false);
      const answer = event.target.closest('[data-answer]')?.dataset.answer;
      if (answer) finish(answer === 'yes');
    });
    document.addEventListener('keydown', onKey);
    document.body.appendChild(back);
    $('[data-answer="yes"]', back).focus();
  });
}

function promptBox({ title, text, placeholder = '', confirmText = 'Confirmar', danger = false }) {
  return new Promise((resolve) => {
    const back = document.createElement('div');
    back.className = 'modal-back';
    back.innerHTML = `
      <div class="modal" role="dialog" aria-modal="true">
        <h3>${esc(title)}</h3>
        <p>${esc(text)}</p>
        <textarea rows="3" maxlength="300" placeholder="${esc(placeholder)}" style="margin-bottom:18px"></textarea>
        <div class="btn-row">
          <button class="btn ghost" data-answer="no">Cancelar</button>
          <button class="btn ${danger ? 'danger' : ''}" data-answer="yes">${esc(confirmText)}</button>
        </div>
      </div>`;
    const field = $('textarea', back);
    const finish = (value) => {
      document.removeEventListener('keydown', onKey);
      back.remove();
      resolve(value);
    };
    const onKey = (event) => { if (event.key === 'Escape') finish(null); };
    back.addEventListener('click', (event) => {
      if (event.target === back) finish(null);
      const answer = event.target.closest('[data-answer]')?.dataset.answer;
      if (answer) finish(answer === 'yes' ? field.value.trim() : null);
    });
    document.addEventListener('keydown', onKey);
    document.body.appendChild(back);
    field.focus();
  });
}

async function api(path, options = {}) {
  const init = {
    method: options.method || 'GET',
    headers: { 'ngrok-skip-browser-warning': '1' },
  };
  if (options.body !== undefined) {
    init.headers['Content-Type'] = 'application/json';
    init.body = JSON.stringify(options.body);
  }

  let response;
  try {
    response = await fetch(`/api${path}`, init);
  } catch {
    throw new Error('Sem conexão com o painel. O bot ainda está rodando?');
  }

  if (response.status === 401) {
    window.location.href = '/login';
    throw new Error('Sessão expirada.');
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok || data.error) throw new Error(data.message || `Erro ${response.status}`);
  return data;
}

function guildPath(suffix) {
  if (!state.guildId) throw new Error('Nenhum servidor selecionado. Convide o bot para um servidor primeiro.');
  return `/guilds/${state.guildId}${suffix}`;
}
const guildApi = (suffix, options) => api(guildPath(suffix), options);

/** Desativa o botão, mostra um indicador e converte erros em avisos. */
async function action(button, task) {
  const original = button?.innerHTML;
  if (button) {
    button.disabled = true;
    button.innerHTML = `<span class="spin"></span>`;
  }
  try {
    return await task();
  } catch (err) {
    toast(err.message, 'bad');
    return undefined;
  } finally {
    if (button) {
      button.disabled = false;
      button.innerHTML = original;
    }
  }
}

function avatarHtml(url) {
  return url ? `<img class="avatar" src="${esc(url)}" alt="" loading="lazy" />` : '<span class="avatar"></span>';
}

/* ------------------------------------------------------------------ navegação */

function openView(name, { updateHash = true } = {}) {
  if (!VIEWS.includes(name)) name = 'overview';
  state.view = name;

  $$('.view').forEach((el) => el.classList.toggle('active', el.id === `view-${name}`));
  $$('.nav-item').forEach((el) => el.classList.toggle('active', el.dataset.view === name));
  document.body.classList.remove('nav-open');
  if (updateHash && location.hash !== `#${name}`) history.replaceState(null, '', `#${name}`);

  clearInterval(state.viewTimer);
  state.viewTimer = null;
  window.scrollTo({ top: 0 });
  refreshView();
}

const timers = { overview: 15000, music: 4000, logs: 5000, system: 10000, tickets: 8000, suggestions: 15000 };

function refreshView() {
  clearInterval(state.viewTimer);
  const loader = loaders[state.view];
  if (loader && state.guildId !== undefined) loader().catch((err) => toast(err.message, 'bad'));

  const every = timers[state.view];
  if (every) {
    state.viewTimer = setInterval(() => {
      if (document.hidden) return;
      if (state.view === 'logs' && !$('#logs-live').checked) return;
      loaders[state.view]?.().catch(() => {});
    }, every);
  }
}

$$('.nav-item').forEach((item) => item.addEventListener('click', () => openView(item.dataset.view)));
window.addEventListener('hashchange', () => openView(location.hash.slice(1), { updateHash: false }));
$('#menu-btn').addEventListener('click', () => document.body.classList.toggle('nav-open'));
$('#scrim').addEventListener('click', () => document.body.classList.remove('nav-open'));

$('#logout').addEventListener('click', async () => {
  await fetch('/api/logout', { method: 'POST', headers: { 'ngrok-skip-browser-warning': '1' } }).catch(() => {});
  window.location.href = '/login';
});

$('#url-chip').addEventListener('click', async () => {
  const url = state.status?.panel?.publicUrl;
  if (!url) return;
  try {
    await navigator.clipboard.writeText(url);
    toast('Link copiado.');
  } catch {
    toast(url);
  }
});

/* ------------------------------------------------------------------ status geral */

async function loadStatus() {
  let status;
  try {
    status = await api('/status');
  } catch (err) {
    $('#bot-dot').className = 'dot';
    $('#bot-state').textContent = 'painel sem resposta';
    return;
  }
  state.status = status;

  $('#bot-dot').className = `dot ${status.botOnline ? 'on' : ''}`;
  $('#bot-state').textContent = status.botOnline
    ? `${status.botTag}${status.ping != null ? ` · ${status.ping}ms` : ''}`
    : 'bot offline';
  $('#rail-foot').textContent = `SkyeBot v${status.version}`;

  const chip = $('#url-chip');
  if (status.panel.publicUrl) {
    chip.hidden = false;
    $('#url-text').textContent = status.panel.publicUrl.replace(/^https?:\/\//, '');
  } else {
    chip.hidden = true;
  }

  renderBanners(status);
  syncGuildSelect(status.guilds);

  if (state.view === 'system') renderSystem();
}

function renderBanners(status) {
  const banners = [];

  if (!status.botOnline) {
    banners.push({
      kind: status.botError ? 'bad' : 'info',
      icon: status.botError ? 'alert' : 'info',
      html: status.botError
        ? `<div><b>O bot está offline.</b> ${esc(status.botError)}</div>`
        : '<div><b>Conectando ao Discord…</b> Isso leva alguns segundos.</div>',
    });
  }
  if (status.limitedIntents?.length) {
    banners.push({
      kind: 'warn',
      icon: 'alert',
      html: `<div><b>Faltam permissões no Discord Developer Portal.</b> Ligue <b>Server Members Intent</b> e <b>Message Content Intent</b> (aba Bot) e reinicie o bot. Sem elas, boas-vindas, XP, auto-moderação e comandos com prefixo ficam desativados.</div>`,
      button: { href: 'https://discord.com/developers/applications', text: 'Abrir portal' },
    });
  }
  const tunnel = status.panel.tunnel;
  if (tunnel.state === 'error') {
    banners.push({ kind: 'warn', icon: 'alert', html: `<div><b>Não consegui criar o link público do painel.</b> ${esc(tunnel.error || '')}${status.panel.directUrl ? ' Tente pelo endereço direto: <code>' + esc(status.panel.directUrl) + '</code>' : ''}</div>` });
  } else if (tunnel.state === 'connecting') {
    banners.push({ kind: 'info', icon: 'info', html: `<div><b>Criando o link público…</b> ${esc(tunnel.error || 'Ele aparece aqui em instantes.')}</div>` });
  }
  if (status.botOnline && !status.guilds.length) {
    banners.push({
      kind: 'info',
      icon: 'info',
      html: '<div><b>O bot ainda não está em nenhum servidor.</b> Convide-o e depois recarregue esta página.</div>',
      button: status.inviteUrl ? { href: status.inviteUrl, text: 'Convidar o bot' } : null,
    });
  }

  const key = JSON.stringify(banners);
  if (key === state.bannerKey) return;
  state.bannerKey = key;

  $('#banners').innerHTML = banners
    .map(
      (b) => `<div class="banner ${b.kind}">${icon(b.icon)}${b.html}${
        b.button ? `<a class="btn small ghost" href="${esc(b.button.href)}" target="_blank" rel="noopener">${esc(b.button.text)}</a>` : ''
      }</div>`,
    )
    .join('');
}

function syncGuildSelect(guilds) {
  const select = $('#guild-select');
  const signature = guilds.map((g) => g.id).join(',');
  if (select.dataset.signature !== signature) {
    select.dataset.signature = signature;
    select.innerHTML = guilds.length
      ? guilds.map((g) => `<option value="${g.id}">${esc(g.name)}</option>`).join('')
      : '<option value="">nenhum servidor</option>';
    select.disabled = !guilds.length;
  }

  if (!guilds.length) {
    state.guildId = null;
    return;
  }

  const saved = safeStorage('get', 'skye.guild');
  const wanted = state.guildId && guilds.some((g) => g.id === state.guildId)
    ? state.guildId
    : guilds.some((g) => g.id === saved) ? saved : guilds[0].id;

  if (select.value !== wanted) select.value = wanted;

  const guild = guilds.find((g) => g.id === wanted);
  $('#guild-icon').innerHTML = guild?.icon ? `<img src="${esc(guild.icon)}" alt="" />` : '';

  if (state.guildId !== wanted) switchGuild(wanted);
}

function safeStorage(op, key, value) {
  try {
    if (op === 'get') return localStorage.getItem(key);
    localStorage.setItem(key, value);
  } catch { /* armazenamento indisponível: sem problema */ }
  return null;
}

$('#guild-select').addEventListener('change', (event) => {
  if (event.target.value) {
    safeStorage('set', 'skye.guild', event.target.value);
    switchGuild(event.target.value);
  }
});

async function switchGuild(guildId) {
  state.guildId = guildId;
  state.resources = null;
  state.config = null;
  try {
    const [resources, config] = await Promise.all([guildApi('/resources'), guildApi('/config')]);
    if (state.guildId !== guildId) return; // trocou de servidor no meio do caminho
    state.resources = resources;
    state.config = config;
    $('#guild-icon').innerHTML = resources.icon ? `<img src="${esc(resources.icon)}" alt="" />` : '';
    populateSelects();
    $$('form[data-section]').forEach(fillForm);
    renderRewards();
    updatePreviews();
    renderCategories();
    refreshBadges();
    refreshView();
  } catch (err) {
    toast(err.message, 'bad');
  }
}

/* ------------------------------------------------------------------ seletores e formulários */

function populateSelects() {
  const res = state.resources;
  if (!res) return;

  $$('select[data-options]').forEach((select) => {
    const items = res[select.dataset.options] || [];
    const previous = select.multiple ? [...select.selectedOptions].map((o) => o.value) : select.value;

    let html = '';
    if (!select.multiple) {
      const noneLabel = select.dataset.field || ['gw-role', 'cmd-role'].includes(select.id) ? '— nenhum —' : 'Escolha…';
      html += `<option value="">${noneLabel}</option>`;
    }
    const prefix = select.dataset.options === 'textChannels' ? '#' : select.dataset.options === 'voiceChannels' ? '🔊 ' : '';
    html += items.map((item) => `<option value="${esc(item.id)}">${prefix}${esc(item.name)}</option>`).join('');
    select.innerHTML = html;

    if (select.multiple) $$('option', select).forEach((o) => { o.selected = previous.includes(o.value); });
    else select.value = previous;
  });
}

function sectionSource(form) {
  const section = form.dataset.section;
  return section === 'general' ? state.config : state.config?.[section];
}

function fillForm(form) {
  const source = sectionSource(form);
  if (!source) return;

  $$('[data-field]', form).forEach((el) => {
    const value = source[el.dataset.field];
    if (el.type === 'checkbox') el.checked = Boolean(value);
    else if (el.tagName === 'SELECT' && el.multiple) {
      const chosen = Array.isArray(value) ? value : [];
      $$('option', el).forEach((o) => { o.selected = chosen.includes(o.value); });
    } else if (Array.isArray(value)) el.value = value.join(', ');
    else el.value = value ?? '';
  });
  setDirty(form, false);
}

function collectForm(form) {
  const body = {};
  $$('[data-field]', form).forEach((el) => {
    if (el.type === 'checkbox') body[el.dataset.field] = el.checked;
    else if (el.tagName === 'SELECT' && el.multiple) body[el.dataset.field] = [...el.selectedOptions].map((o) => o.value);
    else body[el.dataset.field] = el.value;
  });
  // As recompensas de nível têm gerenciamento próprio, mas viajam junto na mesma seção.
  if (form.dataset.section === 'levels') body.rewards = state.config?.levels?.rewards || [];
  return body;
}

function setDirty(form, dirty) {
  form.classList.toggle('is-dirty', dirty);
  $('.dirty', form)?.classList.toggle('show', dirty);
}

$$('form[data-section]').forEach((form) => {
  const row = $$('.btn-row', form).pop();
  if (row) row.insertAdjacentHTML('beforeend', `<span class="dirty">${icon('alert')} Alterações não salvas</span>`);

  const mark = () => setDirty(form, true);
  form.addEventListener('input', mark);
  form.addEventListener('change', mark);

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const button = $('button[type="submit"]', form);
    action(button, async () => {
      const result = await guildApi(`/config/${form.dataset.section}`, { method: 'POST', body: collectForm(form) });
      state.config = await guildApi('/config');
      fillForm(form);
      toast(result.message || 'Salvo.');
    });
  });
});

document.addEventListener('keydown', (event) => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') {
    const form = $(`#view-${state.view} form[data-section]`);
    if (form) {
      event.preventDefault();
      form.requestSubmit();
    }
  }
});

/* Botões de variáveis: inserem {user} etc. onde está o cursor */
const VARIABLES = ['{user}', '{user.name}', '{user.tag}', '{server.name}', '{member_count}'];
$$('small.vars').forEach((holder) => {
  const target = holder.closest('label')?.querySelector('textarea, input');
  if (!target) return;
  holder.innerHTML = `<span class="chips"><span class="lbl">Inserir:</span>${VARIABLES.map(
    (v) => `<button type="button" class="chip">${esc(v)}</button>`,
  ).join('')}</span>`;
  holder.addEventListener('click', (event) => {
    const chip = event.target.closest('.chip');
    if (!chip) return;
    const start = target.selectionStart ?? target.value.length;
    const end = target.selectionEnd ?? target.value.length;
    target.setRangeText(chip.textContent, start, end, 'end');
    target.focus();
    target.dispatchEvent(new Event('input', { bubbles: true }));
  });
});

/* ------------------------------------------------------------------ seletor de membros */

function attachMemberPicker(input) {
  const wrap = input.closest('.picker') || input.parentElement;
  const box = document.createElement('div');
  box.className = 'suggest';
  box.hidden = true;
  wrap.appendChild(box);

  const search = debounce(async () => {
    const query = input.value.trim();
    if (query.length < 2 || /^\d{17,20}$/.test(query) || !state.guildId) {
      box.hidden = true;
      return;
    }
    try {
      const { members } = await guildApi(`/members?q=${encodeURIComponent(query)}`);
      box.innerHTML = members.length
        ? members.map((m) => `<button type="button" data-id="${esc(m.id)}" data-tag="${esc(m.tag)}">${avatarHtml(m.avatar)}<span>${esc(m.name)}</span><span class="sub">${esc(m.tag)}</span></button>`).join('')
        : '<div class="none">Ninguém encontrado. Você também pode colar o ID.</div>';
      box.hidden = false;
    } catch {
      box.hidden = true;
    }
  }, 260);

  input.addEventListener('input', () => {
    delete input.dataset.userId;
    search();
  });
  input.addEventListener('blur', () => setTimeout(() => { box.hidden = true; }, 180));
  box.addEventListener('mousedown', (event) => {
    const item = event.target.closest('button[data-id]');
    if (!item) return;
    input.value = item.dataset.tag;
    input.dataset.userId = item.dataset.id;
    input.dataset.label = item.dataset.tag;
    box.hidden = true;
  });
}
$$('[data-member-picker]').forEach(attachMemberPicker);

function pickedUserId(input) {
  if (input.dataset.userId && input.value === input.dataset.label) return input.dataset.userId;
  return input.value.replace(/[<>@!\s]/g, '');
}

function fillPicker(input, id, tag) {
  input.value = tag || id;
  input.dataset.userId = id;
  input.dataset.label = input.value;
  input.scrollIntoView({ behavior: 'smooth', block: 'center' });
  input.focus();
}

/* ------------------------------------------------------------------ pré-visualizações */

function renderPreview(container, { content = '', embed = null }) {
  const body = [];
  const empty = !content.trim() && !(embed && (embed.title || embed.desc));
  if (empty) {
    container.innerHTML = '<div class="msg"><div class="av">S</div><div class="col"><div class="hd"><span class="name">SkyeBot</span><span class="bot">BOT</span></div><span style="color:#80848e">A prévia da mensagem aparece aqui enquanto você escreve…</span></div></div>';
    return;
  }
  body.push(`<div class="text">${content ? mdLite(content).replace(/@Membro/g, '<span class="mention">@Membro</span>') : ''}</div>`);
  if (embed) {
    const thumb = embed.thumb && /^https?:\/\//.test(embed.thumb) ? `<img class="th" src="${esc(embed.thumb)}" alt="" />` : '';
    const image = embed.image && /^https?:\/\//.test(embed.image) ? `<img class="im" src="${esc(embed.image)}" alt="" />` : '';
    body.push(`
      <div class="embed" style="border-left-color:${esc(embed.color || '#57c785')}">
        <div class="in">
          ${embed.title ? `<div class="t">${mdLite(embed.title)}</div>` : ''}
          ${embed.desc ? `<div class="d">${mdLite(embed.desc)}</div>` : ''}
          ${image}
          ${embed.footer ? `<div class="f">${esc(embed.footer)}</div>` : ''}
        </div>
        ${thumb}
      </div>`);
  }
  container.innerHTML = `
    <div class="msg"><div class="av">S</div>
      <div class="col"><div class="hd"><span class="name">SkyeBot</span><span class="bot">BOT</span></div>${body.join('')}</div>
    </div>`;
}

const sampleVars = (text) =>
  String(text || '')
    .replaceAll('{user}', '@Membro')
    .replaceAll('{user.name}', 'Membro')
    .replaceAll('{user.tag}', 'membro')
    .replaceAll('{server.name}', state.resources?.name || 'Seu servidor')
    .replaceAll('{member_count}', fmtNum((state.resources?.memberCount || 100) + 1));

function updatePreviews() {
  const wl = $('#view-welcome form');
  const message = sampleVars($('#wl-message').value);
  const asEmbed = $('[data-field="useEmbed"]', wl).checked;
  renderPreview($('#wl-preview'), asEmbed
    ? { content: '@Membro', embed: { desc: message, color: $('#wl-color').value } }
    : { content: message });

  const embedOn = $('#msg-embed').checked;
  $('#embed-fields').hidden = !embedOn;
  renderPreview($('#msg-preview'), {
    content: $('#msg-content').value,
    embed: embedOn
      ? {
          title: $('#msg-title').value,
          desc: $('#msg-desc').value,
          color: $('#msg-color').value,
          image: $('#msg-image').value,
          thumb: $('#msg-thumb').value,
          footer: $('#msg-footer').value,
        }
      : null,
  });
}
$('#view-welcome form').addEventListener('input', updatePreviews);
$('#view-welcome form').addEventListener('change', updatePreviews);
$('#view-messages').addEventListener('input', updatePreviews);
$('#view-messages').addEventListener('change', updatePreviews);

/* ------------------------------------------------------------------ carregadores de tela */

const loaders = {};

/* ----- visão geral ----- */
loaders.overview = async () => {
  if (!state.guildId) return;
  const data = await guildApi('/overview');
  const mc = data.minecraft;

  const icon$ = $('#mc-icon');
  icon$.innerHTML = data.minecraftIcon ? `<img src="${esc(data.minecraftIcon)}" alt="" style="width:100%;height:100%;border-radius:14px" />` : icon('cube');

  if (mc?.online) {
    $('#mc-players').innerHTML = `${fmtNum(mc.players.online)}<small> / ${fmtNum(mc.players.max)} online</small>`;
    $('#mc-motd').textContent = mc.motd || '';
    $('#mc-meta').innerHTML = [
      mc.version ? `<span class="badge">${esc(mc.version)}</span>` : '',
      `<span class="badge ok">${mc.latency}ms</span>`,
      ...(mc.players.sample || []).slice(0, 6).map((name) => `<span class="badge">${esc(name)}</span>`),
    ].join('');
  } else {
    $('#mc-players').innerHTML = mc ? '<span style="color:var(--clay)">Offline</span>' : '—';
    $('#mc-motd').textContent = mc?.error || 'Ainda não consultei o servidor.';
    $('#mc-meta').innerHTML = '';
  }
  const status = state.config?.serverStatus;
  $('#mc-address').textContent = status?.host ? `${status.host}${status.port && status.port !== 25565 ? `:${status.port}` : ''}` : 'sem endereço configurado';

  $('#stat-members').textContent = fmtNum(data.guild.memberCount);
  $('#stat-economy').textContent = fmtNum(data.stats.economyAccounts);
  $('#stat-ranked').textContent = fmtNum(data.stats.rankedUsers);
  $('#stat-tickets').textContent = fmtNum(data.stats.ticketsOpened);
  $('#stat-commands').textContent = fmtNum(data.stats.commands);
  $('#stat-giveaways').textContent = fmtNum(data.stats.openGiveaways);

  renderChecklist(data);
  $('#overview-logs').innerHTML = renderLogs(data.logs.slice(0, 8));
};

function renderChecklist(data) {
  const c = state.config;
  if (!c) return;
  const items = [
    { done: Boolean(data.minecraft?.online), text: 'Servidor de Minecraft respondendo', go: 'minecraft' },
    { done: c.welcome.enabled && Boolean(c.welcome.channelId), text: 'Boas-vindas ligadas com um canal escolhido', go: 'welcome' },
    { done: Boolean(c.tickets.channelId && c.tickets.supportRoleId), text: 'Tickets com canal e cargo de suporte', go: 'tickets' },
    { done: c.automod.enabled, text: 'Auto-moderação ligada', go: 'automod' },
    { done: Boolean(c.automod.logChannelId), text: 'Canal de registros da moderação definido', go: 'automod' },
    { done: c.antinuke.enabled, text: 'Anti-nuke ligado (recomendado)', go: 'antinuke' },
  ];
  const done = items.filter((i) => i.done).length;
  $('#setup-bar').style.width = `${Math.round((done / items.length) * 100)}%`;
  $('#setup-sub').textContent = done === items.length ? 'Tudo pronto por aqui. 🌱' : `${done} de ${items.length} passos concluídos.`;
  $('#checklist').innerHTML = items
    .map((i) => `<li class="${i.done ? 'done' : ''}"><span class="mark">${icon('check')}</span><span>${esc(i.text)}</span>${i.done ? '' : `<a href="#${i.go}">Configurar</a>`}</li>`)
    .join('');
}

const LOG_TAGS = { 'Anti-nuke': 'bad', Automod: 'warn', Moderação: 'warn' };
function renderLogs(logs) {
  if (!logs.length) return '<p class="empty">Nada por aqui ainda.</p>';
  return logs
    .map((l) => `<div class="logline"><time>${fmtTime(l.at)}</time><span class="tag ${LOG_TAGS[l.action] || ''}">${esc(l.action)}</span><span class="txt">${esc(l.details)}</span></div>`)
    .join('');
}

$('#mc-refresh').addEventListener('click', (event) =>
  action(event.currentTarget, async () => {
    const result = await guildApi('/minecraft/ping', { method: 'POST', body: {} });
    toast(result.message, result.result?.online ? 'ok' : 'bad');
    await loaders.overview();
  }),
);

/* ----- minecraft ----- */
$('#mc-test').addEventListener('click', (event) => {
  const form = $('#view-minecraft form');
  action(event.currentTarget, async () => {
    const result = await guildApi('/minecraft/ping', {
      method: 'POST',
      body: { host: $('[data-field="host"]', form).value, port: $('[data-field="port"]', form).value },
    });
    toast(result.message, result.result?.online ? 'ok' : 'bad');
  });
});

/* ----- música ----- */
let musicLoopBusy = false;

loaders.music = async () => {
  if (!state.guildId) return;
  const { queue, engine } = await guildApi('/music');

  $('#music-engine').innerHTML = [
    engine.ytdlp ? `<span class="badge ok">yt-dlp ${esc(engine.ytdlp)}</span>` : `<span class="badge warn" title="${esc(engine.ytdlpError || '')}">yt-dlp indisponível</span>`,
    engine.ffmpeg ? '<span class="badge ok">ffmpeg</span>' : '<span class="badge bad">ffmpeg ausente</span>',
    engine.cookies ? '<span class="badge ok">cookies.txt</span>' : '',
  ].join('');

  const controls = $('#music-controls');
  const now = $('#music-now');

  if (!queue) {
    now.innerHTML = '<p class="empty">O bot não está em nenhuma call.</p>';
    controls.hidden = true;
    $('#queue-card').hidden = true;
    return;
  }

  const track = queue.current;
  if (track) {
    const pct = track.duration ? Math.min(100, (queue.elapsed / track.duration) * 100) : 0;
    now.innerHTML = `
      <div class="np">
        ${track.thumbnail ? `<img src="${esc(track.thumbnail)}" alt="" />` : `<div class="art">${icon('music')}</div>`}
        <div class="info">
          <div class="title"><a href="${esc(track.url)}" target="_blank" rel="noopener" style="color:inherit;text-decoration:none">${esc(track.title)}</a></div>
          <div class="by">${esc(track.author || '')}${track.requestedBy ? ` · pedido por ${esc(track.requestedBy)}` : ''}</div>
          <div class="engine" style="margin-top:8px">
            <span class="badge">🔊 ${esc(queue.voiceChannelName)}</span>
            ${queue.paused ? '<span class="badge warn">pausada</span>' : ''}
            ${queue.loop !== 'off' ? `<span class="badge">repetição: ${queue.loop === 'song' ? 'faixa' : 'fila'}</span>` : ''}
          </div>
          <div class="bar" style="margin-top:12px"><i style="width:${pct}%"></i></div>
          <div class="time"><span>${fmtClock(queue.elapsed)}</span><span>${esc(track.durationText || '')}</span></div>
        </div>
      </div>`;
  } else {
    now.innerHTML = '<p class="empty">Carregando a próxima faixa…</p>';
  }

  controls.hidden = false;
  $('#btn-pause').hidden = queue.paused;
  $('#btn-resume').hidden = !queue.paused;
  if (document.activeElement !== $('#music-volume') && !musicLoopBusy) {
    $('#music-volume').value = queue.volume;
    $('#music-volume-label').textContent = queue.volume;
  }
  if (document.activeElement !== $('#music-loop')) $('#music-loop').value = queue.loop;

  $('#queue-card').hidden = !queue.upcoming.length;
  $('#queue-body').innerHTML = queue.upcoming
    .map((t, i) => `<tr><td class="mono">${i + 1}</td><td>${esc(t.title)}<span class="sub">${esc(t.author || '')}</span></td><td class="mono">${esc(t.durationText || '')}</td><td class="actions"><button class="btn ghost small" data-remove="${i + 1}">${icon('trash')}</button></td></tr>`)
    .join('') + (queue.total > queue.upcoming.length ? `<tr><td colspan="4" class="empty">…e mais ${queue.total - queue.upcoming.length} na fila.</td></tr>` : '');
};

$('#music-play').addEventListener('click', (event) =>
  action(event.currentTarget, async () => {
    const result = await guildApi('/music/play', {
      method: 'POST',
      body: { channelId: $('#music-channel').value, query: $('#music-query').value },
    });
    $('#music-query').value = '';
    toast(result.message);
    setTimeout(() => loaders.music().catch(() => {}), 1200);
  }),
);
$('#music-query').addEventListener('keydown', (event) => { if (event.key === 'Enter') $('#music-play').click(); });

$('#music-controls').addEventListener('click', (event) => {
  const button = event.target.closest('[data-music]');
  if (!button) return;
  action(button, async () => {
    const result = await guildApi(`/music/${button.dataset.music}`, { method: 'POST', body: {} });
    toast(result.message);
    await loaders.music();
  });
});

$('#queue-body').addEventListener('click', (event) => {
  const button = event.target.closest('[data-remove]');
  if (!button) return;
  action(button, async () => {
    await guildApi('/music/remove', { method: 'POST', body: { index: Number(button.dataset.remove) } });
    await loaders.music();
  });
});

$('#music-volume').addEventListener('input', (event) => { $('#music-volume-label').textContent = event.target.value; });
$('#music-volume').addEventListener('change', (event) => {
  musicLoopBusy = true;
  guildApi('/music/volume', { method: 'POST', body: { volume: Number(event.target.value) } })
    .catch((err) => toast(err.message, 'bad'))
    .finally(() => { musicLoopBusy = false; });
});
$('#music-loop').addEventListener('change', (event) =>
  guildApi('/music/loop', { method: 'POST', body: { mode: event.target.value } }).catch((err) => toast(err.message, 'bad')),
);

/* ----- níveis ----- */
function renderRewards() {
  const list = $('#rewards-list');
  const rewards = state.config?.levels?.rewards || [];
  if (!rewards.length) {
    list.innerHTML = '<p class="empty" style="padding:8px 0">Nenhum cargo por nível ainda.</p>';
    return;
  }
  const roles = new Map((state.resources?.roles || []).map((r) => [r.id, r.name]));
  list.innerHTML = `<div class="table-wrap"><table><tbody>${rewards
    .slice()
    .sort((a, b) => a.level - b.level)
    .map((r) => `<tr><td style="width:110px"><span class="badge ok">Nível ${r.level}</span></td><td>${esc(roles.get(r.roleId) || `cargo apagado (${r.roleId})`)}</td><td class="actions"><button class="btn ghost small" data-reward="${esc(r.roleId)}:${r.level}">${icon('trash')}</button></td></tr>`)
    .join('')}</tbody></table></div>`;
}

async function saveRewards(rewards) {
  const body = { ...state.config.levels, rewards };
  await guildApi('/config/levels', { method: 'POST', body });
  state.config = await guildApi('/config');
  renderRewards();
}

$('#reward-add').addEventListener('click', (event) =>
  action(event.currentTarget, async () => {
    const roleId = $('#reward-role').value;
    const level = Number($('#reward-level').value);
    if (!roleId) throw new Error('Escolha o cargo.');
    if (!(level >= 1)) throw new Error('Informe um nível válido.');
    const rewards = (state.config.levels.rewards || []).filter((r) => !(r.roleId === roleId && r.level === level));
    rewards.push({ level, roleId });
    await saveRewards(rewards);
    toast('Cargo por nível salvo.');
  }),
);
$('#rewards-list').addEventListener('click', (event) => {
  const button = event.target.closest('[data-reward]');
  if (!button) return;
  const [roleId, level] = button.dataset.reward.split(':');
  action(button, async () => {
    await saveRewards(state.config.levels.rewards.filter((r) => !(r.roleId === roleId && String(r.level) === level)));
    toast('Cargo removido.');
  });
});

loaders.levels = async () => {
  if (!state.guildId) return;
  const { entries } = await guildApi('/levels');
  $('#levels-table').innerHTML = entries.length
    ? entries.map((e, i) => {
        const pct = e.needed ? Math.min(100, Math.floor((e.xp / e.needed) * 100)) : 0;
        return `<tr>
          <td><div class="who"><span class="mono" style="color:var(--faint);width:22px">${i + 1}</span>${avatarHtml(e.avatar)}<div>${esc(e.tag)}<span class="sub">${esc(e.userId)}</span></div></div></td>
          <td><span class="badge ok">Nível ${e.level}</span></td>
          <td class="mono">${fmtNum(e.xp)} / ${fmtNum(e.needed)}</td>
          <td><div class="bar"><i style="width:${pct}%"></i></div></td>
          <td class="actions"><button class="btn ghost small" data-pick="${esc(e.userId)}" data-tag="${esc(e.tag)}">Ajustar</button></td>
        </tr>`;
      }).join('')
    : '<tr><td colspan="5" class="empty">Ninguém tem XP ainda. Assim que o pessoal conversar, aparece aqui.</td></tr>';
};

$('#levels-table').addEventListener('click', (event) => {
  const button = event.target.closest('[data-pick]');
  if (button) fillPicker($('#lv-user'), button.dataset.pick, button.dataset.tag);
});

$('#lv-apply').addEventListener('click', (event) =>
  action(event.currentTarget, async () => {
    const userId = pickedUserId($('#lv-user'));
    if (!userId) throw new Error('Escolha um membro.');
    const result = await guildApi('/levels/update', {
      method: 'POST',
      body: { userId, level: $('#lv-level').value, xp: $('#lv-xp').value },
    });
    toast(result.message);
    await loaders.levels();
  }),
);

$('#levels-reset').addEventListener('click', async (event) => {
  const ok = await confirmBox({ title: 'Zerar todo o XP?', text: 'Todos os membros voltam ao nível 1. Isso não pode ser desfeito (mas existe backup automático).', confirmText: 'Zerar XP', danger: true });
  if (!ok) return;
  action(event.target.closest('button'), async () => {
    toast((await guildApi('/levels/reset', { method: 'POST', body: {} })).message);
    await loaders.levels();
  });
});

/* ----- economia ----- */
loaders.economy = async () => {
  if (!state.guildId) return;
  const { entries, settings } = await guildApi('/economy');
  $('#economy-table').innerHTML = entries.length
    ? entries.map((e) => `<tr>
        <td><div class="who">${avatarHtml(e.avatar)}<div>${esc(e.tag)}<span class="sub">${esc(e.userId)}</span></div></div></td>
        <td><b>${fmtNum(e.balance)}</b> ${esc(settings.currencyEmoji || '')} <small>${esc(settings.currency || '')}</small></td>
        <td class="actions"><button class="btn ghost small" data-pick="${esc(e.userId)}" data-tag="${esc(e.tag)}">Ajustar</button></td>
      </tr>`).join('')
    : '<tr><td colspan="3" class="empty">Ninguém tem saldo ainda.</td></tr>';
};

$('#economy-table').addEventListener('click', (event) => {
  const button = event.target.closest('[data-pick]');
  if (button) fillPicker($('#eco-user'), button.dataset.pick, button.dataset.tag);
});

$('#eco-apply').addEventListener('click', (event) =>
  action(event.currentTarget, async () => {
    const userId = pickedUserId($('#eco-user'));
    if (!userId) throw new Error('Escolha um membro.');
    const result = await guildApi('/economy/update', {
      method: 'POST',
      body: { userId, amount: $('#eco-amount').value, action: $('#eco-action').value },
    });
    toast(result.message);
    await loaders.economy();
  }),
);

$('#economy-reset').addEventListener('click', async (event) => {
  const ok = await confirmBox({ title: 'Zerar todos os saldos?', text: 'Todas as carteiras voltam a zero. Isso não pode ser desfeito (mas existe backup automático).', confirmText: 'Zerar saldos', danger: true });
  if (!ok) return;
  action(event.target.closest('button'), async () => {
    toast((await guildApi('/economy/reset', { method: 'POST', body: {} })).message);
    await loaders.economy();
  });
});

/* ----- sorteios ----- */
loaders.giveaways = async () => {
  if (!state.guildId) return;
  const { giveaways } = await guildApi('/giveaways');
  const box = $('#giveaways-list');
  if (!giveaways.length) {
    box.innerHTML = '<p class="empty">Nenhum sorteio ainda.</p>';
    return;
  }
  box.innerHTML = `<div class="table-wrap"><table>
    <thead><tr><th>Prêmio</th><th>Situação</th><th>Participantes</th><th></th></tr></thead>
    <tbody>${giveaways.map((g) => `<tr>
      <td><b>${esc(g.prize)}</b><span class="sub">${g.channelName ? `#${esc(g.channelName)}` : 'canal apagado'} · ${g.winnerCount} ganhador(es)${g.requiredLevel ? ` · nível ${g.requiredLevel}+` : ''}</span></td>
      <td>${g.ended ? '<span class="badge">Encerrado</span>' : `<span class="badge ok">Ativo</span> <small>${timeUntil(g.endsAt)}</small>`}${g.ended && g.winners.length ? `<span class="sub">${g.winners.map(esc).join(', ')}</span>` : ''}</td>
      <td class="mono">${fmtNum(g.participantCount)}</td>
      <td class="actions">${g.ended
        ? `<button class="btn ghost small" data-gw="reroll" data-id="${esc(g.id)}">Sortear de novo</button>`
        : `<button class="btn ghost small" data-gw="end" data-id="${esc(g.id)}">Encerrar agora</button>`}</td>
    </tr>`).join('')}</tbody></table></div>`;
};

$('#giveaways-list').addEventListener('click', (event) => {
  const button = event.target.closest('[data-gw]');
  if (!button) return;
  action(button, async () => {
    const result = await guildApi(`/giveaways/${button.dataset.id}/${button.dataset.gw}`, { method: 'POST', body: {} });
    toast(result.message);
    await loaders.giveaways();
  });
});

$('#gw-create').addEventListener('click', (event) =>
  action(event.currentTarget, async () => {
    const result = await guildApi('/giveaways', {
      method: 'POST',
      body: {
        channelId: $('#gw-channel').value,
        prize: $('#gw-prize').value,
        duration: $('#gw-duration').value,
        winnerCount: $('#gw-winners').value,
        requiredLevel: $('#gw-level').value,
        requiredRoleId: $('#gw-role').value,
      },
    });
    $('#gw-prize').value = '';
    toast(result.message);
    await loaders.giveaways();
  }),
);

/* ----- abas (Tickets) ----- */
$$('.tabs').forEach((tabs) => {
  tabs.addEventListener('click', (event) => {
    const tab = event.target.closest('.tab');
    if (!tab) return;
    const view = tab.closest('.view');
    $$('.tab', view).forEach((t) => t.classList.toggle('active', t === tab));
    $$('.tabpane', view).forEach((pane) => pane.classList.toggle('active', pane.id === tab.dataset.tab));
    if (tab.dataset.tab === 'tk-central') refreshView();
  });
});

function setBadge(selector, count) {
  const el = $(selector);
  if (!el) return;
  el.hidden = !count;
  el.textContent = count || '';
}

async function refreshBadges() {
  if (!state.guildId) return;
  try {
    const badges = await guildApi('/badges');
    setBadge('#nav-tickets', badges.tickets);
    setBadge('#nav-suggestions', badges.suggestions);
  } catch { /* o selo é só um enfeite; ignora falhas */ }
}
setInterval(() => { if (!document.hidden) refreshBadges(); }, 20000);

/* ----- tickets: central ----- */
const tk = { status: 'open', query: '', openId: null, drawerTimer: null, drawerStatus: null };

const starsHtml = (n) => (n ? `<span class="stars">${'★'.repeat(n)}<span class="dim">${'★'.repeat(5 - n)}</span></span>` : '<small>—</small>');

function timeAgo(ts) {
  const diff = Date.now() - ts;
  if (diff < 60000) return 'agora';
  return `há ${fmtDuration(diff)}`;
}

loaders.tickets = async () => {
  if (!state.guildId) return;
  const params = new URLSearchParams({ status: tk.status, q: tk.query });
  const { stats, tickets } = await guildApi(`/tickets?${params}`);

  $('#tk-stat-open').textContent = fmtNum(stats.open);
  $('#tk-stat-closed').textContent = fmtNum(stats.closed);
  $('#tk-stat-total').textContent = fmtNum(stats.total);
  $('#tk-stat-rating').textContent = stats.averageRating ? `${stats.averageRating.toFixed(1)} ★` : '—';
  $('#tk-stat-rating-label').textContent = stats.ratedCount ? `nota média (${stats.ratedCount} avaliações)` : 'nota média';
  $('#tk-open-count').textContent = stats.open;
  setBadge('#nav-tickets', stats.open);

  $('#tk-table').innerHTML = tickets.length
    ? tickets.map((t) => `<tr class="row-click" data-ticket="${t.id}">
        <td class="mono">#${t.id}</td>
        <td><div class="who"><div>${esc(t.userTag)}<span class="sub">${esc(t.userId)}</span></div></div></td>
        <td>${t.categoryLabel ? `<span class="badge">${esc(t.categoryLabel)}</span>` : '<small>—</small>'}</td>
        <td>${t.status === 'open' ? '<span class="badge ok">Aberto</span>' : '<span class="badge">Fechado</span>'}</td>
        <td>${t.claimedBy ? esc(t.claimedBy.tag) : '<small>ninguém ainda</small>'}</td>
        <td><span title="${fmtTime(t.openedAt)}">${timeAgo(t.openedAt)}</span></td>
        <td>${starsHtml(t.rating)}</td>
        <td class="actions"><button class="btn ghost small" data-ticket="${t.id}">Abrir</button></td>
      </tr>`).join('')
    : `<tr><td colspan="8" class="empty">${tk.query ? 'Nenhum ticket encontrado para essa busca.' : tk.status === 'open' ? 'Nenhum ticket aberto agora. 🎉' : 'Nenhum ticket por aqui.'}</td></tr>`;
};

$('#tk-filter').addEventListener('click', (event) => {
  const button = event.target.closest('button[data-status]');
  if (!button) return;
  tk.status = button.dataset.status;
  $$('button', $('#tk-filter')).forEach((b) => b.classList.toggle('on', b === button));
  loaders.tickets().catch((err) => toast(err.message, 'bad'));
});
$('#tk-search').addEventListener('input', debounce((event) => {
  tk.query = event.target.value.trim();
  loaders.tickets().catch((err) => toast(err.message, 'bad'));
}, 260));
$('#tk-refresh').addEventListener('click', () => loaders.tickets().catch((err) => toast(err.message, 'bad')));
$('#tk-table').addEventListener('click', (event) => {
  const target = event.target.closest('[data-ticket]');
  if (target) openTicketDrawer(target.dataset.ticket);
});

/* ----- tickets: gaveta com a conversa ----- */
function closeDrawer() {
  clearInterval(tk.drawerTimer);
  tk.drawerTimer = null;
  tk.openId = null;
  tk.drawerStatus = null;
  $('#drawer')?.remove();
  $('#drawer-back')?.remove();
  document.removeEventListener('keydown', drawerKey);
}
function drawerKey(event) { if (event.key === 'Escape') closeDrawer(); }

function chatHtml(ticket, transcript) {
  if (!transcript.length) return '<p class="empty">Ainda não há mensagens neste ticket.</p>';
  let lastDay = '';
  return transcript.map((line) => {
    const day = new Date(line.at).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long' });
    const sep = day !== lastDay ? `<div class="day-sep">${esc(day)}</div>` : '';
    lastDay = day;
    const staff = !line.bot && line.authorId && line.authorId !== ticket.userId;
    const time = new Date(line.at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    const files = (line.attachments || []).map((url, i) => `<a href="${esc(url)}" target="_blank" rel="noopener">anexo ${i + 1}</a>`).join(' · ');
    return `${sep}<div class="chat ${line.bot ? 'bot' : staff ? 'staff' : ''}">
      <div class="av">${esc((line.author || '?').charAt(0).toUpperCase())}</div>
      <div><div class="who2">${esc(line.author)}<time>${time}</time></div>
        <div class="bubble">${esc(line.content) || '<small>(sem texto)</small>'}</div>
        ${files ? `<div class="files">${files}</div>` : ''}</div>
    </div>`;
  }).join('');
}

async function paintDrawer(first) {
  const drawer = $('#drawer');
  if (!drawer || !tk.openId) return;
  const { ticket, transcript } = await guildApi(`/tickets/${tk.openId}`);
  if (!$('#drawer')) return;

  const isOpen = ticket.status === 'open';
  $('.drawer-head', drawer).innerHTML = `
    <div style="flex:1;min-width:0">
      <h3>Ticket #${ticket.id} · ${esc(ticket.userTag)}</h3>
      <div class="meta">
        ${isOpen ? '<span class="badge ok">Aberto</span>' : '<span class="badge">Fechado</span>'}
        ${ticket.categoryLabel ? `<span class="badge">${esc(ticket.categoryLabel)}</span>` : ''}
        ${ticket.claimedBy ? `<span class="badge">atendido por ${esc(ticket.claimedBy.tag)}</span>` : '<span class="badge warn">sem atendente</span>'}
        <span class="badge">aberto ${fmtTime(ticket.openedAt)}</span>
        ${ticket.rating ? `<span class="badge warn">${'★'.repeat(ticket.rating)} nota ${ticket.rating}/5</span>` : ''}
      </div>
    </div>
    <button class="btn ghost small icon" data-close aria-label="Fechar">${icon('x')}</button>`;

  const body = $('.drawer-body', drawer);
  const nearBottom = body.scrollHeight - body.scrollTop - body.clientHeight < 80;
  body.innerHTML = chatHtml(ticket, transcript);
  if (first || nearBottom) body.scrollTop = body.scrollHeight;

  // O rodapé só é redesenhado quando o ticket muda de aberto para fechado, para não apagar o que você está digitando.
  if (tk.drawerStatus !== ticket.status) {
    tk.drawerStatus = ticket.status;
    $('.drawer-foot', drawer).innerHTML = isOpen
      ? `<textarea id="tk-reply" placeholder="Escreva a resposta para o membro… (Ctrl+Enter envia)" maxlength="1800"></textarea>
         <div class="btn-row">
           <button class="btn danger small" data-act="close">${icon('x')} Fechar ticket</button>
           <button class="btn" data-act="reply">${icon('send')} Enviar resposta</button>
         </div>`
      : `<div class="hint" style="margin:0">Fechado ${fmtTime(ticket.closedAt)} por <b>${esc(ticket.closedBy || '—')}</b>.${ticket.closeReason ? ` Motivo: ${esc(ticket.closeReason)}` : ''}</div>`;
  }
}

async function openTicketDrawer(id) {
  closeDrawer();
  tk.openId = id;
  const back = document.createElement('div');
  back.className = 'drawer-back';
  back.id = 'drawer-back';
  const drawer = document.createElement('aside');
  drawer.className = 'drawer';
  drawer.id = 'drawer';
  drawer.setAttribute('role', 'dialog');
  drawer.innerHTML = '<div class="drawer-head"><h3>Carregando…</h3></div><div class="drawer-body"></div><div class="drawer-foot"></div>';
  document.body.append(back, drawer);
  back.addEventListener('click', closeDrawer);
  document.addEventListener('keydown', drawerKey);

  drawer.addEventListener('keydown', (event) => {
    if (event.target.id === 'tk-reply' && event.key === 'Enter' && (event.ctrlKey || event.metaKey)) {
      event.preventDefault();
      $('[data-act="reply"]', drawer)?.click();
    }
  });

  drawer.addEventListener('click', async (event) => {
    if (event.target.closest('[data-close]')) return closeDrawer();
    const button = event.target.closest('[data-act]');
    if (!button) return undefined;
    const ticketId = tk.openId;

    if (button.dataset.act === 'reply') {
      const field = $('#tk-reply');
      if (!field.value.trim()) { toast('Escreva a resposta antes de enviar.', 'bad'); return undefined; }
      return action(button, async () => {
        const result = await guildApi(`/tickets/${ticketId}/reply`, { method: 'POST', body: { message: field.value } });
        field.value = '';
        toast(result.message);
        await paintDrawer(true);
      });
    }
    if (button.dataset.act === 'close') {
      const reason = await promptBox({
        title: `Fechar o ticket #${ticketId}?`,
        text: 'O canal será apagado depois de guardar a conversa. Se quiser, diga o motivo (o membro e o registro veem).',
        placeholder: 'Ex: problema resolvido',
        confirmText: 'Fechar ticket',
        danger: true,
      });
      if (reason === null) return undefined;
      return action(button, async () => {
        toast((await guildApi(`/tickets/${ticketId}/close`, { method: 'POST', body: { reason } })).message);
        closeDrawer();
        await loaders.tickets();
        refreshBadges();
      });
    }
    return undefined;
  });

  try {
    await paintDrawer(true);
  } catch (err) {
    toast(err.message, 'bad');
    closeDrawer();
    return;
  }
  tk.drawerTimer = setInterval(() => { if (!document.hidden) paintDrawer(false).catch(() => {}); }, 6000);
}

/* ----- tickets: categorias ----- */
function renderCategories() {
  const box = $('#cat-list');
  const list = state.config?.tickets?.categories || [];
  box.innerHTML = list.length
    ? list.map((c) => `<div class="cat-item"><span class="emoji">${esc(c.emoji || '🎫')}</span>
        <div class="txt"><b>${esc(c.label)}</b>${c.description ? `<span>${esc(c.description)}</span>` : ''}</div>
        <button class="btn ghost small" data-cat-del="${esc(c.id)}">${icon('trash')}</button></div>`).join('')
    : '<p class="empty" style="padding:10px 0">Nenhuma categoria. O painel público usa um botão único.</p>';
}

async function saveCategories(categories) {
  await guildApi('/config/tickets', { method: 'POST', body: { ...state.config.tickets, categories } });
  state.config = await guildApi('/config');
  renderCategories();
}

$('#cat-add').addEventListener('click', (event) =>
  action(event.currentTarget, async () => {
    const label = $('#cat-label').value.trim();
    if (!label) throw new Error('Dê um nome à categoria.');
    const current = state.config.tickets.categories || [];
    if (current.length >= 10) throw new Error('O limite é de 10 categorias.');
    await saveCategories([...current, { label, emoji: $('#cat-emoji').value.trim(), description: $('#cat-desc').value.trim() }]);
    ['#cat-label', '#cat-emoji', '#cat-desc'].forEach((s) => { $(s).value = ''; });
    toast('Categoria adicionada. Publique o painel de novo para atualizar o menu no Discord.');
  }),
);
$('#cat-list').addEventListener('click', (event) => {
  const button = event.target.closest('[data-cat-del]');
  if (!button) return;
  action(button, async () => {
    await saveCategories((state.config.tickets.categories || []).filter((c) => c.id !== button.dataset.catDel));
    toast('Categoria removida.');
  });
});

/* ----- tickets: publicar o painel (botões nas duas abas) ----- */
$$('.js-publish-panel').forEach((button) =>
  button.addEventListener('click', async (event) => {
    const form = $('#view-tickets form');
    if (form.classList.contains('is-dirty')) {
      const ok = await confirmBox({ title: 'Há alterações não salvas', text: 'O painel usa o que está salvo. Salve antes de publicar para não sair com o texto antigo.', confirmText: 'Publicar mesmo assim' });
      if (!ok) return;
    }
    action(event.currentTarget, async () => toast((await guildApi('/tickets/panel', { method: 'POST', body: {} })).message));
  }),
);

/* ----- sugestões ----- */
const sg = { status: 'pending' };

loaders.suggestions = async () => {
  if (!state.guildId) return;
  const { counts, suggestions } = await guildApi(`/suggestions?status=${sg.status}`);
  $('#sug-n-pending').textContent = counts.pending || '';
  $('#sug-n-approved').textContent = counts.approved || '';
  $('#sug-n-denied').textContent = counts.denied || '';
  setBadge('#nav-suggestions', counts.pending);

  const label = { pending: '<span class="badge warn">Em votação</span>', approved: '<span class="badge ok">Aprovada</span>', denied: '<span class="badge bad">Negada</span>' };
  $('#sug-list').innerHTML = suggestions.length
    ? suggestions.map((s) => `<div class="sug" data-sug="${s.id}">
        <div class="top"><span class="badge">#${s.id}</span> ${label[s.status]}<b>${esc(s.userTag)}</b>
          <span class="votes"><span>👍 ${s.up}</span><span>👎 ${s.down}</span></span><small>${timeAgo(s.createdAt)}</small></div>
        <div class="text">${esc(s.text)}</div>
        ${s.note ? `<div class="note"><b>${esc(s.reviewedBy || 'Equipe')}:</b> ${esc(s.note)}</div>` : ''}
        ${s.status === 'pending' ? `<div class="review"><input type="text" placeholder="Resposta para o autor (opcional)" maxlength="500" />
          <button class="btn small" data-review="approved">Aprovar</button><button class="btn danger small" data-review="denied">Negar</button></div>` : ''}
      </div>`).join('')
    : `<p class="empty">${sg.status === 'pending' ? 'Nenhuma sugestão esperando resposta.' : 'Nada por aqui ainda.'}</p>`;
};

$('#sug-filter').addEventListener('click', (event) => {
  const button = event.target.closest('button[data-status]');
  if (!button) return;
  sg.status = button.dataset.status;
  $$('button', $('#sug-filter')).forEach((b) => b.classList.toggle('on', b === button));
  loaders.suggestions().catch((err) => toast(err.message, 'bad'));
});

$('#sug-list').addEventListener('click', (event) => {
  const button = event.target.closest('[data-review]');
  if (!button) return;
  const box = button.closest('.sug');
  action(button, async () => {
    const result = await guildApi(`/suggestions/${box.dataset.sug}/review`, {
      method: 'POST',
      body: { status: button.dataset.review, note: $('input', box).value },
    });
    toast(result.message);
    await loaders.suggestions();
  });
});

/* ----- tema (cor do painel) ----- */
const PRESETS = [
  { name: 'Céu', h: 205 }, { name: 'Índigo', h: 235 }, { name: 'Violeta', h: 265 }, { name: 'Rosa', h: 330 },
  { name: 'Vermelho', h: 355 }, { name: 'Laranja', h: 25 }, { name: 'Floresta', h: 146 }, { name: 'Turquesa', h: 175 },
];

function syncTheme() {
  const hue = window.SkyeTheme.get();
  $('#hue').value = hue;
  $$('.swatch').forEach((b) => b.classList.toggle('on', Number(b.dataset.h) === hue));
}

$('#swatches').innerHTML = PRESETS.map((p) => `<button type="button" class="swatch" data-h="${p.h}"><i style="background:hsl(${p.h} 78% 62%)"></i>${p.name}</button>`).join('');
$('#swatches').addEventListener('click', (event) => {
  const swatch = event.target.closest('.swatch');
  if (!swatch) return;
  window.SkyeTheme.set(Number(swatch.dataset.h));
  syncTheme();
});
$('#hue').addEventListener('input', (event) => {
  window.SkyeTheme.set(Number(event.target.value));
  syncTheme();
});
$('#theme-reset').addEventListener('click', () => {
  window.SkyeTheme.reset();
  syncTheme();
});

function toggleThemePopover(show) {
  const pop = $('#theme-pop');
  const open = show ?? pop.hidden;
  pop.hidden = !open;
  $('#theme-btn').setAttribute('aria-expanded', String(open));
}
$('#theme-btn').addEventListener('click', (event) => {
  event.stopPropagation();
  toggleThemePopover();
});
document.addEventListener('click', (event) => {
  if (!event.target.closest('.theme-wrap')) toggleThemePopover(false);
});
document.addEventListener('keydown', (event) => { if (event.key === 'Escape') toggleThemePopover(false); });
syncTheme();
window.SkyeTheme.apply(window.SkyeTheme.get());

/* ----- mensagens ----- */
$('#msg-send').addEventListener('click', (event) =>
  action(event.currentTarget, async () => {
    const result = await guildApi('/message', {
      method: 'POST',
      body: {
        channelId: $('#msg-channel').value,
        content: $('#msg-content').value,
        useEmbed: $('#msg-embed').checked,
        title: $('#msg-title').value,
        description: $('#msg-desc').value,
        embedColor: $('#msg-color').value,
        imageUrl: $('#msg-image').value,
        thumbnailUrl: $('#msg-thumb').value,
        footer: $('#msg-footer').value,
      },
    });
    toast(result.message);
  }),
);

$('#rb-send').addEventListener('click', (event) =>
  action(event.currentTarget, async () => {
    const roles = [...$('#rb-roles').selectedOptions].map((o) => ({ roleId: o.value }));
    if (roles.length > 5) throw new Error('Escolha no máximo 5 cargos.');
    const result = await guildApi('/role-buttons', {
      method: 'POST',
      body: { channelId: $('#rb-channel').value, title: $('#rb-title').value, description: $('#rb-desc').value, roles },
    });
    toast(result.message);
  }),
);

/* ----- comandos personalizados ----- */
function resetCommandForm() {
  state.commandBeingEdited = null;
  ['#cmd-name', '#cmd-reply', '#cmd-dm'].forEach((s) => { $(s).value = ''; });
  $('#cmd-role').value = '';
  $('#cmd-amount').value = 0;
  $('#cmd-cooldown').value = 10;
  $('#cmd-name').disabled = false;
  $('#cmd-form-title').textContent = 'Criar ou atualizar';
  $('#cmd-cancel').hidden = true;
}

loaders.commands = async () => {
  if (!state.guildId) return;
  const { commands } = await guildApi('/commands');
  state.commandList = commands;
  const prefix = state.config?.prefix || '!';
  const box = $('#commands-list');
  if (!commands.length) {
    box.innerHTML = '<p class="empty">Nenhum comando criado ainda.</p>';
    return;
  }
  const label = { reply: 'responde', send_dm: 'privado', add_role: 'cargo', add_money: 'moedas' };
  box.innerHTML = `<div class="table-wrap"><table>
    <thead><tr><th>Comando</th><th>O que faz</th><th>Espera</th><th></th></tr></thead>
    <tbody>${commands.map((c) => `<tr>
      <td><code>${esc(prefix)}${esc(c.name)}</code></td>
      <td>${(c.actions || []).map((a) => `<span class="badge">${label[a.type] || a.type}</span>`).join(' ')}</td>
      <td class="mono">${c.cooldown ?? 10}s</td>
      <td class="actions">
        <button class="btn ghost small" data-edit="${esc(c.name)}">Editar</button>
        <button class="btn danger small" data-del="${esc(c.name)}">${icon('trash')}</button>
      </td></tr>`).join('')}</tbody></table></div>`;
};

$('#commands-list').addEventListener('click', async (event) => {
  const edit = event.target.closest('[data-edit]');
  const del = event.target.closest('[data-del]');

  if (edit) {
    const command = (state.commandList || []).find((c) => c.name === edit.dataset.edit);
    if (!command) return;
    resetCommandForm();
    state.commandBeingEdited = command.name;
    $('#cmd-name').value = command.name;
    $('#cmd-name').disabled = true;
    $('#cmd-cooldown').value = command.cooldown ?? 10;
    for (const a of command.actions || []) {
      if (a.type === 'reply') $('#cmd-reply').value = a.content;
      if (a.type === 'send_dm') $('#cmd-dm').value = a.content;
      if (a.type === 'add_role') $('#cmd-role').value = a.roleId;
      if (a.type === 'add_money') $('#cmd-amount').value = a.amount;
    }
    $('#cmd-form-title').textContent = `Editando ${state.config.prefix}${command.name}`;
    $('#cmd-cancel').hidden = false;
    $('#cmd-name').closest('.card').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  if (del) {
    const ok = await confirmBox({ title: `Apagar ${del.dataset.del}?`, text: 'O comando deixa de responder imediatamente.', confirmText: 'Apagar', danger: true });
    if (!ok) return;
    action(del, async () => {
      toast((await guildApi(`/commands/${encodeURIComponent(del.dataset.del)}`, { method: 'DELETE' })).message);
      await loaders.commands();
    });
  }
});

$('#cmd-cancel').addEventListener('click', resetCommandForm);
$('#cmd-save').addEventListener('click', (event) =>
  action(event.currentTarget, async () => {
    const result = await guildApi('/commands', {
      method: 'POST',
      body: {
        name: $('#cmd-name').value,
        reply: $('#cmd-reply').value,
        dm: $('#cmd-dm').value,
        roleId: $('#cmd-role').value,
        amount: $('#cmd-amount').value,
        cooldown: $('#cmd-cooldown').value,
      },
    });
    toast(result.message);
    resetCommandForm();
    await loaders.commands();
  }),
);

/* ----- auto-moderação ----- */
loaders.automod = async () => {
  if (!state.guildId) return;
  const { entries } = await guildApi('/warns');
  $('#warns-table').innerHTML = entries.length
    ? entries.map((e) => `<tr>
        <td><div class="who">${avatarHtml(e.avatar)}<div>${esc(e.tag)}<span class="sub">${esc(e.userId)}</span></div></div></td>
        <td><span class="badge warn">${e.count}</span></td>
        <td>${esc(e.last?.reason || '')}</td>
        <td class="actions"><button class="btn ghost small" data-clear="${esc(e.userId)}">Limpar</button></td>
      </tr>`).join('')
    : '<tr><td colspan="4" class="empty">Ninguém com avisos. 🌱</td></tr>';
};

$('#warns-table').addEventListener('click', (event) => {
  const button = event.target.closest('[data-clear]');
  if (!button) return;
  action(button, async () => {
    toast((await guildApi(`/warns/${button.dataset.clear}`, { method: 'DELETE' })).message);
    await loaders.automod();
  });
});

/* ----- registros ----- */
let logsCache = [];
function paintLogs() {
  const term = $('#logs-filter').value.trim().toLowerCase();
  const rows = term ? logsCache.filter((l) => `${l.action} ${l.details}`.toLowerCase().includes(term)) : logsCache;
  $('#logs-list').innerHTML = renderLogs(rows);
}
loaders.logs = async () => {
  if (!state.guildId) return;
  logsCache = (await guildApi('/logs?limit=200')).logs;
  paintLogs();
};
$('#logs-filter').addEventListener('input', paintLogs);

/* ----- sistema ----- */
function renderSystem() {
  const s = state.status;
  if (!s) return;
  $('#sys-ping').textContent = s.botOnline && s.ping != null ? `${s.ping}ms` : '—';
  $('#sys-uptime').textContent = s.botOnline ? fmtDuration(s.uptime) : '—';
  $('#sys-memory').textContent = `${s.system.memoryMb} MB`;
  $('#sys-version').textContent = `v${s.version}`;

  const t = s.panel.tunnel;
  const provider = { ngrok: 'ngrok', cloudflare: 'Cloudflare' }[t.provider] || 'nenhum';
  const stateLabel = { disabled: 'desligado', connecting: 'conectando…', online: 'online', error: 'com erro' }[t.state];
  $('#sys-details').innerHTML = `
    Bot: <b>${esc(s.botTag || 'offline')}</b> · Node ${esc(s.system.node)} · processo ligado há ${fmtDuration(s.system.processUptime)}<br />
    Link público (${esc(provider)}): <b>${esc(stateLabel)}</b>${s.panel.publicUrl ? ` — <a href="${esc(s.panel.publicUrl)}" target="_blank" rel="noopener">${esc(s.panel.publicUrl)}</a>` : ''}${t.provider === 'cloudflare' && s.panel.publicUrl ? ' <small>(link temporário: muda toda vez que o bot reinicia; veja o novo no console)</small>' : ''}${t.error ? `<br /><small>${esc(t.error)}</small>` : ''}<br />
    Endereço direto: ${s.panel.directUrl ? `<code>${esc(s.panel.directUrl)}</code>` : `porta ${esc(s.panel.port)}`} <small>(só abre se a host liberou a porta)</small><br />
    Música: ${s.music.ytdlp ? `yt-dlp ${esc(s.music.ytdlp)}` : 'yt-dlp indisponível (usando ytdl-core)'} · ffmpeg ${s.music.ffmpeg ? 'ok' : 'ausente'} · cookies.txt ${s.music.cookies ? 'presente' : 'não usado'}`;
}

loaders.system = async () => {
  await loadStatus();
  renderSystem();
  const { backups } = await api('/backups');
  $('#backup-list').innerHTML = backups.length
    ? `<div class="table-wrap"><table><tbody>${backups.map((b) => `<tr><td class="mono">${esc(b.name)}</td><td>${fmtTime(b.at)}</td><td class="mono">${fmtBytes(b.size)}</td></tr>`).join('')}</tbody></table></div>`
    : '<p class="empty">Nenhum backup ainda.</p>';
};

$('#backup-now').addEventListener('click', (event) =>
  action(event.currentTarget, async () => {
    toast((await api('/backup', { method: 'POST', body: {} })).message);
    await loaders.system();
  }),
);

/* ------------------------------------------------------------------ início */

(async function init() {
  await loadStatus();
  openView(location.hash.slice(1) || 'overview', { updateHash: false });
  setInterval(() => { if (!document.hidden) loadStatus(); }, 10000);
})();
