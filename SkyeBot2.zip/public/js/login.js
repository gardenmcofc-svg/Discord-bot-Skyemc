'use strict';

const form = document.getElementById('login-form');
const message = document.getElementById('message');
const submit = document.getElementById('submit');
const password = document.getElementById('password');

document.getElementById('toggle-pw').addEventListener('click', (event) => {
  const show = password.type === 'password';
  password.type = show ? 'text' : 'password';
  event.currentTarget.setAttribute('aria-label', show ? 'Ocultar senha' : 'Mostrar senha');
  password.focus();
});

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  message.textContent = '';
  submit.disabled = true;
  submit.textContent = 'Entrando…';

  try {
    const response = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'ngrok-skip-browser-warning': '1' },
      body: JSON.stringify({
        user: document.getElementById('user').value,
        password: password.value,
      }),
    });
    const data = await response.json().catch(() => ({}));

    if (!response.ok || data.error) {
      message.textContent = data.message || 'Não foi possível entrar.';
      return;
    }
    window.location.href = '/';
  } catch {
    message.textContent = 'O painel não respondeu. O bot ainda está rodando?';
  } finally {
    submit.disabled = false;
    submit.textContent = 'Entrar';
  }
});
