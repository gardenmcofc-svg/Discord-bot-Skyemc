/* Tema do painel: um único número (o matiz) muda todas as cores. Carrega no <head> para não piscar. */
(function () {
  'use strict';
  var KEY = 'skye.theme';
  var DEFAULT = 205; // azul-céu

  function read() {
    try {
      var raw = localStorage.getItem(KEY);
      if (raw === null) return DEFAULT;
      var value = Number(raw);
      return isFinite(value) ? Math.min(360, Math.max(0, value)) : DEFAULT;
    } catch (e) {
      return DEFAULT;
    }
  }

  function apply(hue) {
    document.documentElement.style.setProperty('--h', String(hue));
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', 'hsl(' + hue + ', 30%, 5.5%)');
  }

  function set(hue) {
    apply(hue);
    try {
      localStorage.setItem(KEY, String(hue));
    } catch (e) { /* sem armazenamento: vale só nesta visita */ }
  }

  function reset() {
    try {
      localStorage.removeItem(KEY);
    } catch (e) { /* nada a fazer */ }
    apply(DEFAULT);
  }

  window.SkyeTheme = { get: read, set: set, reset: reset, apply: apply, DEFAULT: DEFAULT };
  apply(read());
})();
